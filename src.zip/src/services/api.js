const API_BASE = '/api';

function getAuthHeaders() {
  const token = localStorage.getItem('landgov_auth_token');
  const headers = { 'Content-Type': 'application/json' };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export const api = {
  // 1. Health & Overview
  getHealth: async () => {
    const res = await fetch(`${API_BASE}/health`);
    return res.json();
  },

  getNationalOverview: async () => {
    const res = await fetch(`${API_BASE}/dashboard/overview`);
    return res.json();
  },

  // 2. Auth & RBAC
  login: async (email, password) => {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Login failed');
    }
    return res.json();
  },

  getProfile: async () => {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // 3. WebGIS Parcels
  getParcelsByBbox: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE}/parcels/bbox?${query}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getParcelByUlpin: async (ulpin) => {
    const res = await fetch(`${API_BASE}/parcels/ulpin/${encodeURIComponent(ulpin)}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  validateUlpinSyntax: async (ulpin) => {
    const res = await fetch(`${API_BASE}/parcels/validate-ulpin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ulpin })
    });
    return res.json();
  },

  updateParcelVerification: async (ulpin, status, remarks) => {
    const res = await fetch(`${API_BASE}/parcels/${encodeURIComponent(ulpin)}/verify`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify({ status, remarks })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update verification status');
    }
    return res.json();
  },

  // 4. Ingested Datasets
  getDatasets: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE}/datasets?${query}`);
    return res.json();
  },

  getDatasetById: async (id) => {
    const res = await fetch(`${API_BASE}/datasets/${id}`);
    return res.json();
  },

  uploadDataset: async (payload) => {
    const res = await fetch(`${API_BASE}/datasets/upload`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Dataset ingestion failed');
    }
    return res.json();
  },

  // 5. Research & Legal Search (RAG with >0.85 Verification)
  searchLegalEvidence: async (query, actFilter = 'ALL') => {
    const res = await fetch(`${API_BASE}/legal/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, actFilter })
    });
    return res.json();
  },

  getStatutoryActs: async () => {
    const res = await fetch(`${API_BASE}/legal/acts`);
    return res.json();
  },

  // 6. Geo-Analytics
  getAnalyticsWorkspace: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE}/analytics/workspace?${query}`);
    return res.json();
  },

  // 7. Policy Simulator
  getScenarios: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE}/scenarios?${query}`);
    return res.json();
  },

  createScenario: async (payload) => {
    const res = await fetch(`${API_BASE}/scenarios/create`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Scenario creation failed');
    }
    return res.json();
  },

  // 8. Open Innovation Hub
  getProposals: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE}/innovation/proposals?${query}`);
    return res.json();
  },

  submitProposal: async (payload) => {
    const res = await fetch(`${API_BASE}/innovation/submit`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Proposal submission failed');
    }
    return res.json();
  },

  reviewProposal: async (id, payload) => {
    const res = await fetch(`${API_BASE}/innovation/review/${id}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Proposal review failed');
    }
    return res.json();
  },

  // 9. Decision Dossiers
  getDossiers: async () => {
    const res = await fetch(`${API_BASE}/dossiers`);
    return res.json();
  },

  getDossierById: async (id) => {
    const res = await fetch(`${API_BASE}/dossiers/${id}`);
    return res.json();
  },

  createDossier: async (payload) => {
    const res = await fetch(`${API_BASE}/dossiers/create`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Dossier creation failed');
    }
    return res.json();
  },

  getDossierCsvUrl: (id) => `${API_BASE}/dossiers/${id}/export-csv`,

  // 10. Audit Ledger & SHA-256 Verification
  getAuditLogs: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE}/audit/logs?${query}`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Access denied: Audit logs require Administrator privileges.');
    }
    return res.json();
  },

  verifyAuditChain: async () => {
    const res = await fetch(`${API_BASE}/audit/verify`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Access denied: Audit verification requires Administrator privileges.');
    }
    return res.json();
  }
};
