import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  FileText, 
  Download, 
  Plus, 
  ExternalLink, 
  ShieldCheck, 
  Calendar, 
  CheckCircle2, 
  X,
  FileSpreadsheet,
  Printer
} from 'lucide-react';

export default function Dossiers() {
  const { user, hasRole } = useAuth();
  const [dossiers, setDossiers] = useState([]);
  const [selectedDossier, setSelectedDossier] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Dossier Form
  const [title, setTitle] = useState('');
  const [committee, setCommittee] = useState('Inter-Ministerial Land & Infrastructure Committee');
  const [summary, setSummary] = useState('');
  const [recommendations, setRecommendations] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    loadDossiers();
  }, []);

  async function loadDossiers() {
    try {
      setLoading(true);
      const res = await api.getDossiers();
      setDossiers(res.dossiers || []);
      if (res.dossiers && res.dossiers.length > 0 && !selectedDossier) {
        setSelectedDossier(res.dossiers[0]);
      }
    } catch (err) {
      console.error('[Dossiers] Error loading dossiers:', err);
    } finally {
      setLoading(false);
    }
  }

  const handleCreateDossier = async (e) => {
    e.preventDefault();
    if (!title.trim() || !summary.trim()) return;

    try {
      setCreating(true);
      const res = await api.createDossier({
        title,
        targetCommittee: committee,
        executiveSummary: summary,
        keyRecommendations: recommendations.split('\n').filter(r => r.trim()),
        authorName: user?.fullName || 'Senior Officer',
        authorDepartment: user?.department || 'Land Revenue'
      });
      setShowCreateModal(false);
      setTitle('');
      setSummary('');
      setRecommendations('');
      loadDossiers();
      if (res.dossier) setSelectedDossier(res.dossier);
      alert('Cabinet Decision Dossier created and registered on the tamper-evident chain!');
    } catch (err) {
      alert(err.message || 'Creation failed');
    } finally {
      setCreating(false);
    }
  };

  const handleExportCsv = (dossierId) => {
    window.open(api.getDossierCsvUrl(dossierId), '_blank');
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Evidence-Based Decision Dossiers</h1>
          <p className="page-subtitle">
            Statutory Briefings & Executive Compilations for Cabinet & High-Powered Committees
          </p>
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          {selectedDossier && (
            <button 
              className="btn btn-secondary"
              onClick={() => handleExportCsv(selectedDossier.id)}
            >
              <FileSpreadsheet size={15} color="#059669" /> Export CSV Briefing
            </button>
          )}

          <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
            <Plus size={16} /> Compile New Dossier
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 2fr)', gap: '20px' }}>
        
        {/* Left Dossier List */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Published Dossiers ({dossiers.length})</span>
            <span className="badge badge-blue">Official</span>
          </div>
          <div className="card-body" style={{ padding: '12px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {dossiers.map(d => {
                const isSelected = selectedDossier?.id === d.id;
                return (
                  <div
                    key={d.id}
                    onClick={() => setSelectedDossier(d)}
                    style={{
                      padding: '14px',
                      borderRadius: '8px',
                      border: isSelected ? '2px solid var(--gov-navy-800)' : '1px solid #e2e8f0',
                      background: isSelected ? '#f1f5f9' : '#ffffff',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span className="badge badge-purple" style={{ fontSize: '10px' }}>{d.id}</span>
                      <span style={{ fontSize: '11px', color: '#94a3b8' }}>
                        {d.createdAt ? new Date(d.createdAt).toLocaleDateString() : '2026-03-10'}
                      </span>
                    </div>
                    <div style={{ fontWeight: 700, fontSize: '13.5px', color: 'var(--gov-navy-950)', marginBottom: '4px' }}>
                      {d.title}
                    </div>
                    <div style={{ fontSize: '11.5px', color: '#64748b' }}>
                      Target: {d.targetCommittee}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Dossier Detail Viewer */}
        {selectedDossier ? (
          <div className="card">
            <div className="card-header" style={{ background: '#f8fafc' }}>
              <div>
                <span className="badge badge-green" style={{ marginBottom: '6px' }}>
                  <ShieldCheck size={12} /> SHA-256 Verified Official Dossier
                </span>
                <h2 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--gov-navy-950)' }}>
                  {selectedDossier.title}
                </h2>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                  Prepared for: <strong>{selectedDossier.targetCommittee}</strong> • Author: {selectedDossier.authorName || 'Revenue Officer'}
                </div>
              </div>

              <button 
                className="btn btn-sm btn-secondary" 
                onClick={() => window.print()}
                title="Print official dossier"
              >
                <Printer size={14} /> Print
              </button>
            </div>

            <div className="card-body">
              {/* Executive Summary */}
              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ fontSize: '13px', fontWeight: 700, color: 'var(--gov-navy-900)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>
                  Executive Summary
                </h3>
                <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '13.5px', lineHeight: 1.6, color: '#334155' }}>
                  {selectedDossier.executiveSummary}
                </div>
              </div>

              {/* Statutory Compliance Matrix */}
              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ fontSize: '13px', fontWeight: 700, color: 'var(--gov-navy-900)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>
                  Statutory Compliance Verification
                </h3>
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Statute / Legal Act</th>
                        <th>Clause Reference</th>
                        <th>Compliance Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td style={{ fontWeight: 600 }}>Right to Fair Compensation (LARR 2013)</td>
                        <td>Section 26 & First Schedule (100% Solatium)</td>
                        <td><span className="badge badge-green">Fully Compliant</span></td>
                      </tr>
                      <tr>
                        <td style={{ fontWeight: 600 }}>Forest Rights Act (FRA 2006)</td>
                        <td>Section 4(5) (Inviolable Rights Verification)</td>
                        <td><span className="badge badge-green">Gram Sabha Certified</span></td>
                      </tr>
                      <tr>
                        <td style={{ fontWeight: 600 }}>Wetlands Conservation Rules 2017</td>
                        <td>Rule 4 (Prohibited Conversions in Buffer)</td>
                        <td><span className="badge badge-green">Buffer Boundary Respected</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Key Recommendations */}
              <div>
                <h3 style={{ fontSize: '13px', fontWeight: 700, color: 'var(--gov-navy-900)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '10px' }}>
                  Actionable Policy Directives & Recommendations
                </h3>
                <ul style={{ paddingLeft: '20px', fontSize: '13px', color: '#334155', lineHeight: 1.6 }}>
                  {selectedDossier.keyRecommendations?.map((rec, i) => (
                    <li key={i} style={{ marginBottom: '6px' }}>{rec}</li>
                  )) || (
                    <>
                      <li>Mandate digital verification of all 14-digit ULPIN records prior to disbursement.</li>
                      <li>Deploy Sentinel-2 automated change detection along the 500m right-of-way corridor.</li>
                      <li>Establish a single-window grievance portal for affected landholders with 15-day resolution SLAs.</li>
                    </>
                  )}
                </ul>
              </div>

            </div>
          </div>
        ) : (
          <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px', color: '#94a3b8' }}>
            <p>Select a dossier from the registry or compile a new one.</p>
          </div>
        )}

      </div>

      {/* Create Dossier Modal */}
      {showCreateModal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Compile Decision Dossier
              </h3>
              <button onClick={() => setShowCreateModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleCreateDossier}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Dossier Title *</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    placeholder="e.g. Pune Peri-Urban Industrial Expansion Land Assessment 2026"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Target Governance Body *</label>
                  <select 
                    className="form-control"
                    value={committee}
                    onChange={(e) => setCommittee(e.target.value)}
                  >
                    <option value="Inter-Ministerial Land & Infrastructure Committee">Inter-Ministerial Land & Infrastructure Committee</option>
                    <option value="State Cabinet Sub-Committee on Revenue Affairs">State Cabinet Sub-Committee on Revenue Affairs</option>
                    <option value="District Land Acquisition & Collector Review Board">District Land Acquisition & Collector Review Board</option>
                    <option value="High-Level Ecological Monitoring Authority">High-Level Ecological Monitoring Authority</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Executive Briefing Summary *</label>
                  <textarea 
                    className="form-control"
                    placeholder="Concise overview of geographical scope, legal standing, and key findings..."
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Policy Recommendations (One per line)</label>
                  <textarea 
                    className="form-control"
                    placeholder="Enter actionable directives..."
                    value={recommendations}
                    onChange={(e) => setRecommendations(e.target.value)}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCreateModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={creating}>
                  {creating ? 'Hashing & Publishing...' : 'Publish Official Dossier'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
