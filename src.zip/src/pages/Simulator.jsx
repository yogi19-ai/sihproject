import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  Sliders, 
  TrendingUp, 
  DollarSign, 
  ShieldCheck, 
  Layers, 
  Calendar, 
  HelpCircle,
  Save,
  CheckCircle2,
  PieChart
} from 'lucide-react';

export default function Simulator() {
  const { user, hasRole } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState('markov'); // 'markov' or 'larr'

  // --- 1. Markov CA Parameters ---
  const [years, setYears] = useState(5);
  const [agriRate, setAgriRate] = useState(0.25);
  const [ecoProtect, setEcoProtect] = useState(true);
  const [simResult, setSimResult] = useState(null);
  const [savingScenario, setSavingScenario] = useState(false);
  const [scenarioTitle, setScenarioTitle] = useState('Pune Ring Road 2031 Transition Model');

  // --- 2. LARR 2013 Compensation Parameters ---
  const [areaHa, setAreaHa] = useState(15.5);
  const [circleRatePerHa, setCircleRatePerHa] = useState(45.0); // Lakhs INR per hectare
  const [isRural, setIsRural] = useState(true);
  const [ruralMultiplier, setRuralMultiplier] = useState(1.5);
  const [solatiumPct, setSolatiumPct] = useState(100); // 100% statutory solatium

  // Run Markov Simulation
  useEffect(() => {
    runMarkovSimulation();
  }, [years, agriRate, ecoProtect]);

  function runMarkovSimulation() {
    const baseline = { agri: 1000.0, builtup: 400.0, forest: 350.0, water: 150.0, fallow: 200.0 };
    const stepRate = (agriRate / 5.0) * years;
    const ecoMult = ecoProtect ? 0.05 : 0.35;

    const convAgri = Math.round(baseline.agri * Math.min(0.60, stepRate) * 100) / 100;
    const convFallow = Math.round(baseline.fallow * Math.min(0.70, stepRate * 1.2) * 100) / 100;
    const convForest = Math.round(baseline.forest * Math.min(0.25, stepRate * ecoMult) * 100) / 100;
    const convWater = ecoProtect ? 0.0 : Math.round(baseline.water * 0.05 * 100) / 100;

    const newBuiltup = Math.round((convAgri + convFallow + convForest + convWater) * 100) / 100;

    setSimResult({
      baselineYear: 2026,
      targetYear: 2026 + parseInt(years),
      convertedAgriHa: convAgri,
      convertedForestHa: convForest,
      convertedWaterHa: convWater,
      totalNewBuiltupHa: newBuiltup,
      projectedAgriHa: Math.round((baseline.agri - convAgri) * 100) / 100,
      projectedBuiltupHa: Math.round((baseline.builtup + newBuiltup) * 100) / 100,
      projectedForestHa: Math.round((baseline.forest - convForest) * 100) / 100,
      projectedWaterHa: Math.round((baseline.water - convWater) * 100) / 100
    });
  }

  // Calculate LARR 2013 Financials
  const calculateLarr = () => {
    const baseValue = areaHa * circleRatePerHa; // Lakhs INR
    const multiplier = isRural ? parseFloat(ruralMultiplier) : 1.0;
    const multipliedCompensation = baseValue * multiplier;
    const solatiumAmount = multipliedCompensation * (solatiumPct / 100.0);
    const totalOutlay = multipliedCompensation + solatiumAmount;

    return {
      baseValue: baseValue.toFixed(2),
      multiplier: multiplier.toFixed(2),
      multipliedCompensation: multipliedCompensation.toFixed(2),
      solatiumAmount: solatiumAmount.toFixed(2),
      totalOutlay: totalOutlay.toFixed(2)
    };
  };

  const larrFinancials = calculateLarr();

  const handleSaveScenario = async () => {
    try {
      setSavingScenario(true);
      await api.createScenario({
        title: scenarioTitle,
        type: activeSubTab === 'markov' ? 'Cellular Automata Urban Expansion' : 'LARR 2013 Statutory Compensation',
        parameters: activeSubTab === 'markov' ? { years, agriRate, ecoProtect } : { areaHa, circleRatePerHa, isRural, ruralMultiplier },
        outcomes: activeSubTab === 'markov' ? simResult : larrFinancials
      });
      alert('Policy Scenario saved and registered to the National Decision Registry! SHA-256 block chained.');
    } catch (err) {
      alert(err.message || 'Failed to save scenario');
    } finally {
      setSavingScenario(false);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Policy What-If & Economic Impact Simulator</h1>
          <p className="page-subtitle">
            Cellular Automata-Markov Urban Transition Modeling & Statutory LARR 2013 Compensation Calculator
          </p>
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          <button 
            className={`btn ${activeSubTab === 'markov' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveSubTab('markov')}
          >
            <Layers size={15} /> Land-Use Transition (CA-Markov)
          </button>
          <button 
            className={`btn ${activeSubTab === 'larr' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveSubTab('larr')}
          >
            <DollarSign size={15} /> LARR 2013 Financial Compensation
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: CA-MARKOV URBAN GROWTH MODEL */}
      {activeSubTab === 'markov' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.2fr) minmax(0, 1.3fr)', gap: '20px' }}>
          
          {/* Controls */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">Policy Levers & Simulation Inputs</span>
              <span className="badge badge-blue">Python Geospatial Engine</span>
            </div>
            <div className="card-body">
              <div className="form-group">
                <label className="form-label">Scenario Name</label>
                <input 
                  type="text" 
                  className="form-control" 
                  value={scenarioTitle}
                  onChange={(e) => setScenarioTitle(e.target.value)}
                />
              </div>

              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <label className="form-label" style={{ marginBottom: 0 }}>Projection Horizon: {years} Years ({2026 + parseInt(years)})</label>
                </div>
                <input 
                  type="range" 
                  min="3" 
                  max="20" 
                  step="1" 
                  value={years}
                  onChange={(e) => setYears(e.target.value)}
                  style={{ width: '100%', accentColor: 'var(--gov-navy-800)' }}
                />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#94a3b8', marginTop: '4px' }}>
                  <span>3 Years (2029)</span>
                  <span>10 Years (2036)</span>
                  <span>20 Years (2046)</span>
                </div>
              </div>

              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <label className="form-label" style={{ marginBottom: 0 }}>
                    Agricultural Conversion Rate: {Math.round(agriRate * 100)}% per 5-Yr Step
                  </label>
                </div>
                <input 
                  type="range" 
                  min="0.05" 
                  max="0.50" 
                  step="0.05" 
                  value={agriRate}
                  onChange={(e) => setAgriRate(parseFloat(e.target.value))}
                  style={{ width: '100%', accentColor: '#d97706' }}
                />
              </div>

              <div style={{ padding: '14px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0', marginBottom: '20px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontSize: '13.5px', fontWeight: 600, color: 'var(--gov-navy-950)' }}>
                  <input 
                    type="checkbox" 
                    checked={ecoProtect}
                    onChange={(e) => setEcoProtect(e.target.checked)}
                    style={{ width: '18px', height: '18px', accentColor: '#059669' }}
                  />
                  <span>Enforce Strict Wetlands & Forest Buffer Protection (2017 Rules)</span>
                </label>
                <p style={{ fontSize: '12px', color: '#64748b', marginTop: '6px', marginLeft: '28px' }}>
                  When enabled, penalizes waterbody and eco-sensitive conversion probabilities by 95% in accordance with Ministry of Environment mandates.
                </p>
              </div>

              <button 
                className="btn btn-primary" 
                onClick={handleSaveScenario}
                disabled={savingScenario}
                style={{ width: '100%' }}
              >
                <Save size={15} /> {savingScenario ? 'Chaining Scenario Block...' : 'Save Scenario to Evidence Dossier'}
              </button>
            </div>
          </div>

          {/* Simulation Output Dashboard */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">Projected LULC Dynamics (Year {simResult?.targetYear})</span>
              <span className="badge badge-green">Cellular Automata Output</span>
            </div>
            <div className="card-body">
              {simResult && (
                <div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '20px' }}>
                    <div style={{ padding: '14px', background: '#eff6ff', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
                      <div style={{ fontSize: '11px', color: '#1d4ed8', fontWeight: 700, textTransform: 'uppercase' }}>New Built-Up Footprint</div>
                      <div style={{ fontSize: '26px', fontWeight: 800, color: '#1e40af', marginTop: '4px' }}>
                        +{simResult.totalNewBuiltupHa} <span style={{ fontSize: '13px' }}>Ha</span>
                      </div>
                      <div style={{ fontSize: '11.5px', color: '#3b82f6', marginTop: '4px' }}>
                        Total Urban Area: {simResult.projectedBuiltupHa} Ha
                      </div>
                    </div>

                    <div style={{ padding: '14px', background: '#fffbeb', borderRadius: '8px', border: '1px solid #fde68a' }}>
                      <div style={{ fontSize: '11px', color: '#b45309', fontWeight: 700, textTransform: 'uppercase' }}>Farmland Conversion</div>
                      <div style={{ fontSize: '26px', fontWeight: 800, color: '#b45309', marginTop: '4px' }}>
                        -{simResult.convertedAgriHa} <span style={{ fontSize: '13px' }}>Ha</span>
                      </div>
                      <div style={{ fontSize: '11.5px', color: '#d97706', marginTop: '4px' }}>
                        Remaining Agri: {simResult.projectedAgriHa} Ha
                      </div>
                    </div>
                  </div>

                  {/* Ecological Preservation Metrics */}
                  <h4 style={{ fontSize: '13px', fontWeight: 700, color: 'var(--gov-navy-900)', textTransform: 'uppercase', marginBottom: '10px' }}>
                    Ecological & Natural Capital Preservation
                  </h4>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '13px' }}>
                      <span style={{ fontWeight: 600, color: '#047857' }}>Conserved Forest Cover</span>
                      <span style={{ fontWeight: 700 }}>{simResult.projectedForestHa} Ha (Loss: -{simResult.convertedForestHa} Ha)</span>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '13px' }}>
                      <span style={{ fontWeight: 600, color: '#0284c7' }}>Protected Water Bodies / Wetlands</span>
                      <span style={{ fontWeight: 700 }}>{simResult.projectedWaterHa} Ha (Loss: {simResult.convertedWaterHa} Ha)</span>
                    </div>
                  </div>

                  <div className="alert-banner alert-info" style={{ marginBottom: 0 }}>
                    <ShieldCheck size={18} style={{ flexShrink: 0 }} />
                    <span style={{ fontSize: '12px' }}>
                      Simulated transitions conform to standard Markov equilibrium models. Policy makers can integrate these projections into regional master plans.
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* SUB-TAB 2: LARR 2013 STATUTORY COMPENSATION CALCULATOR */}
      {activeSubTab === 'larr' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.2fr) minmax(0, 1.3fr)', gap: '20px' }}>
          
          {/* Statutory Inputs */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">Statutory Acquisition Parameters (LARR 2013)</span>
              <span className="badge badge-amber">First Schedule Compliance</span>
            </div>
            <div className="card-body">
              <div className="form-group">
                <label className="form-label">Parcel Extent to Acquire (Hectares)</label>
                <input 
                  type="number" 
                  step="0.1" 
                  className="form-control" 
                  value={areaHa}
                  onChange={(e) => setAreaHa(parseFloat(e.target.value) || 0)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Circle Rate / Market Valuation (INR Lakhs per Hectare)</label>
                <input 
                  type="number" 
                  step="1.0" 
                  className="form-control" 
                  value={circleRatePerHa}
                  onChange={(e) => setCircleRatePerHa(parseFloat(e.target.value) || 0)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Locality Classification</label>
                <div style={{ display: 'flex', gap: '16px', marginTop: '6px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
                    <input 
                      type="radio" 
                      name="loc" 
                      checked={isRural} 
                      onChange={() => setIsRural(true)}
                    />
                    <span>Rural Area (Multiplier 1.0 - 2.0x)</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
                    <input 
                      type="radio" 
                      name="loc" 
                      checked={!isRural} 
                      onChange={() => setIsRural(false)}
                    />
                    <span>Urban Area (Multiplier 1.0x fixed)</span>
                  </label>
                </div>
              </div>

              {isRural && (
                <div className="form-group">
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                    <label className="form-label" style={{ marginBottom: 0 }}>
                      Distance Factor / Rural Multiplier: {ruralMultiplier}x
                    </label>
                  </div>
                  <input 
                    type="range" 
                    min="1.0" 
                    max="2.0" 
                    step="0.1" 
                    value={ruralMultiplier}
                    onChange={(e) => setRuralMultiplier(parseFloat(e.target.value))}
                    style={{ width: '100%', accentColor: 'var(--gov-navy-800)' }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#94a3b8', marginTop: '4px' }}>
                    <span>1.0x (Near Urban Edge)</span>
                    <span>1.5x (Intermediate Radial)</span>
                    <span>2.0x (Deep Interior Rural)</span>
                  </div>
                </div>
              )}

              <div className="form-group">
                <label className="form-label">Statutory Solatium Percentage (Section 30(1))</label>
                <input 
                  type="number" 
                  className="form-control" 
                  value={solatiumPct}
                  disabled
                  style={{ background: '#f1f5f9' }}
                />
                <div style={{ fontSize: '11px', color: '#64748b', marginTop: '4px' }}>
                  Statutory 100% Solatium is non-derogable under the First Schedule of LARR Act 2013.
                </div>
              </div>

              <button 
                className="btn btn-primary" 
                onClick={handleSaveScenario}
                disabled={savingScenario}
                style={{ width: '100%' }}
              >
                <Save size={15} /> Save Financial Assessment
              </button>
            </div>
          </div>

          {/* Statutory Financial Breakdown */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">Statutory Award & Compensation Outlay</span>
              <span className="badge badge-green">Gazette Formula</span>
            </div>
            <div className="card-body">
              <div style={{ background: '#0a2240', color: '#ffffff', padding: '20px', borderRadius: '10px', marginBottom: '20px', textAlign: 'center' }}>
                <div style={{ fontSize: '12px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>
                  Total Estimated Ex-Chequer Outlay
                </div>
                <div style={{ fontSize: '36px', fontWeight: 800, fontFamily: 'var(--font-heading)', color: '#f59e0b', margin: '8px 0' }}>
                  ₹ {larrFinancials.totalOutlay} <span style={{ fontSize: '16px', color: '#cbd5e1' }}>Lakhs</span>
                </div>
                <div style={{ fontSize: '12px', color: '#cbd5e1' }}>
                  (~₹ {(parseFloat(larrFinancials.totalOutlay) / 100).toFixed(3)} Crores)
                </div>
              </div>

              <h4 style={{ fontSize: '13px', fontWeight: 700, color: 'var(--gov-navy-950)', textTransform: 'uppercase', marginBottom: '12px' }}>
                Formula Breakdown (LARR 2013 First Schedule)
              </h4>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '13px' }}>
                  <span>1. Base Market Valuation ({areaHa} Ha × ₹{circleRatePerHa}L)</span>
                  <strong style={{ color: '#1e293b' }}>₹ {larrFinancials.baseValue} Lakhs</strong>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '13px' }}>
                  <span>2. Rural Multiplier Factor ({larrFinancials.multiplier}x)</span>
                  <strong style={{ color: '#1e293b' }}>₹ {larrFinancials.multipliedCompensation} Lakhs</strong>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: '#fef3c7', borderRadius: '6px', border: '1px solid #fde68a', fontSize: '13px' }}>
                  <span style={{ fontWeight: 600, color: '#92400e' }}>3. Mandatory 100% Solatium (Sec 30(1))</span>
                  <strong style={{ color: '#b45309' }}>+ ₹ {larrFinancials.solatiumAmount} Lakhs</strong>
                </div>
              </div>

              <div style={{ marginTop: '20px', padding: '12px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '11.5px', color: '#475569' }}>
                <strong>Collector Discretion Note:</strong> Additional interest under Section 30(3) of 12% per annum from preliminary notification date until possession may apply.
              </div>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
