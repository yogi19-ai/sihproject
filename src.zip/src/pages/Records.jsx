import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  Database, 
  Search, 
  UploadCloud, 
  CheckCircle2, 
  AlertCircle, 
  FileSpreadsheet, 
  Layers, 
  ShieldCheck, 
  X,
  ExternalLink,
  HelpCircle
} from 'lucide-react';

export default function Records() {
  const { user, hasRole } = useAuth();
  const [datasets, setDatasets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [formatFilter, setFormatFilter] = useState('ALL');

  // ULPIN Validator State
  const [testUlpin, setTestUlpin] = useState('MH26000190012A');
  const [validationResult, setValidationResult] = useState(null);
  const [validating, setValidating] = useState(false);

  // Ingestion Modal
  const [showModal, setShowModal] = useState(false);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadDept, setUploadDept] = useState('State Remote Sensing Application Centre');
  const [uploadTheme, setUploadTheme] = useState('LULC Classification');
  const [uploadFormat, setUploadFormat] = useState('GeoJSON');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadDatasets();
    handleValidateUlpin();
  }, [formatFilter]);

  async function loadDatasets() {
    try {
      setLoading(true);
      const params = {};
      if (formatFilter !== 'ALL') params.format = formatFilter;
      const res = await api.getDatasets(params);
      setDatasets(res.datasets || []);
    } catch (err) {
      console.error('[Records] Error loading datasets:', err);
    } finally {
      setLoading(false);
    }
  }

  const handleValidateUlpin = async () => {
    if (!testUlpin.trim()) return;
    try {
      setValidating(true);
      const res = await api.validateUlpinSyntax(testUlpin.trim());
      setValidationResult(res);
    } catch (err) {
      setValidationResult({ valid: false, error: err.message });
    } finally {
      setValidating(false);
    }
  };

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (!uploadTitle.trim()) return;

    try {
      setUploading(true);
      await api.uploadDataset({
        title: uploadTitle,
        sourceDepartment: uploadDept,
        theme: uploadTheme,
        format: uploadFormat,
        recordsCount: 450,
        completenessScore: 98.4
      });
      setShowModal(false);
      setUploadTitle('');
      loadDatasets();
      alert('Dataset successfully ingested and indexed! SHA-256 audit block created.');
    } catch (err) {
      alert(err.message || 'Ingestion failed');
    } finally {
      setUploading(false);
    }
  };

  const filteredDatasets = datasets.filter(d => 
    d.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.sourceDepartment?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.theme?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Digital Land Records & Federated Ingestion</h1>
          <p className="page-subtitle">
            Cross-Departmental Geospatial Registry & 14-Digit Bhu-Aadhaar Syntax Engine
          </p>
        </div>

        {hasRole(['Administrator']) && (
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <UploadCloud size={16} /> Ingest Cross-Agency Dataset
          </button>
        )}
      </div>

      {/* ULPIN (Bhu-Aadhaar) Validation Engine Widget */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <ShieldCheck size={18} color="#0a2240" />
            <span className="card-title">14-Digit ULPIN (Bhu-Aadhaar) Standardization Engine</span>
          </div>
          <span className="badge badge-blue">ISO-7064 & DoLR Guideline</span>
        </div>
        <div className="card-body">
          <p style={{ fontSize: '13px', color: '#475569', marginBottom: '16px' }}>
            The Unique Land Parcel Identification Number (ULPIN) represents a 14-digit alphanumeric code derived from 
            cadastral coordinates and state jurisdiction. Verify syntax conformance below:
          </p>

          <div style={{ display: 'flex', gap: '10px', alignItems: 'center', maxWidth: '600px', marginBottom: '16px' }}>
            <input 
              type="text" 
              className="form-control"
              value={testUlpin}
              onChange={(e) => setTestUlpin(e.target.value.toUpperCase())}
              placeholder="e.g. MH26000190012A"
              maxLength={14}
              style={{ fontFamily: 'monospace', fontSize: '15px', letterSpacing: '1px' }}
            />
            <button className="btn btn-primary" onClick={handleValidateUlpin} disabled={validating}>
              {validating ? 'Verifying...' : 'Validate Standard'}
            </button>
          </div>

          {validationResult && (
            <div style={{ padding: '14px', borderRadius: '8px', background: validationResult.valid ? '#ecfdf5' : '#fef2f2', border: `1px solid ${validationResult.valid ? '#a7f3d0' : '#fecaca'}`, display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
              {validationResult.valid ? (
                <CheckCircle2 size={20} color="#059669" style={{ flexShrink: 0, marginTop: '2px' }} />
              ) : (
                <AlertCircle size={20} color="#dc2626" style={{ flexShrink: 0, marginTop: '2px' }} />
              )}
              <div style={{ fontSize: '13px' }}>
                <div style={{ fontWeight: 700, color: validationResult.valid ? '#065f46' : '#991b1b', marginBottom: '4px' }}>
                  {validationResult.valid ? 'Valid 14-Digit ULPIN Structure' : 'Syntax Non-Conformance'}
                </div>
                <div style={{ color: '#334155' }}>
                  {validationResult.message || validationResult.error}
                </div>
                {validationResult.valid && (
                  <div style={{ marginTop: '8px', fontSize: '11.5px', color: '#64748b' }}>
                    Note: Syntactic validity confirms structural compliance with national standards. Legal property ownership requires certification against stamped physical revenue records.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Datasets Table */}
      <div className="card">
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span className="card-title">Ingested Datasets & Inter-Agency Catalog ({filteredDatasets.length})</span>
            <div style={{ position: 'relative', width: '240px' }}>
              <input 
                type="text" 
                className="form-control"
                placeholder="Filter catalog..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{ height: '34px', fontSize: '12.5px', paddingLeft: '32px' }}
              />
              <Search size={14} style={{ position: 'absolute', left: '10px', top: '10px', color: '#94a3b8' }} />
            </div>
          </div>

          <div style={{ display: 'flex', gap: '6px' }}>
            {['ALL', 'GeoJSON', 'Shapefile', 'CSV', 'GeoTIFF'].map(fmt => (
              <button 
                key={fmt} 
                className={`btn btn-sm ${formatFilter === fmt ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setFormatFilter(fmt)}
              >
                {fmt}
              </button>
            ))}
          </div>
        </div>

        <div className="card-body" style={{ padding: 0 }}>
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Dataset Name & Scope</th>
                  <th>Source Department</th>
                  <th>Format</th>
                  <th>Records</th>
                  <th>Spatial CRS</th>
                  <th>Integrity Score</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredDatasets.map(ds => (
                  <tr key={ds.id}>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{ds.title}</div>
                      <div style={{ fontSize: '11.5px', color: '#64748b' }}>{ds.description || ds.theme}</div>
                    </td>
                    <td>
                      <span style={{ fontSize: '12.5px', color: '#334155' }}>{ds.sourceDepartment}</span>
                    </td>
                    <td>
                      <span className="badge badge-purple">{ds.format}</span>
                    </td>
                    <td style={{ fontWeight: 600 }}>{ds.recordsCount?.toLocaleString() || '-'}</td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontSize: '12px' }}>{ds.crs || 'EPSG:4326'}</span>
                    </td>
                    <td>
                      <span className="badge badge-green">
                        <CheckCircle2 size={12} /> {ds.completenessScore || 99}%
                      </span>
                    </td>
                    <td>
                      <span className="badge badge-blue">Synchronized</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Ingestion Modal */}
      {showModal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Ingest Inter-Agency Cadastral Dataset
              </h3>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleUploadSubmit}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Dataset Title *</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    placeholder="e.g. Pune Urban Cadastral Zone Boundary Survey 2026"
                    value={uploadTitle}
                    onChange={(e) => setUploadTitle(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Source Agency / Department *</label>
                  <select 
                    className="form-control"
                    value={uploadDept}
                    onChange={(e) => setUploadDept(e.target.value)}
                  >
                    <option value="State Remote Sensing Application Centre">State Remote Sensing Application Centre</option>
                    <option value="Department of Revenue & Land Records">Department of Revenue & Land Records</option>
                    <option value="Forest Survey of India">Forest Survey of India</option>
                    <option value="Central Ground Water Board">Central Ground Water Board</option>
                    <option value="Town Planning & Valuation Directorate">Town Planning & Valuation Directorate</option>
                  </select>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  <div className="form-group">
                    <label className="form-label">Thematic Domain</label>
                    <input 
                      type="text" 
                      className="form-control"
                      value={uploadTheme}
                      onChange={(e) => setUploadTheme(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Payload Format</label>
                    <select 
                      className="form-control"
                      value={uploadFormat}
                      onChange={(e) => setUploadFormat(e.target.value)}
                    >
                      <option value="GeoJSON">GeoJSON</option>
                      <option value="Shapefile">Shapefile (.zip)</option>
                      <option value="CSV">CSV / Tabular</option>
                      <option value="GeoTIFF">GeoTIFF (Raster)</option>
                    </select>
                  </div>
                </div>

                <div className="alert-banner alert-info" style={{ marginTop: '10px' }}>
                  <ShieldCheck size={16} />
                  <span>Submitting triggers an automated SHA-256 hash calculation and logs an immutable audit event.</span>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={uploading}>
                  {uploading ? 'Processing & Ingesting...' : 'Confirm Ingestion'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
