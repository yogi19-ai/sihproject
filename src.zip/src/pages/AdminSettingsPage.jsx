import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  Activity, 
  CheckCircle2, 
  Server, 
  Database, 
  ShieldCheck, 
  Cpu, 
  Layers,
  Lock,
  UserCheck
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function AdminSettingsPage() {
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user, availableDemoUsers, switchDemoUser } = useAuth();

  useEffect(() => {
    loadHealth();
  }, []);

  const loadHealth = async () => {
    try {
      setLoading(true);
      const res = await api.getHealth();
      setHealth(res);
    } catch (err) {
      console.error('[AdminSettings] Health check error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Administration & System Health</h1>
          <p className="page-subtitle">
            Diagnostic telemetry, subsystem statuses, three-tier RBAC configuration, and microservice connectivity.
          </p>
        </div>
        <button className="btn btn-secondary btn-sm" onClick={loadHealth}>
          Refresh Health Checks
        </button>
      </div>

      {/* Subsystem Health Cards */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <div className="card-header">
          <div className="card-title">Subsystem Operational Health</div>
          <span className="badge badge-green">All Subsystems Operational</span>
        </div>
        <div className="card-body">
          {health ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '16px' }}>
              <div style={{ padding: '16px', background: 'var(--bg-subtle)', borderRadius: '8px', border: '1px solid var(--border-light)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                  <Server size={18} color="#059669" />
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>Core API Service</div>
                </div>
                <div style={{ fontSize: '12.5px', color: '#64748b' }}>
                  Status: <strong style={{ color: '#059669' }}>{health.subsystems?.apiServer?.status}</strong> (Port {health.subsystems?.apiServer?.port})
                </div>
                <div style={{ fontSize: '11.5px', color: '#94a3b8', marginTop: '4px' }}>Express.js Engine v1.0.0</div>
              </div>

              <div style={{ padding: '16px', background: 'var(--bg-subtle)', borderRadius: '8px', border: '1px solid var(--border-light)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                  <Database size={18} color="#059669" />
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>Spatial Database Adapter</div>
                </div>
                <div style={{ fontSize: '12.5px', color: '#64748b' }}>
                  Engine: <strong>{health.subsystems?.databaseAdapter?.engine}</strong>
                </div>
                <div style={{ fontSize: '11.5px', color: '#059669', marginTop: '4px' }}>
                  {health.subsystems?.databaseAdapter?.totalParcelsIndexed} Cadastral Parcels Indexed
                </div>
              </div>

              <div style={{ padding: '16px', background: 'var(--bg-subtle)', borderRadius: '8px', border: '1px solid var(--border-light)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                  <ShieldCheck size={18} color="#059669" />
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>SHA-256 Audit Ledger</div>
                </div>
                <div style={{ fontSize: '12.5px', color: '#64748b' }}>
                  Status: <strong style={{ color: '#059669' }}>{health.subsystems?.auditLedger?.status}</strong>
                </div>
                <div style={{ fontSize: '11.5px', color: '#94a3b8', marginTop: '4px' }}>
                  {health.subsystems?.auditLedger?.totalBlocks} Blocks Sequenced
                </div>
              </div>

              <div style={{ padding: '16px', background: 'var(--bg-subtle)', borderRadius: '8px', border: '1px solid var(--border-light)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                  <Cpu size={18} color="#059669" />
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>Python AI Microservice</div>
                </div>
                <div style={{ fontSize: '12.5px', color: '#64748b' }}>
                  Status: <strong style={{ color: '#059669' }}>{health.subsystems?.pyGeoAiService?.status}</strong>
                </div>
                <div style={{ fontSize: '11.5px', color: '#94a3b8', marginTop: '4px' }}>
                  {health.subsystems?.pyGeoAiService?.url}
                </div>
              </div>
            </div>
          ) : (
            <p>Loading telemetry...</p>
          )}
        </div>
      </div>

      {/* Role Switcher & RBAC Matrix */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">Three-Tier Role-Based Access Control (RBAC) Simulator</div>
        </div>
        <div className="card-body">
          <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
            Select any simulated identity below to test permission gating across the platform:
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
            {availableDemoUsers.map(u => (
              <div 
                key={u.email}
                style={{
                  padding: '16px',
                  borderRadius: '8px',
                  border: user?.email === u.email ? '2px solid var(--gov-navy-800)' : '1px solid var(--border-light)',
                  background: user?.email === u.email ? 'var(--bg-subtle)' : '#ffffff'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
                  <span className={`badge ${u.role === 'Administrator' ? 'badge-amber' : (u.role === 'Researcher' ? 'badge-blue' : 'badge-green')}`}>
                    {u.role} Tier
                  </span>
                  {user?.email === u.email && (
                    <span style={{ fontSize: '11.5px', fontWeight: 700, color: '#059669' }}>Active Identity</span>
                  )}
                </div>

                <div style={{ fontWeight: 700, fontSize: '14px', color: 'var(--gov-navy-950)', marginBottom: '2px' }}>
                  {u.name}
                </div>
                <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '12px' }}>
                  {u.dept} ({u.email})
                </div>

                <button 
                  className="btn btn-secondary btn-sm"
                  style={{ width: '100%' }}
                  onClick={() => switchDemoUser(u.email)}
                >
                  <UserCheck size={14} />
                  Switch to this Persona
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
