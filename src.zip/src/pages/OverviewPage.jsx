import React, { useState, useEffect } from 'react';
import { 
  Database, 
  MapPin, 
  FileCheck2, 
  Lightbulb, 
  Sliders, 
  TrendingUp, 
  Layers, 
  Info,
  Clock,
  ArrowRight
} from 'lucide-react';
import { api } from '../services/api';

export default function OverviewPage({ setActiveTab }) {
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stateFilter, setStateFilter] = useState('ALL');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await api.getNationalOverview();
      setOverview(data);
    } catch (err) {
      console.error('[OverviewPage] Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !overview) {
    return (
      <div className="page-container" style={{ padding: '40px', textAlign: 'center' }}>
        <p style={{ color: '#64748b' }}>Loading National Land Governance metrics...</p>
      </div>
    );
  }

  const cards = overview.summaryCards || {};
  const landUse = overview.landUseBreakdown || {};

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">National Land Governance Overview</h1>
          <p className="page-subtitle">
            Executive intelligence dashboard tracking cadastral records, geospatial datasets, policy evidence, and innovation initiatives.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <select 
            className="form-control" 
            style={{ width: '180px', height: '38px', fontSize: '13px' }}
            value={stateFilter}
            onChange={(e) => setStateFilter(e.target.value)}
          >
            <option value="ALL">All Covered States</option>
            <option value="Maharashtra">Maharashtra</option>
            <option value="Uttar Pradesh">Uttar Pradesh</option>
            <option value="Karnataka">Karnataka</option>
            <option value="Gujarat">Gujarat</option>
            <option value="Odisha">Odisha</option>
          </select>
        </div>
      </div>

      <div className="alert-banner alert-info">
        <Info size={18} style={{ flexShrink: 0, marginTop: '2px' }} />
        <div>
          <strong>Statutory Compliance & Demonstration Notice:</strong> {overview.demonstrationNotice} Syntactic conformity with 14-digit ULPIN guidelines does not constitute judicial title or clear ownership under the Registration Act, 1908.
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Mapped Parcels</span>
            <div className="kpi-icon-wrapper"><MapPin size={18} /></div>
          </div>
          <div className="kpi-value">{cards.totalParcels}</div>
          <div className="kpi-subtext">Georeferenced cadastral boundaries</div>
        </div>

        <div className="kpi-card kpi-accent">
          <div className="kpi-header">
            <span className="kpi-label">Total Mapped Area</span>
            <div className="kpi-icon-wrapper"><Layers size={18} /></div>
          </div>
          <div className="kpi-value">{cards.totalMappedHectares} <span style={{ fontSize: '14px', fontWeight: 500 }}>Ha</span></div>
          <div className="kpi-subtext">{cards.totalMappedAcres} Acres total</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Ingested Datasets</span>
            <div className="kpi-icon-wrapper"><Database size={18} /></div>
          </div>
          <div className="kpi-value">{cards.totalDatasets}</div>
          <div className="kpi-subtext">Bhulekh, Bhuvan & PM GatiShakti</div>
        </div>

        <div className="kpi-card kpi-green">
          <div className="kpi-header">
            <span className="kpi-label">Statutory Acts</span>
            <div className="kpi-icon-wrapper"><FileCheck2 size={18} /></div>
          </div>
          <div className="kpi-value">{cards.totalStatutoryActs}</div>
          <div className="kpi-subtext">Indexed for RAG semantic search</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Policy Scenarios</span>
            <div className="kpi-icon-wrapper"><Sliders size={18} /></div>
          </div>
          <div className="kpi-value">{cards.policyScenariosCreated}</div>
          <div className="kpi-subtext">Cellular Automata & Markov models</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Innovation Pilots</span>
            <div className="kpi-icon-wrapper"><Lightbulb size={18} /></div>
          </div>
          <div className="kpi-value">{cards.activeInnovationProposals}</div>
          <div className="kpi-subtext">Grants & hackathon challenges</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '24px' }}>
        {/* Land-Use Breakdown */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Land-Use Classification Breakdown</div>
            <span className="badge badge-blue">Multi-Temporal Satellite Classification</span>
          </div>
          <div className="card-body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {Object.entries(landUse).map(([cls, count]) => {
                const total = Object.values(landUse).reduce((a, b) => a + b, 0);
                const pct = Math.round((count / total) * 100);
                return (
                  <div key={cls}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '4px' }}>
                      <span style={{ fontWeight: 500, color: 'var(--text-main)' }}>{cls}</span>
                      <span style={{ color: 'var(--text-muted)' }}>{count} parcels ({pct}%)</span>
                    </div>
                    <div style={{ width: '100%', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                      <div 
                        style={{ 
                          width: `${pct}%`, 
                          height: '100%', 
                          background: cls.includes('Forest') ? '#059669' : (cls.includes('Agri') ? '#d97706' : (cls.includes('Wetland') ? '#2563eb' : '#0f2f57'))
                        }} 
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* State-Wise Coverage */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">State-Level Ingestion Coverage</div>
            <button className="btn btn-secondary btn-sm" onClick={() => setActiveTab('records')}>
              View Catalogue
            </button>
          </div>
          <div className="card-body">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>State Jurisdiction</th>
                    <th>Parcels Indexed</th>
                    <th>Integration Status</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(overview.stateBreakdown || {}).map(([stateName, count]) => (
                    <tr key={stateName}>
                      <td style={{ fontWeight: 600 }}>{stateName}</td>
                      <td>{count} Demonstration Parcels</td>
                      <td>
                        <span className="badge badge-green">Connected (WFS / RoR)</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Datasets & Activity */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '24px' }}>
        <div className="card">
          <div className="card-header">
            <div className="card-title">Recently Ingested Datasets</div>
            <button className="btn btn-primary btn-sm" onClick={() => setActiveTab('records')}>
              Open Data Catalogue
            </button>
          </div>
          <div className="card-body" style={{ padding: '0' }}>
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Dataset Title</th>
                    <th>Agency</th>
                    <th>Format</th>
                    <th>Quality</th>
                  </tr>
                </thead>
                <tbody>
                  {(overview.recentDatasets || []).map(ds => (
                    <tr key={ds.id}>
                      <td style={{ fontWeight: 500 }}>{ds.title}</td>
                      <td style={{ fontSize: '12px', color: '#64748b' }}>{ds.sourceAgency}</td>
                      <td><span className="badge badge-amber">{ds.format}</span></td>
                      <td style={{ fontWeight: 600, color: '#059669' }}>{ds.qualityScore}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div className="card-title">SHA-256 Tamper-Evident Ledger</div>
            <button className="btn btn-secondary btn-sm" onClick={() => setActiveTab('audit')}>
              Verify Chain
            </button>
          </div>
          <div className="card-body" style={{ padding: '16px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {(overview.recentActivity || []).slice(0, 4).map(act => (
                <div key={act.index} style={{ padding: '10px', background: 'var(--bg-subtle)', borderRadius: '6px', fontSize: '12.5px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                    <span style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{act.action}</span>
                    <span style={{ color: 'var(--text-muted)', fontSize: '11px' }}>
                      <Clock size={11} style={{ display: 'inline', marginRight: '3px' }} />
                      {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div style={{ fontSize: '11px', fontFamily: 'monospace', color: '#64748b', wordBreak: 'break-all' }}>
                    Hash: {act.currentHash?.substring(0, 24)}...
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
