import React, { useState, useEffect } from 'react';
import { 
  Satellite, 
  TrendingUp, 
  AlertCircle, 
  Info, 
  Sliders, 
  Layers, 
  ArrowUpRight, 
  ArrowDownRight,
  Download
} from 'lucide-react';
import { api } from '../services/api';

export default function GeoAnalyticsPage() {
  const [workspace, setWorkspace] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSensor, setSelectedSensor] = useState('Sentinel-2 / Resourcesat-2A');
  const [selectedRegion, setSelectedRegion] = useState('Maharashtra - Pune Corridor');

  useEffect(() => {
    loadAnalytics();
  }, [selectedSensor, selectedRegion]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const res = await api.getAnalyticsWorkspace({ region: selectedRegion, sensor: selectedSensor });
      setWorkspace(res);
    } catch (err) {
      console.error('[GeoAnalytics] Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !workspace) {
    return (
      <div className="page-container" style={{ padding: '40px', textAlign: 'center' }}>
        <p style={{ color: '#64748b' }}>Computing satellite spectral indices and LULC matrix...</p>
      </div>
    );
  }

  const { metrics, lulcChangeMatrix, ndviHistogram, methodology } = workspace;

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Geo-Analytics & Satellite Workspace</h1>
          <p className="page-subtitle">
            Biophysical vegetation health (NDVI), surface moisture (NDWI), and multi-temporal land-use change detection.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <select 
            className="form-control" 
            style={{ width: '220px' }}
            value={selectedRegion}
            onChange={(e) => setSelectedRegion(e.target.value)}
          >
            <option value="Maharashtra - Pune Corridor">Maharashtra - Pune Corridor</option>
            <option value="UP - Jewar Aerotropolis Fringe">UP - Jewar Aerotropolis Fringe</option>
            <option value="Karnataka - Bellandur Basin">Karnataka - Bellandur Basin</option>
          </select>
        </div>
      </div>

      <div className="alert-banner alert-info">
        <Info size={18} style={{ flexShrink: 0 }} />
        <div>
          <strong>Scientific Methodology & Indicator Notice:</strong> {workspace.disclaimer} {methodology.ndviFormula}; {methodology.ndwiFormula}.
        </div>
      </div>

      {/* KPI Spectral Metrics */}
      <div className="kpi-grid">
        <div className="kpi-card kpi-green">
          <div className="kpi-header">
            <span className="kpi-label">Average NDVI Index</span>
            <div className="kpi-icon-wrapper"><Satellite size={18} /></div>
          </div>
          <div className="kpi-value">{metrics.averageNdvi}</div>
          <div className="kpi-subtext">Normalized Difference Vegetation Index</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Average NDWI Index</span>
            <div className="kpi-icon-wrapper"><Layers size={18} /></div>
          </div>
          <div className="kpi-value">{metrics.averageNdwi}</div>
          <div className="kpi-subtext">Normalized Difference Water Index</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Analyzed Territory</span>
            <div className="kpi-icon-wrapper"><Sliders size={18} /></div>
          </div>
          <div className="kpi-value">{metrics.totalAreaAnalyzedHa} <span style={{ fontSize: '14px' }}>Ha</span></div>
          <div className="kpi-subtext">Sentinel-2 Orthorectified Area</div>
        </div>

        <div className="kpi-card kpi-accent">
          <div className="kpi-header">
            <span className="kpi-label">Vegetation Status</span>
            <div className="kpi-icon-wrapper"><TrendingUp size={18} /></div>
          </div>
          <div className="kpi-value" style={{ fontSize: '18px' }}>{metrics.vegetationStressScore}</div>
          <div className="kpi-subtext">Pre-Monsoon Satellite Composite</div>
        </div>
      </div>

      {/* LULC Change Detection Matrix Table */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">Multi-Temporal Land-Use / Land-Cover (LULC) Change Matrix</div>
          <span className="badge badge-amber">Baseline 2021 vs Current 2026</span>
        </div>
        <div className="card-body" style={{ padding: '0' }}>
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>LULC Classification Class</th>
                  <th>2021 Baseline (Ha)</th>
                  <th>2026 Current (Ha)</th>
                  <th>Net Change (Ha)</th>
                  <th>Growth Rate (%)</th>
                  <th>Primary Transition Factor</th>
                </tr>
              </thead>
              <tbody>
                {lulcChangeMatrix.map((item, idx) => (
                  <tr key={idx}>
                    <td style={{ fontWeight: 600 }}>{item.class}</td>
                    <td>{item.baseline2021Ha.toLocaleString()} Ha</td>
                    <td style={{ fontWeight: 600 }}>{item.current2026Ha.toLocaleString()} Ha</td>
                    <td style={{ color: item.netChangeHa >= 0 ? '#059669' : '#b91c1c', fontWeight: 600 }}>
                      {item.netChangeHa >= 0 ? `+${item.netChangeHa}` : item.netChangeHa} Ha
                    </td>
                    <td>
                      <span className={`badge ${item.netChangePct >= 0 ? 'badge-green' : 'badge-red'}`}>
                        {item.netChangePct >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                        {Math.abs(item.netChangePct)}%
                      </span>
                    </td>
                    <td style={{ fontSize: '12.5px', color: '#64748b' }}>{item.primaryDriver}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* NDVI Histogram & Spectral Distribution */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
        <div className="card">
          <div className="card-header">
            <div className="card-title">NDVI Spectral Histogram & Biomass Density</div>
          </div>
          <div className="card-body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {ndviHistogram.map((bin, idx) => (
                <div key={idx}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', marginBottom: '4px' }}>
                    <span style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{bin.label}</span>
                    <span style={{ color: 'var(--text-muted)' }}>{bin.range} ({bin.count} Clusters)</span>
                  </div>
                  <div style={{ width: '100%', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                    <div 
                      style={{ 
                        width: `${bin.count * 2}%`, 
                        height: '100%', 
                        background: idx === 0 ? '#0284c7' : (idx === 1 ? '#64748b' : (idx === 2 ? '#d97706' : (idx === 3 ? '#65a30d' : '#059669')))
                      }} 
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div className="card-title">Satellite Sensor & Processing Pipeline</div>
          </div>
          <div className="card-body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '13px' }}>
              <div>
                <strong>Primary Constellation:</strong> Copernicus Sentinel-2 MSI & ISRO Resourcesat-2A LISS-IV
              </div>
              <div>
                <strong>Ground Sampling Distance (GSD):</strong> 10m Multispectral / 5.8m LISS-IV
              </div>
              <div>
                <strong>Atmospheric Processing:</strong> Sen2Cor Bottom-Of-Atmosphere (BOA) Surface Reflectance
              </div>
              <div>
                <strong>Cloud & Shadow Masking:</strong> Automated Scene Classification Layer (SCL &gt; 98% clear)
              </div>
              <div>
                <strong>Coordinate Reference System:</strong> EPSG:4326 (WGS84 Lat/Lng) / UTM Zone 43N
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
