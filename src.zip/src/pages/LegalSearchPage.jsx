import React, { useState, useEffect } from 'react';
import { 
  Search, 
  BookOpen, 
  FileText, 
  CheckCircle2, 
  AlertTriangle, 
  Scale, 
  ShieldCheck, 
  Info,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';

export default function LegalSearchPage() {
  const [query, setQuery] = useState('What is the mandatory solatium percentage and rural multiplier under LARR Act 2013?');
  const [actFilter, setActFilter] = useState('ALL');
  const [acts, setActs] = useState([]);
  const [searchResult, setSearchResult] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadActs();
    performSearch(query);
  }, []);

  const loadActs = async () => {
    try {
      const res = await api.getStatutoryActs();
      setActs(res.acts || []);
    } catch (err) {
      console.error('[LegalSearch] Load acts error:', err);
    }
  };

  const performSearch = async (searchQuery) => {
    if (!searchQuery.trim()) return;
    try {
      setLoading(true);
      const res = await api.searchLegalEvidence(searchQuery, actFilter);
      setSearchResult(res);
    } catch (err) {
      console.error('[LegalSearch] Search error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    performSearch(query);
  };

  const sampleQueries = [
    'What is the mandatory solatium percentage and rural multiplier under LARR Act 2013?',
    'What are the restrictions on eviction under Forest Rights Act (FRA 2006)?',
    'What activities are prohibited in wetland buffer zones under Wetlands Rules 2017?',
    'Does allotment of a 14-digit ULPIN confer judicial ownership or clear title?'
  ];

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Research & Legal Evidence Assistant</h1>
          <p className="page-subtitle">
            Grounded statutory retrieval engine with hybrid BM25 + dense vector ranking and verified citation evaluation (&gt;0.85 threshold).
          </p>
        </div>
      </div>

      <div className="alert-banner alert-warning">
        <Scale size={18} style={{ flexShrink: 0 }} />
        <div>
          <strong>Statutory AI Disclaimer:</strong> This assistant retrieves and cross-checks official provisions of the LARR Act 2013, Forest Rights Act 2006, Wetlands Rules 2017, and ULPIN Guidelines. It strictly evaluates citations against verifiable source text and does NOT constitute formal legal advice.
        </div>
      </div>

      {/* Query Bar */}
      <div className="card" style={{ padding: '24px', marginBottom: '24px' }}>
        <form onSubmit={handleFormSubmit}>
          <div style={{ display: 'flex', gap: '12px', marginBottom: '14px' }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <input
                type="text"
                className="form-control"
                style={{ height: '46px', fontSize: '14px', paddingLeft: '40px' }}
                placeholder="Ask any statutory question on land acquisition, forest rights, wetland buffers, or ULPIN..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <Search size={18} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
            </div>

            <select
              className="form-control"
              style={{ width: '220px', height: '46px' }}
              value={actFilter}
              onChange={(e) => setActFilter(e.target.value)}
            >
              <option value="ALL">All Statutory Acts</option>
              <option value="LARR">LARR Act 2013</option>
              <option value="Forest">Forest Rights Act 2006</option>
              <option value="Wetlands">Wetlands Rules 2017</option>
              <option value="ULPIN">ULPIN Standards 2021</option>
            </select>

            <button type="submit" className="btn btn-primary" style={{ padding: '0 24px' }} disabled={loading}>
              {loading ? 'Retrieving Evidence...' : 'Search'}
            </button>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)' }}>Suggested Inquiries:</span>
            {sampleQueries.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setQuery(q);
                  performSearch(q);
                }}
                style={{
                  background: 'var(--bg-subtle)',
                  border: '1px solid var(--border-light)',
                  borderRadius: 'var(--radius-full)',
                  padding: '4px 10px',
                  fontSize: '11.5px',
                  color: 'var(--gov-navy-900)',
                  cursor: 'pointer'
                }}
              >
                {q}
              </button>
            ))}
          </div>
        </form>
      </div>

      {/* Synthesis & Evidence Results */}
      {searchResult && (
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '24px' }}>
          {/* Grounded Synthesis */}
          <div className="card">
            <div className="card-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Sparkles size={18} color="#d97706" />
                <div className="card-title">Evidence-Grounded Legal Synthesis</div>
              </div>

              {/* Citation Verification Target Evaluation */}
              <div>
                <span 
                  className={`badge ${searchResult.isGroundingVerified ? 'badge-green' : 'badge-amber'}`}
                  title={`Citation Verification Threshold: ${searchResult.verificationThreshold}`}
                >
                  <ShieldCheck size={13} />
                  Grounding Score: {searchResult.groundingScore} / 1.0 ({searchResult.statusLabel})
                </span>
              </div>
            </div>

            <div className="card-body">
              <div style={{ fontSize: '14.5px', lineHeight: '1.7', color: 'var(--text-main)', marginBottom: '20px' }}>
                {searchResult.synthesis}
              </div>

              <div style={{ padding: '14px', background: 'var(--bg-subtle)', borderRadius: '8px', border: '1px solid var(--border-light)', fontSize: '12.5px' }}>
                <div style={{ fontWeight: 600, color: 'var(--gov-navy-900)', marginBottom: '4px' }}>
                  Verification Target Metric Explanation (&gt;0.85):
                </div>
                <div style={{ color: 'var(--text-muted)', lineHeight: '1.4' }}>
                  The Citation Grounding Score evaluates exact n-gram and legal entity overlap between the synthesized answer and the statutory sections retrieved from the knowledge base. A score &ge; 0.85 satisfies the strict non-hallucination benchmark prescribed for public policy research.
                </div>
              </div>
            </div>
          </div>

          {/* Direct Statutory Citations */}
          <div className="card">
            <div className="card-header">
              <div className="card-title">Direct Statutory Citations ({searchResult.citations?.length || 0})</div>
            </div>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {(searchResult.citations || []).map((cite, idx) => (
                <div 
                  key={idx}
                  style={{ 
                    padding: '14px', 
                    borderRadius: '8px', 
                    border: '1px solid var(--border-light)',
                    background: '#ffffff',
                    boxShadow: 'var(--shadow-sm)'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
                    <div style={{ fontWeight: 700, fontSize: '13.5px', color: 'var(--gov-navy-900)' }}>
                      {cite.sectionNumber}: {cite.sectionTitle}
                    </div>
                    <span className="badge badge-blue">Page {cite.pageNumber}</span>
                  </div>

                  <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '8px' }}>
                    {cite.actTitle} ({cite.issuingAuthority})
                  </div>

                  <div style={{ fontSize: '12.5px', color: 'var(--text-secondary)', fontStyle: 'italic', background: 'var(--bg-subtle)', padding: '8px', borderRadius: '4px', borderLeft: '3px solid var(--gov-saffron-500)' }}>
                    "{cite.excerpt}"
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Indexed Acts Reference Library */}
      <div className="card" style={{ marginTop: '24px' }}>
        <div className="card-header">
          <div className="card-title">Indexed Statutory Acts & Guidelines Library</div>
        </div>
        <div className="card-body">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
            {acts.map(act => (
              <div key={act.id} style={{ padding: '16px', borderRadius: '8px', border: '1px solid var(--border-light)', background: 'var(--bg-subtle)' }}>
                <div style={{ fontWeight: 600, fontSize: '14px', color: 'var(--gov-navy-900)', marginBottom: '4px' }}>
                  {act.shortName}
                </div>
                <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '8px' }}>
                  {act.issuingAuthority} • {act.year}
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                  {act.chunks?.length || 0} indexed statutory clauses available for semantic grounding.
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
