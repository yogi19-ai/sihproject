import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  Search, 
  Layers, 
  MapPin, 
  Filter, 
  CheckCircle, 
  X, 
  Info, 
  ShieldAlert, 
  Maximize2,
  ExternalLink,
  Edit3
} from 'lucide-react';

export default function WebGIS() {
  const { user, hasRole } = useAuth();
  const [parcels, setParcels] = useState([]);
  const [selectedParcel, setSelectedParcel] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [landUseFilter, setLandUseFilter] = useState('ALL');
  const [scaleDemo, setScaleDemo] = useState(false);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState(false);
  const [verifyStatus, setVerifyStatus] = useState('Verified');
  const [verifyRemarks, setVerifyRemarks] = useState('');

  // Fetch parcels
  useEffect(() => {
    loadParcels();
  }, [landUseFilter, scaleDemo]);

  async function loadParcels() {
    try {
      setLoading(true);
      const params = {
        limit: 200,
        scaleDemo: scaleDemo ? 1000 : 0
      };
      if (landUseFilter !== 'ALL') {
        params.landUseClass = landUseFilter;
      }
      const res = await api.getParcelsByBbox(params);
      setParcels(res.parcels || []);
      if (!selectedParcel && res.parcels && res.parcels.length > 0) {
        setSelectedParcel(res.parcels[0]);
      }
    } catch (err) {
      console.error('[WebGIS] Error fetching parcels:', err);
    } finally {
      setLoading(false);
    }
  }

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    try {
      setLoading(true);
      const res = await api.getParcelByUlpin(searchQuery.trim().toUpperCase());
      if (res.parcel) {
        setSelectedParcel(res.parcel);
      } else {
        // Search in local parcels by survey number or village
        const found = parcels.find(p => 
          p.ulpin?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.surveyNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.village?.toLowerCase().includes(searchQuery.toLowerCase())
        );
        if (found) setSelectedParcel(found);
        else alert('No parcel found matching ULPIN / Survey: ' + searchQuery);
      }
    } catch (err) {
      alert('Parcel query error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    if (!selectedParcel) return;
    try {
      setVerifying(true);
      const res = await api.updateParcelVerification(
        selectedParcel.ulpin, 
        verifyStatus, 
        verifyRemarks || 'Verified by Land Revenue Officer during field inspection.'
      );
      setSelectedParcel(res.parcel);
      // update in list
      setParcels(prev => prev.map(p => p.ulpin === res.parcel.ulpin ? res.parcel : p));
      alert(`Parcel ${selectedParcel.ulpin} verification status updated to ${verifyStatus}! Cryptographic audit record created.`);
    } catch (err) {
      alert(err.message || 'Verification update failed');
    } finally {
      setVerifying(false);
    }
  };

  // Color mapping by land use
  const getParcelColor = (lu) => {
    if (!lu) return '#64748b';
    if (lu.includes('Agri')) return '#059669';
    if (lu.includes('Residential')) return '#2563eb';
    if (lu.includes('Industrial') || lu.includes('Commercial')) return '#d97706';
    if (lu.includes('Forest')) return '#047857';
    if (lu.includes('Water') || lu.includes('Wetland')) return '#0284c7';
    return '#64748b';
  };

  return (
    <div className="page-container" style={{ paddingBottom: '10px' }}>
      <div className="page-header" style={{ marginBottom: '16px' }}>
        <div>
          <h1 className="page-title">Cadastral WebGIS & Spatial Boundary Explorer</h1>
          <p className="page-subtitle">
            14-Digit ULPIN (Bhu-Aadhaar) Geospatial Geometry & Revenue Attribute Integration
          </p>
        </div>

        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button 
            className={`btn ${scaleDemo ? 'btn-accent' : 'btn-secondary'}`}
            onClick={() => setScaleDemo(!scaleDemo)}
            title="Simulate 1,000+ parcels simultaneously to benchmark spatial engine throughput"
          >
            <Layers size={15} /> {scaleDemo ? 'Dense Demo Active (1,000+ Parcels)' : 'Benchmark 1,000+ Parcels'}
          </button>
        </div>
      </div>

      {/* WebGIS Viewport Frame */}
      <div className="gis-container" style={{ position: 'relative', height: 'calc(100vh - 190px)', minHeight: '550px' }}>
        
        {/* Map Interactive Canvas */}
        <div style={{ flex: 1, position: 'relative', background: '#0b192c', overflow: 'hidden' }}>
          
          {/* Controls overlay */}
          <div className="gis-controls-overlay">
            <form onSubmit={handleSearch} className="gis-search-box">
              <Search size={16} color="#64748b" />
              <input 
                type="text" 
                placeholder="Search ULPIN (e.g. MH26000190012A) or Survey No..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button type="submit" className="btn btn-sm btn-primary" style={{ padding: '3px 8px' }}>Locate</button>
            </form>

            <div className="gis-layer-panel">
              <div className="gis-layer-title">Land-Use Filter</div>
              <div 
                className="gis-layer-item" 
                onClick={() => setLandUseFilter('ALL')}
                style={{ fontWeight: landUseFilter === 'ALL' ? '700' : '400' }}
              >
                <div className="gis-layer-color-dot" style={{ background: '#ffffff', border: '1px solid #94a3b8' }}></div>
                <span>All Classifications ({parcels.length})</span>
              </div>
              <div 
                className="gis-layer-item" 
                onClick={() => setLandUseFilter('Agricultural (Irrigated / Rainfed)')}
                style={{ fontWeight: landUseFilter.includes('Agri') ? '700' : '400' }}
              >
                <div className="gis-layer-color-dot" style={{ background: '#059669' }}></div>
                <span>Agricultural</span>
              </div>
              <div 
                className="gis-layer-item" 
                onClick={() => setLandUseFilter('Residential & Urban Habitation')}
                style={{ fontWeight: landUseFilter.includes('Resi') ? '700' : '400' }}
              >
                <div className="gis-layer-color-dot" style={{ background: '#2563eb' }}></div>
                <span>Residential Habitation</span>
              </div>
              <div 
                className="gis-layer-item" 
                onClick={() => setLandUseFilter('Industrial & Commercial Corridor')}
                style={{ fontWeight: landUseFilter.includes('Ind') ? '700' : '400' }}
              >
                <div className="gis-layer-color-dot" style={{ background: '#d97706' }}></div>
                <span>Industrial / Commercial</span>
              </div>
              <div 
                className="gis-layer-item" 
                onClick={() => setLandUseFilter('Forest & Eco-Sensitive')}
                style={{ fontWeight: landUseFilter.includes('Forest') ? '700' : '400' }}
              >
                <div className="gis-layer-color-dot" style={{ background: '#047857' }}></div>
                <span>Forest & Eco-Sensitive</span>
              </div>
            </div>
          </div>

          {/* Map Vector Visualization Canvas */}
          <div style={{ width: '100%', height: '100%', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg 
              viewBox="0 0 1000 700" 
              style={{ width: '100%', height: '100%', background: 'radial-gradient(ellipse at center, #132742 0%, #07172b 100%)' }}
            >
              {/* Background Cadastral Grid lines */}
              <defs>
                <pattern id="cadastralGrid" width="60" height="60" patternUnits="userSpaceOnUse">
                  <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
                </pattern>
                <linearGradient id="selectedGlow" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity="0.8" />
                </linearGradient>
              </defs>
              <rect width="1000" height="700" fill="url(#cadastralGrid)" />

              {/* Geographical Reference River / Highway curve */}
              <path 
                d="M 50,650 Q 300,450 500,380 T 950,150" 
                fill="none" 
                stroke="#0284c7" 
                strokeWidth="6" 
                opacity="0.3" 
                strokeDasharray="8 4"
              />
              <text x="750" y="220" fill="#38bdf8" fontSize="11" opacity="0.6" transform="rotate(-15 750 220)">
                Mula-Mutha River Basin (Buffer Zone)
              </text>

              {/* Render parcel polygons */}
              {parcels.map((p, index) => {
                // Normalize lat/lng coordinates to SVG 1000x700
                const lat = parseFloat(p.centroidLat) || 18.5;
                const lng = parseFloat(p.centroidLng) || 73.85;
                
                // Map around Pune coordinates [18.4 to 18.7], [73.7 to 74.1]
                const x = ((lng - 73.7) / (74.1 - 73.7)) * 800 + 100;
                const y = 700 - (((lat - 18.4) / (18.7 - 18.4)) * 600 + 50);

                const isSelected = selectedParcel?.ulpin === p.ulpin;
                const color = getParcelColor(p.landUseClass);
                const size = Math.max(14, Math.min(36, Math.sqrt(p.areaSqm || 10000) / 10));

                return (
                  <g 
                    key={p.ulpin || index} 
                    onClick={() => setSelectedParcel(p)}
                    style={{ cursor: 'pointer', transition: 'all 0.2s' }}
                  >
                    <polygon
                      points={`
                        ${x - size},${y - size * 0.7} 
                        ${x + size * 0.9},${y - size * 0.8} 
                        ${x + size * 1.1},${y + size * 0.7} 
                        ${x - size * 0.8},${y + size * 1.1}
                      `}
                      fill={isSelected ? 'url(#selectedGlow)' : color}
                      fillOpacity={isSelected ? 0.85 : 0.65}
                      stroke={isSelected ? '#ffffff' : 'rgba(255,255,255,0.4)'}
                      strokeWidth={isSelected ? 3 : 1}
                    />
                    {/* Label survey number if not scaled demo */}
                    {!scaleDemo && (
                      <text 
                        x={x} 
                        y={y + 3} 
                        fill="#ffffff" 
                        fontSize="9" 
                        fontWeight="600" 
                        textAnchor="middle" 
                        pointerEvents="none"
                      >
                        {p.surveyNumber}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>

            {/* Bottom map status bar */}
            <div style={{ position: 'absolute', bottom: '12px', left: '16px', background: 'rgba(7, 23, 43, 0.85)', backdropFilter: 'blur(6px)', padding: '6px 14px', borderRadius: '6px', fontSize: '11.5px', color: '#94a3b8', display: 'flex', gap: '16px', border: '1px solid rgba(255,255,255,0.1)' }}>
              <span>Viewport: <strong>EPSG:4326 / WGS 84</strong></span>
              <span>Loaded Parcels: <strong style={{ color: '#ffffff' }}>{parcels.length}</strong></span>
              <span>Survey Agency: <strong>Survey of India & Settlement Comm.</strong></span>
            </div>
          </div>
        </div>

        {/* Right Cadastral Details Drawer */}
        {selectedParcel ? (
          <aside className="gis-drawer">
            <div className="gis-drawer-header">
              <div>
                <span className="badge badge-blue" style={{ marginBottom: '4px' }}>
                  {selectedParcel.verifiedStatus || 'Demonstration'}
                </span>
                <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-950)' }}>
                  Survey No. {selectedParcel.surveyNumber}
                </h3>
              </div>
              <button 
                onClick={() => setSelectedParcel(null)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b' }}
              >
                <X size={18} />
              </button>
            </div>

            <div className="gis-drawer-body">
              <div className="data-field-group">
                <span className="data-field-label">14-Digit ULPIN (Bhu-Aadhaar)</span>
                <span className="data-field-value mono">{selectedParcel.ulpin}</span>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="data-field-group">
                  <span className="data-field-label">State</span>
                  <span className="data-field-value">{selectedParcel.state}</span>
                </div>
                <div className="data-field-group">
                  <span className="data-field-label">District</span>
                  <span className="data-field-value">{selectedParcel.district}</span>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="data-field-group">
                  <span className="data-field-label">Taluka / Sub-District</span>
                  <span className="data-field-value">{selectedParcel.subDistrict}</span>
                </div>
                <div className="data-field-group">
                  <span className="data-field-label">Village</span>
                  <span className="data-field-value">{selectedParcel.village}</span>
                </div>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Cadastral Area Measurement</span>
                <div style={{ display: 'flex', gap: '10px', marginTop: '4px' }}>
                  <div style={{ flex: 1, padding: '8px', background: '#f8fafc', borderRadius: '6px', textAlign: 'center', border: '1px solid #e2e8f0' }}>
                    <div style={{ fontSize: '14px', fontWeight: 700, color: '#1e293b' }}>{selectedParcel.areaHectares}</div>
                    <div style={{ fontSize: '10.5px', color: '#64748b' }}>Hectares</div>
                  </div>
                  <div style={{ flex: 1, padding: '8px', background: '#f8fafc', borderRadius: '6px', textAlign: 'center', border: '1px solid #e2e8f0' }}>
                    <div style={{ fontSize: '14px', fontWeight: 700, color: '#1e293b' }}>{selectedParcel.areaAcres}</div>
                    <div style={{ fontSize: '10.5px', color: '#64748b' }}>Acres</div>
                  </div>
                  <div style={{ flex: 1, padding: '8px', background: '#f8fafc', borderRadius: '6px', textAlign: 'center', border: '1px solid #e2e8f0' }}>
                    <div style={{ fontSize: '14px', fontWeight: 700, color: '#1e293b' }}>{selectedParcel.areaSqm?.toLocaleString()}</div>
                    <div style={{ fontSize: '10.5px', color: '#64748b' }}>Sq. Meters</div>
                  </div>
                </div>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Land Use Classification</span>
                <span className="data-field-value" style={{ fontWeight: 600, color: getParcelColor(selectedParcel.landUseClass) }}>
                  {selectedParcel.landUseClass}
                </span>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Ownership Classification</span>
                <span className="data-field-value">{selectedParcel.ownershipCategory}</span>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Centroid Coordinates (WGS84)</span>
                <span className="data-field-value mono" style={{ fontSize: '12px' }}>
                  Lat: {selectedParcel.centroidLat}, Lng: {selectedParcel.centroidLng}
                </span>
              </div>

              {/* Admin Verification Section */}
              <div style={{ marginTop: '12px', padding: '16px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #cbd5e1' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                  <Edit3 size={15} color="#0a2240" />
                  <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--gov-navy-950)' }}>
                    Statutory Field Verification
                  </span>
                </div>

                {hasRole(['Administrator']) ? (
                  <div>
                    <div className="form-group" style={{ marginBottom: '8px' }}>
                      <label className="form-label" style={{ fontSize: '11.5px' }}>Status Override</label>
                      <select 
                        className="form-control" 
                        value={verifyStatus}
                        onChange={(e) => setVerifyStatus(e.target.value)}
                        style={{ fontSize: '12.5px', padding: '6px 10px' }}
                      >
                        <option value="Verified">Verified (Revenue Seal Applied)</option>
                        <option value="Demonstration">Demonstration / Pilot Benchmark</option>
                        <option value="Imported">Imported (Pending Field Audit)</option>
                      </select>
                    </div>

                    <div className="form-group" style={{ marginBottom: '10px' }}>
                      <label className="form-label" style={{ fontSize: '11.5px' }}>Inspection Remarks</label>
                      <input 
                        type="text" 
                        className="form-control"
                        placeholder="e.g. Field verification conducted by Tehsildar"
                        value={verifyRemarks}
                        onChange={(e) => setVerifyRemarks(e.target.value)}
                        style={{ fontSize: '12px', padding: '6px 10px' }}
                      />
                    </div>

                    <button 
                      className="btn btn-primary" 
                      onClick={handleVerify}
                      disabled={verifying}
                      style={{ width: '100%', fontSize: '12.5px' }}
                    >
                      {verifying ? 'Applying SHA-256 Block...' : 'Commit Verification to Audit Ledger'}
                    </button>
                  </div>
                ) : (
                  <div style={{ fontSize: '12px', color: '#64748b' }}>
                    <ShieldAlert size={14} style={{ display: 'inline', marginRight: '4px' }} />
                    Verification actions require <strong>Administrator</strong> privileges. Switch active persona in top header to test this workflow.
                  </div>
                )}
              </div>
            </div>
          </aside>
        ) : (
          <aside className="gis-drawer" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', padding: '30px', textAlign: 'center' }}>
            <div>
              <MapPin size={36} style={{ margin: '0 auto 12px auto', opacity: 0.5 }} />
              <div style={{ fontWeight: 600, color: '#475569', marginBottom: '6px' }}>Select a Cadastral Parcel</div>
              <p style={{ fontSize: '12px' }}>Click any vector parcel on the map canvas or use the search bar to view verified revenue attributes.</p>
            </div>
          </aside>
        )}

      </div>
    </div>
  );
}
