import React, { useState, useEffect } from 'react';
import { 
  Lightbulb, 
  Plus, 
  CheckCircle2, 
  Clock, 
  Award, 
  Layers, 
  DollarSign, 
  Calendar,
  MessageSquare,
  ShieldCheck,
  Info
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function InnovationHubPage() {
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);

  // Proposal Submission State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Cadastral GIS & Drone Survey');
  const [targetState, setTargetState] = useState('Maharashtra');
  const [problemStatement, setProblemStatement] = useState('');
  const [solutionSummary, setSolutionSummary] = useState('');
  const [budgetInr, setBudgetInr] = useState(3500000);
  const [timelineMonths, setTimelineMonths] = useState(9);

  // Review Form State
  const [reviewStatus, setReviewStatus] = useState('Under Review');
  const [reviewScore, setReviewScore] = useState(88.0);
  const [reviewNotes, setReviewNotes] = useState('');

  const { user, hasRole } = useAuth();

  useEffect(() => {
    loadProposals();
  }, []);

  const loadProposals = async () => {
    try {
      setLoading(true);
      const res = await api.getProposals();
      setProposals(res.proposals || []);
    } catch (err) {
      console.error('[InnovationHub] Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitProposal = async (e) => {
    e.preventDefault();
    if (!title || !problemStatement || !solutionSummary) return;

    try {
      setLoading(true);
      await api.submitProposal({
        title,
        category,
        targetState,
        problemStatement,
        solutionSummary,
        budgetInr: parseFloat(budgetInr),
        timelineMonths: parseInt(timelineMonths)
      });
      setShowSubmitModal(false);
      setTitle('');
      setProblemStatement('');
      setSolutionSummary('');
      loadProposals();
      alert('Innovation Proposal successfully submitted for National Review.');
    } catch (err) {
      alert(`Submission failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!selectedProposal) return;

    try {
      setLoading(true);
      await api.reviewProposal(selectedProposal.id, {
        status: reviewStatus,
        reviewerScore: parseFloat(reviewScore),
        reviewerNotes: reviewNotes
      });
      setReviewModalOpen(false);
      loadProposals();
      alert('Review decision and score successfully recorded.');
    } catch (err) {
      alert(`Review failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Shortlisted for Pilot':
        return <span className="badge badge-green"><CheckCircle2 size={12} /> {status}</span>;
      case 'Under Review':
        return <span className="badge badge-amber"><Clock size={12} /> {status}</span>;
      case 'Revision Requested':
        return <span className="badge badge-purple">{status}</span>;
      default:
        return <span className="badge badge-blue">{status}</span>;
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Open Innovation Hub & Pilot Sandbox</h1>
          <p className="page-subtitle">
            Collaborative grant and research incubator for drone surveying, AI-assisted mutation detection, and automated parcel boundary delineation.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowSubmitModal(true)}>
          <Plus size={16} />
          Submit Research Proposal
        </button>
      </div>

      <div className="alert-banner alert-info">
        <Info size={18} style={{ flexShrink: 0 }} />
        <div>
          <strong>Challenge Theme:</strong> Smart India Hackathon Problem Statement SIH26019. Proposals submitted here are tracked with genuine milestone deliverables, role-based review scores, and verifiable pilot stage progression.
        </div>
      </div>

      {/* Proposals Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '20px' }}>
        {proposals.map(prop => (
          <div key={prop.id} className="card" style={{ display: 'flex', flexDirection: 'column' }}>
            <div className="card-header">
              <span className="badge badge-blue">{prop.category}</span>
              {getStatusBadge(prop.status)}
            </div>

            <div className="card-body" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)', marginBottom: '8px' }}>
                {prop.title}
              </h3>
              <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '14px', flex: 1 }}>
                {prop.problemStatement}
              </p>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '12.5px', marginBottom: '14px', background: 'var(--bg-subtle)', padding: '10px', borderRadius: '6px' }}>
                <div>
                  <span style={{ color: '#64748b' }}>Target State:</span>
                  <div style={{ fontWeight: 600 }}>{prop.targetState}</div>
                </div>
                <div>
                  <span style={{ color: '#64748b' }}>Requested Budget:</span>
                  <div style={{ fontWeight: 600, color: '#059669' }}>₹{(prop.budgetInr / 100000).toFixed(1)} Lakhs</div>
                </div>
                <div>
                  <span style={{ color: '#64748b' }}>Timeline:</span>
                  <div style={{ fontWeight: 600 }}>{prop.timelineMonths} Months</div>
                </div>
                <div>
                  <span style={{ color: '#64748b' }}>Review Score:</span>
                  <div style={{ fontWeight: 700, color: prop.reviewerScore >= 90 ? '#059669' : '#d97706' }}>
                    {prop.reviewerScore ? `${prop.reviewerScore} / 100` : 'Pending Score'}
                  </div>
                </div>
              </div>

              {prop.reviewerNotes && (
                <div style={{ fontSize: '12px', background: '#ecfdf5', padding: '8px 10px', borderRadius: '4px', border: '1px solid #a7f3d0', color: '#065f46', marginBottom: '12px' }}>
                  <strong>Reviewer Committee:</strong> "{prop.reviewerNotes}"
                </div>
              )}

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: '8px', marginTop: 'auto' }}>
                {hasRole(['Administrator']) && (
                  <button 
                    className="btn btn-secondary btn-sm" 
                    style={{ flex: 1 }}
                    onClick={() => {
                      setSelectedProposal(prop);
                      setReviewStatus(prop.status);
                      setReviewScore(prop.reviewerScore || 85.0);
                      setReviewNotes(prop.reviewerNotes || '');
                      setReviewModalOpen(true);
                    }}
                  >
                    <ShieldCheck size={14} />
                    Evaluate & Score
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Submission Modal */}
      {showSubmitModal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Submit Research Proposal or Pilot Project
              </div>
              <button onClick={() => setShowSubmitModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px' }}>
                ✕
              </button>
            </div>
            <form onSubmit={handleSubmitProposal}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Project / Proposal Title *</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="e.g. AI-driven Parcel Mutation Anomaly Detection in Semi-Arid Tracts"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div className="form-group">
                    <label className="form-label">Category</label>
                    <select className="form-control" value={category} onChange={(e) => setCategory(e.target.value)}>
                      <option value="Cadastral GIS & Drone Survey">Cadastral GIS & Drone Survey</option>
                      <option value="AI & Natural Language Processing">AI & Natural Language Processing</option>
                      <option value="Satellite Remote Sensing">Satellite Remote Sensing</option>
                      <option value="Legal & Land Economics">Legal & Land Economics</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Target State</label>
                    <select className="form-control" value={targetState} onChange={(e) => setTargetState(e.target.value)}>
                      <option value="Maharashtra">Maharashtra</option>
                      <option value="Uttar Pradesh">Uttar Pradesh</option>
                      <option value="Karnataka">Karnataka</option>
                      <option value="Gujarat">Gujarat</option>
                      <option value="Odisha">Odisha</option>
                    </select>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div className="form-group">
                    <label className="form-label">Requested Budget (INR)</label>
                    <input
                      type="number"
                      className="form-control"
                      value={budgetInr}
                      onChange={(e) => setBudgetInr(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Estimated Timeline (Months)</label>
                    <input
                      type="number"
                      className="form-control"
                      value={timelineMonths}
                      onChange={(e) => setTimelineMonths(e.target.value)}
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Problem Statement *</label>
                  <textarea
                    className="form-control"
                    required
                    placeholder="Explain the specific land governance or cadastral challenge addressed..."
                    value={problemStatement}
                    onChange={(e) => setProblemStatement(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Proposed Methodology & Solution *</label>
                  <textarea
                    className="form-control"
                    required
                    placeholder="Describe technical implementation, datasets to be utilized, and deliverables..."
                    value={solutionSummary}
                    onChange={(e) => setSolutionSummary(e.target.value)}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowSubmitModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  {loading ? 'Submitting...' : 'Submit to Committee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Review Modal (Administrator Only) */}
      {reviewModalOpen && selectedProposal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Official Proposal Review: {selectedProposal.title}
              </div>
              <button onClick={() => setReviewModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px' }}>
                ✕
              </button>
            </div>
            <form onSubmit={handleReviewSubmit}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Decision Status</label>
                  <select className="form-control" value={reviewStatus} onChange={(e) => setReviewStatus(e.target.value)}>
                    <option value="Under Review">Under Review</option>
                    <option value="Revision Requested">Revision Requested</option>
                    <option value="Shortlisted for Pilot">Shortlisted for Pilot</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Review Score (0 - 100)</label>
                  <input
                    type="number"
                    step="0.5"
                    className="form-control"
                    value={reviewScore}
                    onChange={(e) => setReviewScore(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Reviewer Comments & Sanction Remarks</label>
                  <textarea
                    className="form-control"
                    required
                    placeholder="Enter official evaluation justification..."
                    value={reviewNotes}
                    onChange={(e) => setReviewNotes(e.target.value)}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setReviewModalOpen(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  Save Decision
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
