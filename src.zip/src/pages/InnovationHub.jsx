import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  Lightbulb, 
  Send, 
  ThumbsUp, 
  CheckCircle, 
  Clock, 
  Award, 
  X, 
  ShieldCheck, 
  ExternalLink,
  MessageSquare
} from 'lucide-react';

export default function InnovationHub() {
  const { user, hasRole } = useAuth();
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  
  // Submit proposal state
  const [title, setTitle] = useState('');
  const [challengeId, setChallengeId] = useState('CH-2026-01');
  const [abstract, setAbstract] = useState('');
  const [methodology, setMethodology] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Review proposal state
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [reviewStatus, setReviewStatus] = useState('Approved for Pilot Sandbox');
  const [reviewNotes, setReviewNotes] = useState('');
  const [reviewing, setReviewing] = useState(false);

  const CHALLENGES = [
    {
      id: 'CH-2026-01',
      title: 'Automated Encroachment Detection on Gram Panchayat Commons',
      reward: '₹15 Lakhs Pilot Grant',
      deadline: 'Nov 30, 2026',
      description: 'Computer vision pipeline detecting unauthorized boundary expansion on grazing lands (Gairan) using high-resolution drone and satellite imagery.'
    },
    {
      id: 'CH-2026-02',
      title: 'Multilingual Voice-First RoR (7/12 Extract) Assistant for Farmers',
      reward: '₹10 Lakhs Pilot Grant',
      deadline: 'Dec 15, 2026',
      description: 'Conversational AI in Marathi, Hindi, and Gujarati allowing marginal landholders to verify mutation entry status without physical taluk visits.'
    }
  ];

  useEffect(() => {
    loadProposals();
  }, []);

  async function loadProposals() {
    try {
      setLoading(true);
      const res = await api.getProposals();
      setProposals(res.proposals || []);
    } catch (err) {
      console.error('[InnovationHub] Error loading proposals:', err);
    } finally {
      setLoading(false);
    }
  }

  const handleSubmitProposal = async (e) => {
    e.preventDefault();
    if (!title.trim() || !abstract.trim()) return;

    try {
      setSubmitting(true);
      await api.submitProposal({
        title,
        challengeId,
        abstract,
        methodology: methodology || 'Computer vision spectral pipeline using Python OpenCV and Sentinel-2 imagery.',
        submitterName: user?.fullName || 'Anonymous Researcher',
        organization: user?.department || 'Academic Institute'
      });
      setShowSubmitModal(false);
      setTitle('');
      setAbstract('');
      loadProposals();
      alert('Innovation Proposal submitted successfully! Registered on the tamper-evident ledger.');
    } catch (err) {
      alert(err.message || 'Submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReviewProposal = async (e) => {
    e.preventDefault();
    if (!selectedProposal) return;

    try {
      setReviewing(true);
      await api.reviewProposal(selectedProposal.id, {
        status: reviewStatus,
        reviewNotes: reviewNotes || 'Evaluation committee approved for state pilot incubation.'
      });
      setSelectedProposal(null);
      loadProposals();
      alert(`Proposal ${selectedProposal.id} updated to ${reviewStatus}!`);
    } catch (err) {
      alert(err.message || 'Review failed');
    } finally {
      setReviewing(false);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Open Innovation & Policy Sandbox Hub</h1>
          <p className="page-subtitle">
            Crowdsourcing Geospatial & Statutory Solutions for Next-Generation Land Governance
          </p>
        </div>

        <button className="btn btn-accent" onClick={() => setShowSubmitModal(true)}>
          <Lightbulb size={16} /> Submit Innovation Proposal
        </button>
      </div>

      {/* Featured National Challenges */}
      <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-950)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '14px' }}>
        Active National Innovation Challenges (2026 Cohort)
      </h3>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '20px', marginBottom: '28px' }}>
        {CHALLENGES.map(ch => (
          <div key={ch.id} className="card" style={{ marginBottom: 0 }}>
            <div className="card-header" style={{ background: '#f8fafc' }}>
              <div>
                <span className="badge badge-purple" style={{ marginBottom: '4px' }}>{ch.id}</span>
                <div style={{ fontWeight: 700, fontSize: '15px', color: 'var(--gov-navy-950)' }}>{ch.title}</div>
              </div>
              <span className="badge badge-green" style={{ fontSize: '12px' }}>{ch.reward}</span>
            </div>
            <div className="card-body">
              <p style={{ fontSize: '13px', color: '#475569', lineHeight: 1.5, marginBottom: '16px' }}>
                {ch.description}
              </p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '12px', color: '#94a3b8' }}>Submission Deadline: {ch.deadline}</span>
                <button 
                  className="btn btn-sm btn-primary"
                  onClick={() => { setChallengeId(ch.id); setShowSubmitModal(true); }}
                >
                  Apply with Solution
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Submitted Proposals Table */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">Submitted Innovation Proposals & Peer Review Registry ({proposals.length})</span>
          <span className="badge badge-blue">Public Sandbox Track</span>
        </div>
        <div className="card-body" style={{ padding: 0 }}>
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Proposal Title</th>
                  <th>Challenge</th>
                  <th>Submitter / Org</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {proposals.map(prop => (
                  <tr key={prop.id}>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{prop.title}</div>
                      <div style={{ fontSize: '11.5px', color: '#64748b' }}>{prop.abstract?.substring(0, 90)}...</div>
                    </td>
                    <td>
                      <span className="badge badge-purple">{prop.challengeId}</span>
                    </td>
                    <td>
                      <div style={{ fontWeight: 500, fontSize: '12.5px' }}>{prop.submitterName}</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>{prop.organization}</div>
                    </td>
                    <td>
                      <span className={`badge ${
                        prop.status?.includes('Approved') ? 'badge-green' : 
                        (prop.status?.includes('Review') ? 'badge-amber' : 'badge-blue')
                      }`}>
                        {prop.status}
                      </span>
                    </td>
                    <td style={{ fontSize: '12px', color: '#64748b' }}>
                      {prop.submittedAt ? new Date(prop.submittedAt).toLocaleDateString() : '2026-03-12'}
                    </td>
                    <td>
                      {hasRole(['Administrator']) ? (
                        <button 
                          className="btn btn-sm btn-secondary" 
                          onClick={() => setSelectedProposal(prop)}
                        >
                          Review & Award
                        </button>
                      ) : (
                        <span style={{ fontSize: '11.5px', color: '#94a3b8' }}>Under Evaluation</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Submit Proposal Modal */}
      {showSubmitModal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Submit Innovation Solution
              </h3>
              <button onClick={() => setShowSubmitModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSubmitProposal}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Solution Title *</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    placeholder="e.g. YOLOv9 Multi-Spectral Encroachment Classifier for Village Commons"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Associated Challenge *</label>
                  <select 
                    className="form-control" 
                    value={challengeId}
                    onChange={(e) => setChallengeId(e.target.value)}
                  >
                    {CHALLENGES.map(c => (
                      <option key={c.id} value={c.id}>{c.id}: {c.title}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Executive Abstract *</label>
                  <textarea 
                    className="form-control"
                    placeholder="Describe how your solution directly solves the problem statement..."
                    value={abstract}
                    onChange={(e) => setAbstract(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Technical Architecture / Methodology</label>
                  <textarea 
                    className="form-control"
                    placeholder="Algorithms, datasets used, ground verification protocol..."
                    value={methodology}
                    onChange={(e) => setMethodology(e.target.value)}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowSubmitModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-accent" disabled={submitting}>
                  {submitting ? 'Registering...' : 'Submit to Sandbox'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Review Modal */}
      {selectedProposal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Administrator Decision: {selectedProposal.id}
              </h3>
              <button onClick={() => setSelectedProposal(null)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleReviewProposal}>
              <div className="modal-body">
                <div style={{ marginBottom: '16px' }}>
                  <strong>Title:</strong> {selectedProposal.title}
                </div>
                <div style={{ marginBottom: '16px', fontSize: '13px', color: '#475569' }}>
                  {selectedProposal.abstract}
                </div>

                <div className="form-group">
                  <label className="form-label">Statutory Committee Decision</label>
                  <select 
                    className="form-control"
                    value={reviewStatus}
                    onChange={(e) => setReviewStatus(e.target.value)}
                  >
                    <option value="Approved for Pilot Sandbox">Approved for Pilot Sandbox</option>
                    <option value="Under Technical Evaluation">Under Technical Evaluation</option>
                    <option value="Revision Requested">Revision Requested</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Committee Remarks</label>
                  <textarea 
                    className="form-control"
                    placeholder="Provide justification and grant allocation details..."
                    value={reviewNotes}
                    onChange={(e) => setReviewNotes(e.target.value)}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setSelectedProposal(null)}>
                  Close
                </button>
                <button type="submit" className="btn btn-primary" disabled={reviewing}>
                  {reviewing ? 'Recording...' : 'Publish Official Evaluation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
