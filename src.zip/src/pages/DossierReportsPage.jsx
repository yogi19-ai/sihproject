import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Plus, 
  ShieldCheck, 
  CheckCircle2, 
  Info, 
  ExternalLink,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function DossierReportsPage() {
  const [dossiers, setDossiers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDossier, setSelectedDossier] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Dossier Form State
  const [title, setTitle] = useState('');
  const [geographicScope, setGeographicScope] = useState('Pune District (Haveli Taluk), Maharashtra');
  const [problemStatement, setProblemStatement] = useState('');
  const { user, hasRole } = useAuth();

  useEffect(() => {
    loadDossiers();
  }, []);

  const loadDossiers = async () => {
    try {
      setLoading(true);
      const res = await api.getDossiers();
      setDossiers(res.dossiers || []);
      if (res.dossiers && res.dossiers.length > 0) {
        setSelectedDossier(res.dossiers[0]);
      }
    } catch (err) {
      console.error('[DossierReports] Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDossier = async (e) => {
    e.preventDefault();
    if (!title || !problemStatement) return;

    try {
      setLoading(true);
      const res = await api.createDossier({
        title,
        geographicScope,
        problemStatement
      });
      setShowCreateModal(false);
      setTitle('');
      setProblemStatement('');
      setSelectedDossier(res.dossier);
      loadDossiers();
      alert('Decision Dossier compiled and cryptographically hashed with SHA-256.');
    } catch (err) {
      alert(`Creation failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header no-print">
        <div>
          <h1 className="page-title">Decision Dossiers & Evidence Briefs</h1>
          <p className="page-subtitle">
            Cryptographically sealed policy briefs synthesizing spatial cadastral indicators, statutory citations, and financial liability models.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          {hasRole(['Researcher', 'Administrator']) && (
            <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
              <Plus size={16} />
              Draft New Brief
            </button>
          )}
        </div>
      </div>

      <div className="alert-banner alert-info no-print">
        <Info size={18} style={{ flexShrink: 0 }} />
        <div>
          <strong>Tamper-Evident Dossier Sealing:</strong> Each dossier is assigned a unique SHA-256 cryptographic digest stamped at generation. Outputs provide structured empirical intelligence for revenue authorities and do not constitute official cabinet orders.
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: '24px' }}>
        {/* Dossiers List (Left) */}
        <div className="card no-print" style={{ height: 'fit-content' }}>
          <div className="card-header">
            <div className="card-title">Published Briefs ({dossiers.length})</div>
          </div>
          <div className="card-body" style={{ padding: '8px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {dossiers.map(dos => (
                <button
                  key={dos.id}
                  onClick={() => setSelectedDossier(dos)}
                  style={{
                    padding: '12px',
                    borderRadius: '8px',
                    border: selectedDossier?.id === dos.id ? '2px solid var(--gov-navy-800)' : '1px solid var(--border-light)',
                    background: selectedDossier?.id === dos.id ? 'var(--bg-subtle)' : '#ffffff',
                    textAlign: 'left',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <div style={{ fontSize: '11px', fontWeight: 700, color: '#d97706', marginBottom: '2px' }}>
                    {dos.dossierNumber}
                  </div>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--gov-navy-900)', lineHeight: '1.3', marginBottom: '4px' }}>
                    {dos.title}
                  </div>
                  <div style={{ fontSize: '11px', color: '#64748b' }}>
                    {new Date(dos.createdAt).toLocaleDateString()}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Selected Dossier Preview (Right) */}
        {selectedDossier && (
          <div className="card" style={{ padding: '32px' }}>
            {/* Dossier Header Actions */}
            <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', paddingBottom: '16px', borderBottom: '1px solid #e2e8f0' }}>
              <span className="badge badge-green">
                <ShieldCheck size={14} /> SHA-256 Cryptographically Sealed
              </span>
              <div style={{ display: 'flex', gap: '8px' }}>
                <a 
                  href={api.getDossierCsvUrl(selectedDossier.id)}
                  download={`${selectedDossier.dossierNumber}.csv`}
                  className="btn btn-secondary btn-sm"
                >
                  <FileSpreadsheet size={14} />
                  Export CSV
                </a>
                <button className="btn btn-primary btn-sm" onClick={() => window.print()}>
                  <Printer size={14} />
                  Print / Export PDF
                </button>
              </div>
            </div>

            {/* Formal Report Layout */}
            <div style={{ borderBottom: '2px solid var(--gov-navy-950)', paddingBottom: '16px', marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: '12px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.8px' }}>
                    Government of India • National Land Governance Evidence Dossier
                  </div>
                  <h2 style={{ fontSize: '22px', fontWeight: 700, color: 'var(--gov-navy-950)', marginTop: '4px' }}>
                    {selectedDossier.title}
                  </h2>
                </div>
                <div style={{ textAlign: 'right', fontSize: '12px', color: '#64748b' }}>
                  <div style={{ fontWeight: 700, color: 'var(--gov-navy-900)', fontSize: '13px' }}>{selectedDossier.dossierNumber}</div>
                  <div>Issued: {new Date(selectedDossier.createdAt).toLocaleDateString()}</div>
                </div>
              </div>
            </div>

            {/* Metadata Bar */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', background: 'var(--bg-subtle)', padding: '12px 16px', borderRadius: '6px', fontSize: '12.5px', marginBottom: '24px' }}>
              <div>
                <span style={{ color: '#64748b' }}>Geographic Scope:</span>
                <div style={{ fontWeight: 600 }}>{selectedDossier.geographicScope}</div>
              </div>
              <div>
                <span style={{ color: '#64748b' }}>Author / Persona:</span>
                <div style={{ fontWeight: 600 }}>{selectedDossier.authorName || 'Policy Fellow'}</div>
              </div>
              <div>
                <span style={{ color: '#64748b' }}>Review Status:</span>
                <div style={{ fontWeight: 600, color: '#059669' }}>Final Evidence Brief</div>
              </div>
            </div>

            {/* Problem Statement */}
            <div style={{ marginBottom: '24px' }}>
              <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-900)', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px', marginBottom: '10px' }}>
                1. Executive Problem Statement
              </h3>
              <p style={{ fontSize: '14px', lineHeight: '1.6', color: 'var(--text-main)' }}>
                {selectedDossier.problemStatement}
              </p>
            </div>

            {/* Key Findings */}
            <div style={{ marginBottom: '24px' }}>
              <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-900)', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px', marginBottom: '10px' }}>
                2. Geospatial & Empirical Findings
              </h3>
              <ul style={{ paddingLeft: '20px', fontSize: '13.5px', lineHeight: '1.7', color: 'var(--text-main)' }}>
                {(selectedDossier.keyFindings || []).map((f, idx) => (
                  <li key={idx} style={{ marginBottom: '6px' }}>{f}</li>
                ))}
              </ul>
            </div>

            {/* Statutory Citations */}
            <div style={{ marginBottom: '24px' }}>
              <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-900)', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px', marginBottom: '10px' }}>
                3. Statutory Grounding & Verified Legal Citations
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {(selectedDossier.statutoryCitations || []).map((c, idx) => (
                  <div key={idx} style={{ fontSize: '13px', background: 'var(--bg-subtle)', padding: '8px 12px', borderRadius: '4px', borderLeft: '3px solid var(--gov-saffron-500)' }}>
                    {c}
                  </div>
                ))}
              </div>
            </div>

            {/* Policy Recommendations */}
            <div style={{ marginBottom: '24px' }}>
              <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-900)', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px', marginBottom: '10px' }}>
                4. Strategic Recommendations for Revenue Authorities
              </h3>
              <ol style={{ paddingLeft: '20px', fontSize: '13.5px', lineHeight: '1.7', color: 'var(--text-main)' }}>
                {(selectedDossier.policyRecommendations || []).map((r, idx) => (
                  <li key={idx} style={{ marginBottom: '6px' }}>{r}</li>
                ))}
              </ol>
            </div>

            {/* Cryptographic Seal Footer */}
            <div style={{ marginTop: '30px', paddingTop: '16px', borderTop: '1px solid #cbd5e1', fontSize: '11px', color: '#64748b' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                <strong>SHA-256 Integrity Verification Digest:</strong>
                <span>Verified Hash Chain</span>
              </div>
              <div style={{ fontFamily: 'monospace', wordBreak: 'break-all', background: '#f1f5f9', padding: '6px 10px', borderRadius: '4px' }}>
                {selectedDossier.hashSha256}
              </div>
              <div style={{ marginTop: '8px', fontStyle: 'italic' }}>
                {selectedDossier.disclaimer}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Draft New Dossier Modal */}
      {showCreateModal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Draft New Decision Dossier
              </div>
              <button onClick={() => setShowCreateModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px' }}>
                ✕
              </button>
            </div>
            <form onSubmit={handleCreateDossier}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Dossier Subject Title *</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    placeholder="e.g. Land Pooling Evaluation for Industrial SEZ Expansion"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Geographic Jurisdiction *</label>
                  <input
                    type="text"
                    className="form-control"
                    required
                    value={geographicScope}
                    onChange={(e) => setGeographicScope(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Executive Problem & Context *</label>
                  <textarea
                    className="form-control"
                    required
                    placeholder="State the core land governance dilemma, affected villages, and required policy intervention..."
                    value={problemStatement}
                    onChange={(e) => setProblemStatement(e.target.value)}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCreateModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  Compile & Cryptographically Seal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
