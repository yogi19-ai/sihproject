import React, { useState, useEffect } from 'react';
import { 
  Sliders, 
  Play, 
  Save, 
  Info, 
  TrendingUp, 
  AlertCircle, 
  Scale, 
  ShieldCheck, 
  Layers,
  ArrowRight
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function PolicySimulatorPage() {
  const { user, hasRole } = useAuth();
  const [scenarios, setScenarios] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeScenario, setActiveScenario] = useState(null);

  // Simulation Form Controls
  const [title, setTitle] = useState('Pune Ring Road Outer Growth Model');
  const [state, setState] = useState('Maharashtra');
  const [district, setDistrict] = useState('Pune');
  const [baselineYear, setBaselineYear] = useState(2026);
  const [targetYear, setTargetYear] = useState(2031);
  const [ecoBufferMeters, setEcoBufferMeters] = useState(500);
  const [compensationMultiplier, setCompensationMultiplier] = useState(2.0);
  const [solatiumPercentage, setSolatiumPercentage] = useState(100.0);
  const [circleRateINR, setCircleRateINR] = useState(4500000); // 45 Lakhs / Ha
  const [agriTransitionRate, setAgriTransitionRate] = useState(0.25);
  const [enforceWaterProtection, setEnforceWaterProtection] = useState(true);

  useEffect(() => {
    loadScenarios();
  }, []);

  const loadScenarios = async () => {
    try {
      setLoading(true);
      const res = await api.getScenarios();
      setScenarios(res.scenarios || []);
      if (res.scenarios && res.scenarios.length > 0) {
        setActiveScenario(res.scenarios[0]);
      }
    } catch (err) {
      console.error('[Simulator] Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRunSimulation = async (e) => {
    e.preventDefault();
    if (!title) return;

    try {
      setLoading(true);
      const payload = {
        title,
        state,
        district,
        baselineYear: parseInt(baselineYear),
        targetYear: parseInt(targetYear),
        ecoBufferMeters: parseInt(ecoBufferMeters),
        compensationMultiplier: parseFloat(compensationMultiplier),
        solatiumPercentage: parseFloat(solatiumPercentage),
        circleRatePerHectareINR: parseFloat(circleRateINR),
        agriculturalTransitionRate: parseFloat(agriTransitionRate),
        enforceWaterbodyProtection: enforceWaterProtection
      };

      const res = await api.createScenario(payload);
      setActiveScenario(res.scenario);
      setScenarios([res.scenario, ...scenarios]);
      alert('Policy scenario successfully calculated and saved.');
    } catch (err) {
      alert(`Simulation failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const sim = activeScenario?.simulationResults || null;

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Policy What-If Simulator</h1>
          <p className="page-subtitle">
            Cellular Automata (CA) & Markov-chain spatial forecasting evaluating zoning boundaries, protected eco-buffers, and statutory compensation liabilities.
          </p>
        </div>
      </div>

      <div className="alert-banner alert-warning">
        <Info size={18} style={{ flexShrink: 0 }} />
        <div>
          <strong>Model Disclosure & Uncertainty:</strong> Multi-temporal CA-Markov forecasts predict spatial transition probabilities based on neighborhood suitability and historical trends. Outputs are model estimates subject to market and legislative shifts, not guaranteed outcomes.
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: '24px' }}>
        {/* Simulation Controls Panel */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Policy Parameter Adjustments</div>
            <span className="badge badge-blue">CA-Markov Engine</span>
          </div>
          <div className="card-body">
            <form onSubmit={handleRunSimulation}>
              <div className="form-group">
                <label className="form-label">Scenario Name *</label>
                <input
                  type="text"
                  className="form-control"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="form-group">
                  <label className="form-label">State</label>
                  <select className="form-control" value={state} onChange={(e) => setState(e.target.value)}>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Odisha">Odisha</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">District</label>
                  <input
                    type="text"
                    className="form-control"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="form-group">
                  <label className="form-label">Baseline Year</label>
                  <input
                    type="number"
                    className="form-control"
                    value={baselineYear}
                    disabled
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Horizon Target Year</label>
                  <select 
                    className="form-control"
                    value={targetYear}
                    onChange={(e) => setTargetYear(e.target.value)}
                  >
                    <option value="2031">2031 (5-Year Horizon)</option>
                    <option value="2036">2036 (10-Year Horizon)</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                  <label className="form-label">Eco-Buffer Protection Radius: {ecoBufferMeters}m</label>
                </div>
                <input
                  type="range"
                  min="100"
                  max="1500"
                  step="50"
                  style={{ width: '100%' }}
                  value={ecoBufferMeters}
                  onChange={(e) => setEcoBufferMeters(e.target.value)}
                />
              </div>

              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                  <label className="form-label">LARR Rural Multiplier Factor: {compensationMultiplier}x</label>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="2.0"
                  step="0.1"
                  style={{ width: '100%' }}
                  value={compensationMultiplier}
                  onChange={(e) => setCompensationMultiplier(e.target.value)}
                />
                <span style={{ fontSize: '11px', color: '#64748b' }}>
                  Statutory range: 1.00x (Urban) to 2.00x (Rural) under LARR 2013 Schedule I.
                </span>
              </div>

              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                  <label className="form-label">Mandatory Solatium Rate: {solatiumPercentage}%</label>
                </div>
                <input
                  type="number"
                  className="form-control"
                  value={solatiumPercentage}
                  disabled
                />
                <span style={{ fontSize: '11px', color: '#059669', fontWeight: 500 }}>
                  Mandatory 100% Solatium prescribed under Section 30 of LARR Act 2013.
                </span>
              </div>

              <div className="form-group">
                <label className="form-label">Assumed Circle Rate (INR / Hectare)</label>
                <input
                  type="number"
                  className="form-control"
                  value={circleRateINR}
                  onChange={(e) => setCircleRateINR(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={enforceWaterProtection}
                    onChange={(e) => setEnforceWaterProtection(e.target.checked)}
                  />
                  <span>Enforce Strict Wetlands Rules 2017 Waterbody Protection</span>
                </label>
              </div>

              {hasRole(['Researcher', 'Administrator']) ? (
                <button type="submit" className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
                  <Play size={16} />
                  {loading ? 'Running CA-Markov Engine...' : 'Run & Save Simulation'}
                </button>
              ) : (
                <div className="alert-banner alert-warning" style={{ fontSize: '12px', padding: '10px' }}>
                  Viewer Mode: You can inspect saved scenarios. Creating or modifying scenarios requires Researcher or Administrator privileges.
                </div>
              )}
            </form>
          </div>
        </div>

        {/* Simulation Results & Side-by-Side Comparison */}
        {sim && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Top KPI Impact Cards */}
            <div className="kpi-grid" style={{ marginBottom: '0' }}>
              <div className="kpi-card kpi-accent">
                <div className="kpi-header">
                  <span className="kpi-label">Projected Built-up Growth</span>
                  <div className="kpi-icon-wrapper"><TrendingUp size={18} /></div>
                </div>
                <div className="kpi-value">+{sim.projectedMetrics.netBuiltupGrowthPct}%</div>
                <div className="kpi-subtext">+{sim.projectedMetrics.netBuiltupGrowthHa} Ha urban spread</div>
              </div>

              <div className="kpi-card">
                <div className="kpi-header">
                  <span className="kpi-label">Estimated Liability</span>
                  <div className="kpi-icon-wrapper"><Scale size={18} /></div>
                </div>
                <div className="kpi-value" style={{ fontSize: '20px' }}>
                  ₹{(sim.compensationEstimate.totalEstimatedLiabilityINR / 10000000).toFixed(1)} Cr
                </div>
                <div className="kpi-subtext">Base + 100% Solatium</div>
              </div>

              <div className="kpi-card kpi-green">
                <div className="kpi-header">
                  <span className="kpi-label">Environmental Stress</span>
                  <div className="kpi-icon-wrapper"><ShieldCheck size={18} /></div>
                </div>
                <div className="kpi-value">{sim.environmentalImpactScore} / 100</div>
                <div className="kpi-subtext">Buffer preservation factor</div>
              </div>
            </div>

            {/* Side-by-Side Area Comparison */}
            <div className="card">
              <div className="card-header">
                <div className="card-title">Land-Use Transition Comparison (Ha)</div>
                <span className="badge badge-green">Baseline vs {sim.projectedMetrics.year} Target</span>
              </div>
              <div className="card-body" style={{ padding: '0' }}>
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Class</th>
                        <th>Baseline ({sim.baselineMetrics.year})</th>
                        <th>Projected ({sim.projectedMetrics.year})</th>
                        <th>Net Shift</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Agricultural Land</td>
                        <td>{sim.baselineMetrics.agriculturalHa} Ha</td>
                        <td style={{ fontWeight: 600 }}>{sim.projectedMetrics.agriculturalHa} Ha</td>
                        <td style={{ color: '#b91c1c' }}>-{sim.caMarkovTransitions.agricultureToBuiltupHa} Ha</td>
                      </tr>
                      <tr>
                        <td>Built-up / Urban Infrastructure</td>
                        <td>{sim.baselineMetrics.builtupHa} Ha</td>
                        <td style={{ fontWeight: 600 }}>{sim.projectedMetrics.builtupHa} Ha</td>
                        <td style={{ color: '#059669' }}>+{sim.projectedMetrics.netBuiltupGrowthHa} Ha</td>
                      </tr>
                      <tr>
                        <td>Forest & Canopy Buffer</td>
                        <td>{sim.baselineMetrics.forestHa} Ha</td>
                        <td style={{ fontWeight: 600 }}>{sim.projectedMetrics.forestHa} Ha</td>
                        <td style={{ color: '#b91c1c' }}>-{sim.caMarkovTransitions.forestToBuiltupHa} Ha</td>
                      </tr>
                      <tr>
                        <td>Waterbodies & Drainage Channels</td>
                        <td>{sim.baselineMetrics.waterHa} Ha</td>
                        <td style={{ fontWeight: 600 }}>{sim.projectedMetrics.waterHa} Ha</td>
                        <td style={{ color: '#059669' }}>
                          {sim.caMarkovTransitions.waterToBuiltupHa === 0 ? '100% Protected' : `-${sim.caMarkovTransitions.waterToBuiltupHa} Ha`}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Financial Liability Breakdown */}
            <div className="card">
              <div className="card-header">
                <div className="card-title">LARR Act 2013 Compensation Liability Breakdown</div>
              </div>
              <div className="card-body">
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', fontSize: '13.5px' }}>
                  <div>
                    <span style={{ color: '#64748b' }}>Acquired Agricultural Area:</span>
                    <div style={{ fontWeight: 600 }}>{sim.compensationEstimate.acquiredAgriculturalHa} Hectares</div>
                  </div>
                  <div>
                    <span style={{ color: '#64748b' }}>Multiplier Factor Applied:</span>
                    <div style={{ fontWeight: 600 }}>{sim.compensationEstimate.ruralMultiplierApplied}x (Rural Sector)</div>
                  </div>
                  <div>
                    <span style={{ color: '#64748b' }}>Base Assessed Market Value:</span>
                    <div style={{ fontWeight: 600 }}>₹{sim.compensationEstimate.baseMarketValueINR.toLocaleString()}</div>
                  </div>
                  <div>
                    <span style={{ color: '#64748b' }}>Mandatory 100% Solatium (Sec 30):</span>
                    <div style={{ fontWeight: 600, color: '#d97706' }}>₹{sim.compensationEstimate.mandatorySolatiumINR.toLocaleString()}</div>
                  </div>
                </div>

                <div style={{ marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontWeight: 700, fontSize: '15px', color: 'var(--gov-navy-950)' }}>
                    Total Estimated Acquisition Liability:
                  </span>
                  <span style={{ fontWeight: 800, fontSize: '18px', color: '#059669' }}>
                    ₹{sim.compensationEstimate.totalEstimatedLiabilityINR.toLocaleString()} INR
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
