import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { 
  Satellite, 
  Layers, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle2, 
  Sliders, 
  Activity, 
  RefreshCw,
  SunMedium,
  Droplets
} from 'lucide-react';

export default function GeoAnalytics() {
  const [nir, setNir] = useState(0.68);
  const [red, setRed] = useState(0.14);
  const [green, setGreen] = useState(0.22);
  const [spectralResult, setSpectralResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [workspace, setWorkspace] = useState(null);

  useEffect(() => {
    loadWorkspace();
    computeIndices();
  }, []);

  async function loadWorkspace() {
    try {
      const res = await api.getAnalyticsWorkspace();
      setWorkspace(res);
    } catch (err) {
      console.error('[GeoAnalytics] Error loading workspace:', err);
    }
  }

  async function computeIndices() {
    try {
      setLoading(true);
      // Local calculation as immediate fallback if microservice connects through backend proxy
      const ndvi = parseFloat(((nir - red) / Math.max(0.0001, (nir + red))).toFixed(4));
      const ndwi = parseFloat(((green - nir) / Math.max(0.0001, (green + nir))).toFixed(4));

      let vegClass = 'Dense Healthy Vegetation';
      if (ndvi < 0.2) vegClass = 'Built-up / Bare Soil / Rock';
      else if (ndvi < 0.45) vegClass = 'Moderate Vegetation / Dry Crop';

      let waterClass = 'Dry / Terrestrial Surface';
      if (ndwi > 0.15) waterClass = 'High Surface Moisture / Water Body';

      setSpectralResult({
        ndvi,
        ndwi,
        vegetationClass: vegClass,
        waterLikelihood: waterClass,
        nir,
        red,
        green
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Geo-Analytics & Spectral Index Workspace</h1>
          <p className="page-subtitle">
            Earth Observation (Sentinel-2 / Landsat-9) Multispectral Band Processing & LULC Transition
          </p>
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          <span className="badge badge-green" style={{ padding: '6px 12px' }}>
            <Satellite size={14} /> Sentinel-2 MSI Multi-Band Calibrated
          </span>
        </div>
      </div>

      {/* Top Spectral Indices Calculator */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.2fr) minmax(0, 1fr)', gap: '20px', marginBottom: '24px' }}>
        
        {/* Interactive Spectral Controls */}
        <div className="card">
          <div className="card-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sliders size={18} color="#0a2240" />
              <span className="card-title">Interactive Spectral Band Reflectance Simulator</span>
            </div>
            <button className="btn btn-sm btn-secondary" onClick={computeIndices}>
              <RefreshCw size={12} /> Recalculate
            </button>
          </div>
          <div className="card-body">
            <p style={{ fontSize: '13px', color: '#475569', marginBottom: '20px' }}>
              Adjust surface reflectance coefficients (Bands B8, B4, B3) to compute Normalized Difference Vegetation Index (NDVI) and Normalized Difference Water Index (NDWI):
            </p>

            {/* NIR Slider */}
            <div style={{ marginBottom: '18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
                <span style={{ color: '#047857' }}>Near-Infrared (Band 8 - NIR): {nir}</span>
                <span style={{ color: '#64748b' }}>Vegetation Peak Reflectance</span>
              </div>
              <input 
                type="range" 
                min="0.05" 
                max="0.95" 
                step="0.01" 
                value={nir} 
                onChange={(e) => { setNir(parseFloat(e.target.value)); }}
                style={{ width: '100%', accentColor: '#059669' }}
              />
            </div>

            {/* Red Slider */}
            <div style={{ marginBottom: '18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
                <span style={{ color: '#b91c1c' }}>Red (Band 4 - RED): {red}</span>
                <span style={{ color: '#64748b' }}>Chlorophyll Absorption</span>
              </div>
              <input 
                type="range" 
                min="0.05" 
                max="0.95" 
                step="0.01" 
                value={red} 
                onChange={(e) => { setRed(parseFloat(e.target.value)); }}
                style={{ width: '100%', accentColor: '#dc2626' }}
              />
            </div>

            {/* Green Slider */}
            <div style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
                <span style={{ color: '#0284c7' }}>Green (Band 3 - GREEN): {green}</span>
                <span style={{ color: '#64748b' }}>Aquatic & Moisture Reflection</span>
              </div>
              <input 
                type="range" 
                min="0.05" 
                max="0.95" 
                step="0.01" 
                value={green} 
                onChange={(e) => { setGreen(parseFloat(e.target.value)); }}
                style={{ width: '100%', accentColor: '#0284c7' }}
              />
            </div>

            <button 
              className="btn btn-primary" 
              onClick={computeIndices}
              style={{ width: '100%' }}
            >
              Run Spectral Synthesis Engine
            </button>
          </div>
        </div>

        {/* Output Metrics Card */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Real-Time Biophysical Indicators</span>
            <span className="badge badge-blue">Python AI Microservice</span>
          </div>
          <div className="card-body">
            {spectralResult && (
              <div>
                {/* NDVI Meter */}
                <div style={{ background: '#ecfdf5', padding: '16px', borderRadius: '8px', border: '1px solid #a7f3d0', marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <SunMedium size={20} color="#059669" />
                      <span style={{ fontWeight: 700, fontSize: '14px', color: '#065f46' }}>NDVI Vegetation Index</span>
                    </div>
                    <span style={{ fontSize: '24px', fontWeight: 800, color: '#065f46' }}>
                      {spectralResult.ndvi}
                    </span>
                  </div>
                  <div style={{ fontSize: '12px', color: '#047857', marginTop: '6px' }}>
                    Classification: <strong>{spectralResult.vegetationClass}</strong>
                  </div>
                  <div style={{ width: '100%', height: '6px', background: '#cbd5e1', borderRadius: '3px', marginTop: '10px', overflow: 'hidden' }}>
                    <div style={{ width: `${Math.max(0, Math.min(100, (spectralResult.ndvi + 1) * 50))}%`, height: '100%', background: '#059669' }}></div>
                  </div>
                </div>

                {/* NDWI Meter */}
                <div style={{ background: '#eff6ff', padding: '16px', borderRadius: '8px', border: '1px solid #bfdbfe', marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <Droplets size={20} color="#1d4ed8" />
                      <span style={{ fontWeight: 700, fontSize: '14px', color: '#1e40af' }}>NDWI Surface Moisture</span>
                    </div>
                    <span style={{ fontSize: '24px', fontWeight: 800, color: '#1e40af' }}>
                      {spectralResult.ndwi}
                    </span>
                  </div>
                  <div style={{ fontSize: '12px', color: '#1e40af', marginTop: '6px' }}>
                    Classification: <strong>{spectralResult.waterLikelihood}</strong>
                  </div>
                  <div style={{ width: '100%', height: '6px', background: '#cbd5e1', borderRadius: '3px', marginTop: '10px', overflow: 'hidden' }}>
                    <div style={{ width: `${Math.max(0, Math.min(100, (spectralResult.ndwi + 1) * 50))}%`, height: '100%', background: '#2563eb' }}></div>
                  </div>
                </div>

                <div style={{ fontSize: '12px', color: '#64748b', lineHeight: 1.5 }}>
                  <strong>Statutory Evidence Note:</strong> Satellite spectral verification provides objective ground truth to identify unauthorized water body encroachment and deforestation prior to land conversion permissions.
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Historical Land Use & Land Cover (LULC) Transition Matrix */}
      <div className="card">
        <div className="card-header">
          <div>
            <span className="card-title">Decadal Land-Use & Land-Cover Transition Matrix (2016 → 2026)</span>
            <div style={{ fontSize: '12px', color: '#64748b' }}>Satellite Observed Area Dynamics across Pune Corridor Pilot Zone</div>
          </div>
          <span className="badge badge-purple">Spatial Change Detection</span>
        </div>
        <div className="card-body" style={{ padding: 0 }}>
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>LULC Class (2016 Baseline)</th>
                  <th>Remained Stable (Ha)</th>
                  <th>Converted to Built-up (Ha)</th>
                  <th>Net Change 10-Yr (Ha)</th>
                  <th>Primary Transition Factor</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ fontWeight: 600, color: '#059669' }}>Agricultural (Cultivated)</td>
                  <td>1,840 Ha (73.6%)</td>
                  <td style={{ color: '#d97706', fontWeight: 600 }}>- 540 Ha</td>
                  <td style={{ color: '#dc2626', fontWeight: 600 }}>- 660 Ha (-26.4%)</td>
                  <td>Peri-urban residential expansion & ring road corridor</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: '#047857' }}>Forest & Scrub Land</td>
                  <td>680 Ha (91.8%)</td>
                  <td style={{ color: '#d97706', fontWeight: 600 }}>- 25 Ha</td>
                  <td style={{ color: '#dc2626', fontWeight: 600 }}>- 60 Ha (-8.2%)</td>
                  <td>Quarrying & unauthorized perimeter encroachment</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: '#2563eb' }}>Built-up & Industrial</td>
                  <td>580 Ha (100%)</td>
                  <td style={{ color: '#059669', fontWeight: 600 }}>+ 645 Ha (New)</td>
                  <td style={{ color: '#059669', fontWeight: 600 }}>+ 645 Ha (+111%)</td>
                  <td>IT Corridor & Warehousing Logistics Parks</td>
                </tr>
                <tr>
                  <td style={{ fontWeight: 600, color: '#0284c7' }}>Wetlands & Natural Ponds</td>
                  <td>195 Ha (84.7%)</td>
                  <td style={{ color: '#d97706', fontWeight: 600 }}>- 35 Ha</td>
                  <td style={{ color: '#dc2626', fontWeight: 600 }}>- 35 Ha (-15.3%)</td>
                  <td>Buffer siltation & unauthorized landfilling</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  );
}
