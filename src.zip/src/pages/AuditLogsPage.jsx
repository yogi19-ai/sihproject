import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Lock, 
  Info,
  Clock,
  KeyRound,
  FileCheck2
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function AuditLogsPage() {
  const { user, hasRole } = useAuth();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [verificationResult, setVerificationResult] = useState(null);
  const [verifying, setVerifying] = useState(false);
  const [actionFilter, setActionFilter] = useState('');

  useEffect(() => {
    if (hasRole(['Administrator'])) {
      loadLogs();
      verifyChain();
    }
  }, []);

  const loadLogs = async () => {
    try {
      setLoading(true);
      const res = await api.getAuditLogs({ limit: 50, action: actionFilter });
      setLogs(res.logs || []);
    } catch (err) {
      console.error('[AuditLogs] Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const verifyChain = async () => {
    try {
      setVerifying(true);
      const res = await api.verifyAuditChain();
      setVerificationResult(res);
    } catch (err) {
      console.error('[AuditLogs] Verification error:', err);
    } finally {
      setVerifying(false);
    }
  };

  if (!hasRole(['Administrator'])) {
    return (
      <div className="page-container" style={{ padding: '60px 20px', textAlign: 'center' }}>
        <div style={{ maxWidth: '500px', margin: '0 auto' }}>
          <div style={{ width: '50px', height: '50px', borderRadius: '50%', background: '#fee2e2', color: '#b91c1c', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
            <Lock size={24} />
          </div>
          <h2 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--gov-navy-950)', marginBottom: '8px' }}>
            Access Restricted: Administrator Privileges Required
          </h2>
          <p style={{ fontSize: '13.5px', color: '#64748b', lineHeight: '1.5' }}>
            The SHA-256 Tamper-Evident Audit Ledger records all system logins, parcel status modifications, dataset ingestions, and policy report hashes. It is strictly accessible to Authorized Revenue Officers and System Auditors.
          </p>
          <div style={{ marginTop: '20px' }}>
            <span style={{ fontSize: '12px', color: '#0f2f57' }}>
              Switch your simulation role to <strong>Administrator</strong> in the top header to inspect the ledger.
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">SHA-256 Tamper-Evident Audit Ledger</h1>
          <p className="page-subtitle">
            Cryptographically linked blockchain-style hash chain providing mathematical verification against historical log tampering.
          </p>
        </div>
        <button className="btn btn-primary" onClick={verifyChain} disabled={verifying}>
          <RefreshCw size={15} className={verifying ? 'spin' : ''} />
          {verifying ? 'Recomputing Hashes...' : 'Verify Cryptographic Integrity'}
        </button>
      </div>

      {/* Verification Verdict Banner */}
      {verificationResult && (
        <div className={`alert-banner ${verificationResult.isValid ? 'alert-success' : 'alert-warning'}`}>
          {verificationResult.isValid ? (
            <CheckCircle2 size={20} style={{ flexShrink: 0, marginTop: '2px', color: '#059669' }} />
          ) : (
            <AlertTriangle size={20} style={{ flexShrink: 0, marginTop: '2px', color: '#b91c1c' }} />
          )}
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: '14px', marginBottom: '2px' }}>
              {verificationResult.isValid 
                ? 'Cryptographic Verification Passed: All Blocks Intact and Unmodified' 
                : 'Warning: Hash Inconsistency Detected in Audit Chain'}
            </div>
            <div style={{ fontSize: '12.5px', color: 'var(--text-secondary)' }}>
              Verified {verificationResult.totalEntries} sequential entries from Genesis Block. Latest Hash: <span style={{ fontFamily: 'monospace' }}>{verificationResult.latestHash?.substring(0, 32)}...</span>
            </div>
          </div>
        </div>
      )}

      {/* Enterprise Ledger Note */}
      <div className="card" style={{ padding: '16px 20px', marginBottom: '20px', background: 'var(--bg-subtle)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <KeyRound size={18} color="#0f2f57" />
          <div style={{ fontSize: '12.5px', color: 'var(--text-secondary)' }}>
            <strong>Enterprise Immutability Note:</strong> While SHA-256 hash chaining prevents post-hoc insertion or deletion of ledger events, production state-level deployment requires external anchoring to Write-Once-Read-Many (WORM) storage or an authorized state distributed ledger to prevent full-ledger rewrites by root infrastructure administrators.
          </div>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">Sequenced Audit Events ({logs.length})</div>
          <span className="badge badge-green">SHA-256 Hash Chained</span>
        </div>
        <div className="card-body" style={{ padding: '0' }}>
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Block #</th>
                  <th>Timestamp</th>
                  <th>Actor ID</th>
                  <th>Role Tier</th>
                  <th>Action Event</th>
                  <th>Entity Target</th>
                  <th>SHA-256 Current Block Digest</th>
                  <th>Previous Block Digest</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log) => (
                  <tr key={log.index}>
                    <td style={{ fontWeight: 700, color: 'var(--gov-navy-900)' }}>#{log.index}</td>
                    <td style={{ fontSize: '12px', whiteSpace: 'nowrap' }}>
                      <Clock size={12} style={{ display: 'inline', marginRight: '4px', color: '#64748b' }} />
                      {new Date(log.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'medium' })}
                    </td>
                    <td style={{ fontSize: '12px', fontWeight: 500 }}>{log.actorId}</td>
                    <td>
                      <span className={`badge ${log.actorRole === 'Administrator' ? 'badge-amber' : (log.actorRole === 'Researcher' ? 'badge-blue' : 'badge-green')}`}>
                        {log.actorRole}
                      </span>
                    </td>
                    <td style={{ fontWeight: 600, color: 'var(--gov-navy-950)' }}>{log.action}</td>
                    <td style={{ fontSize: '12px' }}>{log.entityType} ({log.entityId})</td>
                    <td style={{ fontFamily: 'monospace', fontSize: '11px', color: '#059669' }}>
                      {log.currentHash?.substring(0, 18)}...
                    </td>
                    <td style={{ fontFamily: 'monospace', fontSize: '11px', color: '#64748b' }}>
                      {log.prevHash?.substring(0, 18)}...
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
