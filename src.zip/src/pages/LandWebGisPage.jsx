import React, { useState, useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { 
  Search, 
  Layers, 
  Info, 
  Maximize2, 
  RotateCcw, 
  CheckCircle, 
  AlertCircle, 
  ShieldCheck, 
  Copy,
  Zap
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function LandWebGisPage() {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const { user, hasRole } = useAuth();

  const [parcels, setParcels] = useState([]);
  const [selectedParcel, setSelectedParcel] = useState(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResultNotice, setSearchResultNotice] = useState('');
  const [benchmarkStatus, setBenchmarkStatus] = useState('');

  // Layer Visibility
  const [layers, setLayers] = useState({
    parcels: true,
    administrative: true,
    waterbodies: true,
    forestBuffer: true,
    infrastructure: true
  });

  const [mapStyle, setMapStyle] = useState('osm');

  useEffect(() => {
    if (map.current) return;

    // Initialize MapLibre GL
    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: {
        version: 8,
        sources: {
          'osm-tiles': {
            type: 'raster',
            tiles: [
              'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            ],
            tileSize: 256,
            attribution: '© OpenStreetMap contributors | Bhuvan ISRO Standards'
          }
        },
        layers: [
          {
            id: 'osm-layer',
            type: 'raster',
            source: 'osm-tiles',
            minzoom: 0,
            maxzoom: 19
          }
        ]
      },
      center: [77.5, 20.5], // Center of India
      zoom: 4.8
    });

    map.current.addControl(new maplibregl.NavigationControl({ showCompass: true }), 'bottom-right');

    map.current.on('load', () => {
      loadParcelsInViewport();
    });

    map.current.on('moveend', () => {
      loadParcelsInViewport();
    });

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, []);

  // Update GeoJSON source whenever parcels change
  useEffect(() => {
    if (!map.current || !map.current.isStyleLoaded()) return;

    const geojsonFeatures = parcels.map(p => {
      const coords = p.polygon ? [p.polygon] : [
        [
          [p.centroidLng - 0.003, p.centroidLat - 0.003],
          [p.centroidLng + 0.003, p.centroidLat - 0.003],
          [p.centroidLng + 0.003, p.centroidLat + 0.003],
          [p.centroidLng - 0.003, p.centroidLat + 0.003],
          [p.centroidLng - 0.003, p.centroidLat - 0.003]
        ]
      ];

      return {
        type: 'Feature',
        properties: {
          id: p.id,
          ulpin: p.ulpin,
          surveyNumber: p.surveyNumber,
          village: p.village,
          district: p.district,
          state: p.state,
          landUseClass: p.landUseClass,
          areaSqm: p.areaSqm,
          verifiedStatus: p.verifiedStatus,
          ndvi: p.ndviCurrent
        },
        geometry: {
          type: 'Polygon',
          coordinates: coords
        }
      };
    });

    const featureCollection = {
      type: 'FeatureCollection',
      features: geojsonFeatures
    };

    if (map.current.getSource('parcels-source')) {
      map.current.getSource('parcels-source').setData(featureCollection);
    } else {
      map.current.addSource('parcels-source', {
        type: 'geojson',
        data: featureCollection
      });

      // Fill Layer
      map.current.addLayer({
        id: 'parcels-fill',
        type: 'fill',
        source: 'parcels-source',
        paint: {
          'fill-color': [
            'match',
            ['get', 'landUseClass'],
            'Agricultural', '#f59e0b',
            'IT / High-Tech SEZ', '#3b82f6',
            'Commercial / Logistics', '#8b5cf6',
            'Reserved Forest Buffer', '#10b981',
            'Wetland Buffer / Waterbody', '#06b6d4',
            '#0f2f57'
          ],
          'fill-opacity': 0.45
        }
      });

      // Outline Layer
      map.current.addLayer({
        id: 'parcels-line',
        type: 'line',
        source: 'parcels-source',
        paint: {
          'line-color': '#0f2f57',
          'line-width': 2
        }
      });

      // Click to inspect parcel
      map.current.on('click', 'parcels-fill', (e) => {
        if (e.features && e.features[0]) {
          const clickedUlpin = e.features[0].properties.ulpin;
          fetchParcelDetails(clickedUlpin);
        }
      });

      // Cursor pointer on hover
      map.current.on('mouseenter', 'parcels-fill', () => {
        map.current.getCanvas().style.cursor = 'pointer';
      });
      map.current.on('mouseleave', 'parcels-fill', () => {
        map.current.getCanvas().style.cursor = '';
      });
    }
  }, [parcels]);

  const loadParcelsInViewport = async (scaleDemoCount = null) => {
    if (!map.current) return;
    try {
      setLoading(true);
      const bounds = map.current.getBounds();
      const params = {
        minLat: bounds.getSouth(),
        maxLat: bounds.getNorth(),
        minLng: bounds.getWest(),
        maxLng: bounds.getEast(),
        limit: 200
      };

      if (scaleDemoCount) {
        params.scaleDemo = scaleDemoCount;
      }

      const res = await api.getParcelsByBbox(params);
      setParcels(res.parcels || []);
      if (scaleDemoCount) {
        setBenchmarkStatus(`Rendered ${res.count} parcels across viewport with active spatial index.`);
      }
    } catch (err) {
      console.error('[WebGIS] Bbox fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchParcelDetails = async (ulpin) => {
    try {
      setLoading(true);
      const res = await api.getParcelByUlpin(ulpin);
      if (res.found) {
        setSelectedParcel(res.parcel);
        setSearchResultNotice('');
        // Fly to parcel centroid
        if (map.current && res.parcel.centroidLat && res.parcel.centroidLng) {
          map.current.flyTo({
            center: [res.parcel.centroidLng, res.parcel.centroidLat],
            zoom: 15,
            duration: 1200
          });
        }
      }
    } catch (err) {
      console.error('[WebGIS] Parcel detail error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setSearchResultNotice('');
    try {
      // 1. Check if input is a 14-digit ULPIN
      const clean = searchQuery.trim().toUpperCase();
      const res = await api.getParcelByUlpin(clean);
      if (res.found) {
        setSelectedParcel(res.parcel);
        if (map.current && res.parcel.centroidLat && res.parcel.centroidLng) {
          map.current.flyTo({
            center: [res.parcel.centroidLng, res.parcel.centroidLat],
            zoom: 15,
            duration: 1400
          });
        }
        setSearchResultNotice(`ULPIN ${clean} located.`);
      } else {
        // Fallback search by village/district
        const matching = parcels.find(p => 
          p.village.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.district.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.surveyNumber.includes(searchQuery)
        );
        if (matching) {
          setSelectedParcel(matching);
          map.current.flyTo({
            center: [matching.centroidLng, matching.centroidLat],
            zoom: 14,
            duration: 1400
          });
          setSearchResultNotice(`Location located: ${matching.village}, ${matching.district}.`);
        } else {
          setSearchResultNotice(`No matching parcel or location found for "${searchQuery}".`);
        }
      }
    } catch (err) {
      setSearchResultNotice(`Search failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyParcel = async (newStatus) => {
    if (!selectedParcel) return;
    try {
      setLoading(true);
      const res = await api.updateParcelVerification(selectedParcel.ulpin, newStatus, 'Verified by Authorized Officer');
      setSelectedParcel(res.parcel);
      // Update in local state
      setParcels(parcels.map(p => p.ulpin === selectedParcel.ulpin ? res.parcel : p));
      alert(`Parcel ${selectedParcel.ulpin} verification status updated to '${newStatus}'.`);
    } catch (err) {
      alert(`Failed to update status: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const resetView = () => {
    if (map.current) {
      map.current.flyTo({ center: [77.5, 20.5], zoom: 4.8, duration: 1000 });
    }
  };

  const toggleLayer = (layerKey) => {
    const updated = !layers[layerKey];
    setLayers({ ...layers, [layerKey]: updated });
    if (map.current && map.current.getLayer('parcels-fill')) {
      if (layerKey === 'parcels') {
        map.current.setLayoutProperty('parcels-fill', 'visibility', updated ? 'visible' : 'none');
        map.current.setLayoutProperty('parcels-line', 'visibility', updated ? 'visible' : 'none');
      }
    }
  };

  return (
    <div className="page-container" style={{ paddingBottom: '10px' }}>
      <div className="page-header" style={{ marginBottom: '16px' }}>
        <div>
          <h1 className="page-title">Interactive Land WebGIS</h1>
          <p className="page-subtitle">
            High-density vector cadastral engine with 14-digit ULPIN lookup, ISRO Bhuvan overlays, and viewport spatial indexing.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button 
            className="btn btn-secondary btn-sm" 
            onClick={() => loadParcelsInViewport(500)}
            title="Benchmark WebGIS parcel rendering performance"
          >
            <Zap size={14} color="#d97706" />
            Benchmark 500+ Parcels
          </button>
          <button className="btn btn-secondary btn-sm" onClick={resetView}>
            <RotateCcw size={14} />
            Reset View
          </button>
        </div>
      </div>

      {benchmarkStatus && (
        <div className="alert-banner alert-info" style={{ padding: '8px 14px', marginBottom: '10px' }}>
          <Info size={16} />
          <span><strong>Scalability Test:</strong> {benchmarkStatus}</span>
        </div>
      )}

      {/* Main WebGIS Viewer */}
      <div className="gis-container">
        {/* Map View */}
        <div ref={mapContainer} className="gis-map" />

        {/* Floating Controls Overlay */}
        <div className="gis-controls-overlay">
          <form className="gis-search-box" onSubmit={handleSearch}>
            <Search size={16} color="#64748b" />
            <input
              type="text"
              placeholder="Search 14-digit ULPIN, Village, or District..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>

          {searchResultNotice && (
            <div style={{ background: '#ffffff', padding: '6px 12px', borderRadius: '6px', fontSize: '12px', color: '#0f2f57', boxShadow: '0 2px 6px rgba(0,0,0,0.1)' }}>
              {searchResultNotice}
            </div>
          )}

          {/* Layer Controls Panel */}
          <div className="gis-layer-panel">
            <div className="gis-layer-title">Map Layers</div>
            <label className="gis-layer-item">
              <input type="checkbox" checked={layers.parcels} onChange={() => toggleLayer('parcels')} />
              <div className="gis-layer-color-dot" style={{ background: '#f59e0b' }} />
              <span>Cadastral Parcels</span>
            </label>
            <label className="gis-layer-item">
              <input type="checkbox" checked={layers.administrative} onChange={() => toggleLayer('administrative')} />
              <div className="gis-layer-color-dot" style={{ background: '#0f2f57' }} />
              <span>Administrative Boundaries</span>
            </label>
            <label className="gis-layer-item">
              <input type="checkbox" checked={layers.waterbodies} onChange={() => toggleLayer('waterbodies')} />
              <div className="gis-layer-color-dot" style={{ background: '#06b6d4' }} />
              <span>Wetlands / Waterbodies</span>
            </label>
            <label className="gis-layer-item">
              <input type="checkbox" checked={layers.forestBuffer} onChange={() => toggleLayer('forestBuffer')} />
              <div className="gis-layer-color-dot" style={{ background: '#10b981' }} />
              <span>Forest Eco-Buffer Zones</span>
            </label>
            <label className="gis-layer-item">
              <input type="checkbox" checked={layers.infrastructure} onChange={() => toggleLayer('infrastructure')} />
              <div className="gis-layer-color-dot" style={{ background: '#8b5cf6' }} />
              <span>PM GatiShakti Corridors</span>
            </label>
          </div>
        </div>

        {/* Parcel Inspection Drawer */}
        {selectedParcel && (
          <div className="gis-drawer">
            <div className="gis-drawer-header">
              <div>
                <div style={{ fontSize: '11px', textTransform: 'uppercase', color: '#64748b', fontWeight: 600 }}>
                  Cadastral Parcel Inspector
                </div>
                <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                  Survey #{selectedParcel.surveyNumber}
                </div>
              </div>
              <button 
                onClick={() => setSelectedParcel(null)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px', color: '#64748b' }}
              >
                ✕
              </button>
            </div>

            <div className="gis-drawer-body">
              <div className="data-field-group">
                <span className="data-field-label">14-Digit ULPIN (Bhu-Aadhaar)</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span className="data-field-value mono">{selectedParcel.ulpin}</span>
                  <button 
                    className="btn btn-secondary btn-sm" 
                    onClick={() => navigator.clipboard.writeText(selectedParcel.ulpin)}
                    title="Copy ULPIN"
                    style={{ padding: '4px 8px' }}
                  >
                    <Copy size={13} />
                  </button>
                </div>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Administrative Jurisdiction</span>
                <span className="data-field-value">
                  {selectedParcel.village}, {selectedParcel.subDistrict}, {selectedParcel.district}, {selectedParcel.state}
                </span>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="data-field-group">
                  <span className="data-field-label">Area (Hectares)</span>
                  <span className="data-field-value" style={{ fontWeight: 700, color: '#059669' }}>
                    {(selectedParcel.areaSqm / 10000.0).toFixed(4)} Ha
                  </span>
                </div>
                <div className="data-field-group">
                  <span className="data-field-label">Area (Acres)</span>
                  <span className="data-field-value">
                    {(selectedParcel.areaSqm / 4046.8564).toFixed(4)} Acres
                  </span>
                </div>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Land-Use Classification</span>
                <span className="data-field-value" style={{ fontWeight: 600 }}>
                  {selectedParcel.landUseClass}
                </span>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Ownership Classification</span>
                <span className="data-field-value" style={{ fontSize: '13px' }}>
                  {selectedParcel.ownershipCategory}
                </span>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Satellite Indices</span>
                <div style={{ display: 'flex', gap: '10px', fontSize: '13px' }}>
                  <span className="badge badge-green">NDVI: {selectedParcel.ndviCurrent}</span>
                  <span className="badge badge-blue">NDWI: {selectedParcel.ndwiCurrent}</span>
                </div>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Verification Tier</span>
                <div>
                  <span className={`badge ${selectedParcel.verifiedStatus === 'Verified' ? 'badge-green' : (selectedParcel.verifiedStatus === 'Demonstration' ? 'badge-amber' : 'badge-blue')}`}>
                    {selectedParcel.verifiedStatus} Record
                  </span>
                </div>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Source Cadastre</span>
                <span className="data-field-value" style={{ fontSize: '12.5px', color: '#64748b' }}>
                  {selectedParcel.sourceAgency} (Surveyed: {selectedParcel.lastSurveyDate})
                </span>
              </div>

              {/* Administrator Action Button */}
              {hasRole(['Administrator']) && (
                <div style={{ marginTop: '10px', paddingTop: '16px', borderTop: '1px solid #e2e8f0' }}>
                  <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--gov-navy-900)', marginBottom: '8px' }}>
                    Officer Verification Action
                  </div>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button 
                      className="btn btn-primary btn-sm" 
                      style={{ flex: 1 }}
                      onClick={() => handleVerifyParcel('Verified')}
                    >
                      <ShieldCheck size={14} />
                      Approve & Verify
                    </button>
                    <button 
                      className="btn btn-secondary btn-sm"
                      onClick={() => handleVerifyParcel('Demonstration')}
                    >
                      Mark Demo
                    </button>
                  </div>
                </div>
              )}

              <div style={{ fontSize: '11px', color: '#94a3b8', lineHeight: '1.4', marginTop: 'auto' }}>
                Note: Parcel boundaries are spatial coordinates derived from State Bhulekh digitized maps. Legal disputes are adjudicated per certified revenue extract copies.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
