import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Search, 
  Lock, 
  Link, 
  FileCode, 
  X,
  ExternalLink
} from 'lucide-react';

export default function AuditLogs() {
  const { user, hasRole } = useAuth();
  const [logs, setLogs] = useState([]);
  const [verification, setVerification] = useState(null);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState(false);
  const [selectedBlock, setSelectedBlock] = useState(null);
  const [searchAction, setSearchAction] = useState('');

  useEffect(() => {
    loadAuditData();
  }, []);

  async function loadAuditData() {
    try {
      setLoading(true);
      const [logsRes, verifyRes] = await Promise.all([
        api.getAuditLogs({ limit: 50 }),
        api.verifyAuditChain()
      ]);
      setLogs(logsRes.logs || []);
      setVerification(verifyRes);
    } catch (err) {
      console.error('[AuditLogs] Error:', err);
    } finally {
      setLoading(false);
    }
  }

  const handleVerifyChain = async () => {
    try {
      setVerifying(true);
      const res = await api.verifyAuditChain();
      setVerification(res);
      alert(`Ledger Cryptographic Audit Complete!\nStatus: ${res.status}\nTotal Blocks Checked: ${res.totalEntries}\nIntegrity Verified: ${res.isValid ? 'YES (Tamper-Free)' : 'NO'}`);
    } catch (err) {
      alert('Verification error: ' + err.message);
    } finally {
      setVerifying(false);
    }
  };

  const filteredLogs = logs.filter(l => 
    l.action?.toLowerCase().includes(searchAction.toLowerCase()) ||
    l.userEmail?.toLowerCase().includes(searchAction.toLowerCase()) ||
    l.blockHash?.toLowerCase().includes(searchAction.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">SHA-256 Tamper-Evident Cryptographic Ledger</h1>
          <p className="page-subtitle">
            Immutable Audit Trail for Land Administration, Field Verifications, and Cross-Agency Mutations
          </p>
        </div>

        <button 
          className="btn btn-primary" 
          onClick={handleVerifyChain}
          disabled={verifying}
        >
          <RefreshCw size={15} className={verifying ? 'animate-spin' : ''} /> 
          {verifying ? 'Computing SHA-256 Digests...' : 'Verify Entire Chain Integrity'}
        </button>
      </div>

      {/* Chain Status Card */}
      {verification && (
        <div className="card" style={{ marginBottom: '24px', background: verification.isValid ? 'linear-gradient(135deg, #07172b 0%, #0a2240 100%)' : '#450a0a', color: '#ffffff' }}>
          <div className="card-body" style={{ padding: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: verification.isValid ? 'rgba(5, 150, 105, 0.2)' : 'rgba(239, 68, 68, 0.2)', border: `2px solid ${verification.isValid ? '#059669' : '#ef4444'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {verification.isValid ? <ShieldCheck size={26} color="#10b981" /> : <AlertTriangle size={26} color="#ef4444" />}
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>
                    Cryptographic Assurance Protocol
                  </div>
                  <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#ffffff', margin: '2px 0' }}>
                    {verification.isValid ? 'Cryptographic Chain Integrity Confirmed' : 'Audit Chain Discrepancy Detected'}
                  </h2>
                  <div style={{ fontSize: '13px', color: '#cbd5e1' }}>
                    Every block mathematically binds to the preceding SHA-256 hash digest. Total {verification.totalEntries} validated blocks.
                  </div>
                </div>
              </div>

              <div style={{ background: 'rgba(255, 255, 255, 0.08)', padding: '12px 18px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)' }}>
                <div style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 600 }}>Latest Block Digest</div>
                <div style={{ fontFamily: 'monospace', fontSize: '12.5px', color: '#38bdf8', marginTop: '4px' }}>
                  {verification.latestHash ? `${verification.latestHash.substring(0, 28)}...` : 'N/A'}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Block Explorer Table */}
      <div className="card">
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span className="card-title">Block Explorer & Event Sequence ({filteredLogs.length})</span>
            <div style={{ position: 'relative', width: '260px' }}>
              <input 
                type="text" 
                className="form-control"
                placeholder="Search action or hash..." 
                value={searchAction}
                onChange={(e) => setSearchAction(e.target.value)}
                style={{ height: '34px', fontSize: '12.5px', paddingLeft: '32px' }}
              />
              <Search size={14} style={{ position: 'absolute', left: '10px', top: '10px', color: '#94a3b8' }} />
            </div>
          </div>

          <span className="badge badge-green">Tamper-Proof Chained</span>
        </div>

        <div className="card-body" style={{ padding: 0 }}>
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Block #</th>
                  <th>Action / Event</th>
                  <th>Actor Persona</th>
                  <th>Timestamp</th>
                  <th>Previous Hash (Digest)</th>
                  <th>Block Hash (SHA-256)</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                {filteredLogs.map(log => (
                  <tr key={log.blockIndex}>
                    <td>
                      <span className="badge badge-purple" style={{ fontFamily: 'monospace' }}>
                        #{log.blockIndex}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{log.action}</div>
                    </td>
                    <td>
                      <div style={{ fontSize: '12.5px', fontWeight: 500 }}>{log.userEmail}</div>
                      <span className="badge badge-blue" style={{ fontSize: '10px' }}>{log.userRole}</span>
                    </td>
                    <td style={{ fontSize: '12px', color: '#64748b', whiteSpace: 'nowrap' }}>
                      {log.timestamp ? new Date(log.timestamp).toLocaleString() : 'N/A'}
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#64748b' }}>
                        {log.previousHash ? `${log.previousHash.substring(0, 12)}...` : '0 (Genesis)'}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontSize: '11px', color: '#0369a1', fontWeight: 600 }}>
                        {log.blockHash ? `${log.blockHash.substring(0, 16)}...` : '-'}
                      </span>
                    </td>
                    <td>
                      <button 
                        className="btn btn-sm btn-secondary"
                        onClick={() => setSelectedBlock(log)}
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Block Payload Modal */}
      {selectedBlock && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Block #{selectedBlock.blockIndex}: {selectedBlock.action}
              </h3>
              <button onClick={() => setSelectedBlock(null)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>
            <div className="modal-body">
              <div className="data-field-group" style={{ marginBottom: '14px' }}>
                <span className="data-field-label">Current Block SHA-256 Hash</span>
                <span className="data-field-value mono" style={{ wordBreak: 'break-all' }}>
                  {selectedBlock.blockHash}
                </span>
              </div>

              <div className="data-field-group" style={{ marginBottom: '14px' }}>
                <span className="data-field-label">Preceding Block Hash (Chained)</span>
                <span className="data-field-value mono" style={{ wordBreak: 'break-all' }}>
                  {selectedBlock.previousHash || '0000000000000000000000000000000000000000000000000000000000000000'}
                </span>
              </div>

              <div className="data-field-group" style={{ marginBottom: '14px' }}>
                <span className="data-field-label">Actor & Role</span>
                <div style={{ fontSize: '13.5px', marginTop: '2px' }}>
                  <strong>{selectedBlock.userEmail}</strong> ({selectedBlock.userRole})
                </div>
              </div>

              <div className="data-field-group">
                <span className="data-field-label">Sanitized Event Details Payload</span>
                <pre style={{ background: '#0f172a', color: '#f8fafc', padding: '14px', borderRadius: '6px', fontSize: '12px', overflowX: 'auto', marginTop: '6px' }}>
                  {JSON.stringify(selectedBlock.details || {}, null, 2)}
                </pre>
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setSelectedBlock(null)}>
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
