import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Upload, 
  Filter, 
  Search, 
  FileCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Info,
  ExternalLink,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function LandRecordsPage() {
  const [datasets, setDatasets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDataset, setSelectedDataset] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  // Upload Wizard State
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadAgency, setUploadAgency] = useState('');
  const [uploadState, setUploadState] = useState('Maharashtra');
  const [uploadCategory, setUploadCategory] = useState('Cadastral & RoR');
  const [uploadContent, setUploadContent] = useState('');
  const [uploadResult, setUploadResult] = useState(null);
  const [uploading, setUploading] = useState(false);

  const { user, hasRole } = useAuth();

  useEffect(() => {
    loadDatasets();
  }, [categoryFilter]);

  const loadDatasets = async () => {
    try {
      setLoading(true);
      const res = await api.getDatasets({ category: categoryFilter, search: searchQuery });
      setDatasets(res.datasets || []);
    } catch (err) {
      console.error('[LandRecords] Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    loadDatasets();
  };

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (!uploadTitle || !uploadAgency) return;

    try {
      setUploading(true);
      const res = await api.uploadDataset({
        title: uploadTitle,
        sourceAgency: uploadAgency,
        coverageState: uploadState,
        category: uploadCategory,
        rawContent: uploadContent,
        format: 'CSV / GeoJSON'
      });
      setUploadResult(res);
      loadDatasets();
    } catch (err) {
      alert(`Ingestion failed: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Land Records & Data Catalogue</h1>
          <p className="page-subtitle">
            Harmonized repository of State Bhulekh RoRs, ISRO Bhuvan satellite rasters, Survey of India geodetic reference networks, and PM GatiShakti corridors.
          </p>
        </div>
        {hasRole(['Administrator', 'Researcher']) && (
          <button 
            className="btn btn-primary"
            onClick={() => {
              setUploadResult(null);
              setShowUploadModal(true);
            }}
          >
            <Upload size={16} />
            Ingest New Dataset
          </button>
        )}
      </div>

      <div className="alert-banner alert-info">
        <Info size={18} style={{ flexShrink: 0 }} />
        <div>
          <strong>Interoperability & Data Governance:</strong> All incoming cadastral packages undergo schema normalization, 14-digit ULPIN checksum validation, and CRS transformation to EPSG:4326. Personal identifiers are minimized per public data protection principles.
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="card" style={{ padding: '16px 20px', marginBottom: '20px' }}>
        <form onSubmit={handleSearchSubmit} style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '240px' }}>
            <input
              type="text"
              className="form-control"
              placeholder="Search datasets by agency, title, or keywords..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <select
            className="form-control"
            style={{ width: '200px' }}
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="Cadastral">Cadastral & RoR</option>
            <option value="Satellite">Geospatial Satellite Raster</option>
            <option value="Infrastructure">Infrastructure Planning</option>
            <option value="Geodetic">Geodetic Reference</option>
          </select>

          <button type="submit" className="btn btn-secondary">
            <Search size={15} />
            Filter
          </button>
        </form>
      </div>

      {/* Dataset Table */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">Indexed Government Datasets ({datasets.length})</div>
          <span className="badge badge-green">OGC Standards Compliant</span>
        </div>
        <div className="card-body" style={{ padding: '0' }}>
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Dataset Name</th>
                  <th>Source Authority</th>
                  <th>State Coverage</th>
                  <th>Category</th>
                  <th>Records</th>
                  <th>Quality Score</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {datasets.map(ds => (
                  <tr key={ds.id}>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{ds.title}</div>
                      <div style={{ fontSize: '11.5px', color: '#64748b' }}>License: {ds.licenseInfo}</div>
                    </td>
                    <td style={{ fontSize: '13px' }}>{ds.sourceAgency}</td>
                    <td>{ds.coverageState}</td>
                    <td><span className="badge badge-amber">{ds.category}</span></td>
                    <td style={{ fontWeight: 500 }}>{ds.recordsCount ? ds.recordsCount.toLocaleString() : 'N/A'}</td>
                    <td style={{ fontWeight: 600, color: '#059669' }}>{ds.qualityScore}%</td>
                    <td>
                      <span className={`badge ${ds.verificationStatus === 'Verified' ? 'badge-green' : 'badge-blue'}`}>
                        {ds.verificationStatus}
                      </span>
                    </td>
                    <td>
                      <button 
                        className="btn btn-secondary btn-sm"
                        onClick={() => setSelectedDataset(ds)}
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Dataset Inspection Modal */}
      {selectedDataset && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <div className="modal-header">
              <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Dataset Metadata & Provenance
              </div>
              <button 
                onClick={() => setSelectedDataset(null)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px' }}
              >
                ✕
              </button>
            </div>
            <div className="modal-body">
              <h3 style={{ fontSize: '17px', color: 'var(--gov-navy-900)', marginBottom: '8px' }}>
                {selectedDataset.title}
              </h3>
              <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
                {selectedDataset.sourceAgency} • Coverage: {selectedDataset.coverageState}
              </p>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '16px' }}>
                <div className="data-field-group">
                  <span className="data-field-label">File Format</span>
                  <span className="data-field-value">{selectedDataset.format}</span>
                </div>
                <div className="data-field-group">
                  <span className="data-field-label">Approx Size</span>
                  <span className="data-field-value">{selectedDataset.fileSizeMb} MB</span>
                </div>
                <div className="data-field-group">
                  <span className="data-field-label">Schema Quality Score</span>
                  <span className="data-field-value" style={{ color: '#059669', fontWeight: 700 }}>
                    {selectedDataset.qualityScore}%
                  </span>
                </div>
                <div className="data-field-group">
                  <span className="data-field-label">Licence Standard</span>
                  <span className="data-field-value">{selectedDataset.licenseInfo}</span>
                </div>
              </div>

              <div className="data-field-group" style={{ marginBottom: '16px' }}>
                <span className="data-field-label">Technical Metadata</span>
                <pre style={{ background: '#f8fafc', padding: '10px', borderRadius: '6px', fontSize: '12px', border: '1px solid #e2e8f0', overflowX: 'auto' }}>
                  {JSON.stringify(selectedDataset.metadata, null, 2)}
                </pre>
              </div>

              <div className="alert-banner alert-warning" style={{ fontSize: '12px', padding: '10px 14px' }}>
                <AlertTriangle size={15} style={{ flexShrink: 0 }} />
                <span>Notice: Official legal use requires matching with stamped revenue extracts issued by the competent Sub-Divisional Magistrate (SDM) or Tahsildar.</span>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setSelectedDataset(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload & Normalization Wizard Modal */}
      {showUploadModal && (
        <div className="modal-backdrop">
          <div className="modal-content" style={{ maxWidth: '750px' }}>
            <div className="modal-header">
              <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--gov-navy-900)' }}>
                Cadastral Ingestion & Schema Normalization Wizard
              </div>
              <button 
                onClick={() => setShowUploadModal(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px' }}
              >
                ✕
              </button>
            </div>
            
            <form onSubmit={handleUploadSubmit}>
              <div className="modal-body">
                {!uploadResult ? (
                  <>
                    <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
                      Upload or paste cadastral CSV / GeoJSON data. The system automatically validates 14-digit ULPIN checksums, removes duplicates, and standardizes coordinates to WGS84.
                    </p>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                      <div className="form-group">
                        <label className="form-label">Dataset Title *</label>
                        <input
                          type="text"
                          className="form-control"
                          required
                          placeholder="e.g. Pune Haveli RoR Sub-Division Batch 2026"
                          value={uploadTitle}
                          onChange={(e) => setUploadTitle(e.target.value)}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Source Agency *</label>
                        <input
                          type="text"
                          className="form-control"
                          required
                          placeholder="e.g. Mahabhumi Land Records Directorate"
                          value={uploadAgency}
                          onChange={(e) => setUploadAgency(e.target.value)}
                        />
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                      <div className="form-group">
                        <label className="form-label">Coverage State</label>
                        <select 
                          className="form-control"
                          value={uploadState}
                          onChange={(e) => setUploadState(e.target.value)}
                        >
                          <option value="Maharashtra">Maharashtra</option>
                          <option value="Uttar Pradesh">Uttar Pradesh</option>
                          <option value="Karnataka">Karnataka</option>
                          <option value="Gujarat">Gujarat</option>
                          <option value="Odisha">Odisha</option>
                        </select>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Category</label>
                        <select 
                          className="form-control"
                          value={uploadCategory}
                          onChange={(e) => setUploadCategory(e.target.value)}
                        >
                          <option value="Cadastral & RoR">Cadastral & RoR</option>
                          <option value="Geospatial Satellite Raster">Geospatial Satellite Raster</option>
                          <option value="Infrastructure Planning">Infrastructure Planning</option>
                        </select>
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Cadastral CSV Data (Header: ULPIN, Survey, District, State)</label>
                      <textarea
                        className="form-control"
                        style={{ height: '120px', fontFamily: 'monospace', fontSize: '12px' }}
                        placeholder="ULPIN,Survey,District,State&#10;MH26000190012A,142/2A,Pune,Maharashtra&#10;MH26000290023B,142/2B,Pune,Maharashtra"
                        value={uploadContent}
                        onChange={(e) => setUploadContent(e.target.value)}
                      />
                    </div>
                  </>
                ) : (
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#059669', marginBottom: '14px' }}>
                      <CheckCircle2 size={24} />
                      <div style={{ fontSize: '16px', fontWeight: 700 }}>Ingestion & Normalization Complete</div>
                    </div>

                    <div className="alert-banner alert-success">
                      <div>{uploadResult.message}</div>
                    </div>

                    <div className="table-responsive" style={{ marginBottom: '16px' }}>
                      <table className="data-table">
                        <tbody>
                          <tr>
                            <th>Total Processed</th>
                            <td>{uploadResult.ingestionReport.totalRecordsProcessed} Records</td>
                          </tr>
                          <tr>
                            <th>Valid 14-Digit ULPINs</th>
                            <td style={{ color: '#059669', fontWeight: 600 }}>{uploadResult.ingestionReport.validUlpins}</td>
                          </tr>
                          <tr>
                            <th>Syntax Warnings</th>
                            <td style={{ color: '#b91c1c' }}>{uploadResult.ingestionReport.invalidUlpins}</td>
                          </tr>
                          <tr>
                            <th>Schema Quality</th>
                            <td style={{ fontWeight: 700 }}>{uploadResult.ingestionReport.qualityScore}%</td>
                          </tr>
                          <tr>
                            <th>Target Projection</th>
                            <td>{uploadResult.ingestionReport.coordinateReferenceSystem}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>

              <div className="modal-footer">
                {!uploadResult ? (
                  <>
                    <button type="button" className="btn btn-secondary" onClick={() => setShowUploadModal(false)}>
                      Cancel
                    </button>
                    <button type="submit" className="btn btn-primary" disabled={uploading}>
                      {uploading ? 'Processing & Validating...' : 'Validate & Ingest'}
                    </button>
                  </>
                ) : (
                  <button type="button" className="btn btn-primary" onClick={() => setShowUploadModal(false)}>
                    Done
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
