import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { 
  Database, 
  MapPin, 
  BookOpen, 
  Sliders, 
  FileText, 
  ShieldCheck, 
  Layers, 
  ArrowUpRight,
  AlertTriangle,
  Activity,
  CheckCircle2
} from 'lucide-react';

export default function Overview({ onNavigate }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchOverview() {
      try {
        setLoading(true);
        const res = await api.getNationalOverview();
        setData(res);
      } catch (err) {
        setError(err.message || 'Failed to connect to backend service.');
      } finally {
        setLoading(false);
      }
    }
    fetchOverview();
  }, []);

  if (loading) {
    return (
      <div className="page-container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
        <div style={{ textAlign: 'center', color: '#64748b' }}>
          <Activity size={32} className="animate-spin" style={{ margin: '0 auto 12px auto' }} />
          <p>Aggregating National Cadastral Records & Metrics...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="page-container">
        <div className="alert-banner alert-warning">
          <AlertTriangle size={20} />
          <div>
            <strong>Backend Connection Notice:</strong> {error || 'Could not load metrics.'}
            <div style={{ marginTop: '6px', fontSize: '12px' }}>
              Ensure the backend service is started via <code>node server.js</code> on port 5000.
            </div>
          </div>
        </div>
      </div>
    );
  }

  const { summaryCards, landUseBreakdown, stateBreakdown, recentDatasets, recentActivity, demonstrationNotice } = data;

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">National Digital Land Governance Dashboard</h1>
          <p className="page-subtitle">
            Unified Registry for Cadastral Integration, Statutory Verification & Decision Science (SIH26019)
          </p>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button className="btn btn-primary" onClick={() => onNavigate('webgis')}>
            <MapPin size={15} /> Launch Cadastral WebGIS
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('legal')}>
            <BookOpen size={15} /> Legal Evidence Engine
          </button>
        </div>
      </div>

      {/* Demonstration Notice Banner */}
      {demonstrationNotice && (
        <div className="alert-banner alert-info">
          <ShieldCheck size={20} color="#1d4ed8" style={{ flexShrink: 0 }} />
          <div>
            <strong>DoLR Statutory Notice:</strong> {demonstrationNotice}
          </div>
        </div>
      )}

      {/* Top 4 Primary KPIs */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Indexed Land Parcels</span>
            <div className="kpi-icon-wrapper"><MapPin size={18} /></div>
          </div>
          <div className="kpi-value">{summaryCards?.totalParcels?.toLocaleString() || '1,000+'}</div>
          <div className="kpi-subtext">14-digit standard ULPIN assigned</div>
        </div>

        <div className="kpi-card kpi-accent">
          <div className="kpi-header">
            <span className="kpi-label">Mapped Area</span>
            <div className="kpi-icon-wrapper"><Layers size={18} color="#d97706" /></div>
          </div>
          <div className="kpi-value">{summaryCards?.totalMappedHectares?.toLocaleString() || '15,240'} <span style={{ fontSize: '14px', fontWeight: 500 }}>Ha</span></div>
          <div className="kpi-subtext">~{summaryCards?.totalMappedAcres?.toLocaleString() || '37,650'} Acres Geo-Referenced</div>
        </div>

        <div className="kpi-card kpi-green">
          <div className="kpi-header">
            <span className="kpi-label">Cross-Department Datasets</span>
            <div className="kpi-icon-wrapper"><Database size={18} color="#059669" /></div>
          </div>
          <div className="kpi-value">{summaryCards?.totalDatasets || '12'}</div>
          <div className="kpi-subtext">Revenue, Forest, Soil, Satellite layers</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-header">
            <span className="kpi-label">Statutory Acts Indexed</span>
            <div className="kpi-icon-wrapper"><BookOpen size={18} color="#1a3e6e" /></div>
          </div>
          <div className="kpi-value">{summaryCards?.totalStatutoryActs || '5'}</div>
          <div className="kpi-subtext">LARR 2013, FRA 2006, Wetlands Rules</div>
        </div>
      </div>

      {/* Grid: Land Use Distribution & State Jurisdictions */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '20px', marginBottom: '24px' }}>
        
        {/* Land Use Classification */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Land Use & Land Cover (LULC) Classification</span>
            <span className="badge badge-blue">State Harmonized</span>
          </div>
          <div className="card-body">
            {landUseBreakdown && Object.entries(landUseBreakdown).map(([type, stats]) => {
              const colors = {
                'Agricultural (Irrigated / Rainfed)': '#059669',
                'Forest & Eco-Sensitive': '#047857',
                'Residential & Urban Habitation': '#2563eb',
                'Industrial & Commercial Corridor': '#d97706',
                'Wetland / Waterbody Buffer': '#0284c7'
              };
              const color = colors[type] || '#64748b';
              return (
                <div key={type} style={{ marginBottom: '14px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', marginBottom: '5px' }}>
                    <span style={{ fontWeight: 600, color: '#1e293b' }}>{type}</span>
                    <span style={{ color: '#475569', fontWeight: 500 }}>
                      {stats.hectares?.toLocaleString() || stats.count} Ha ({stats.percentage}%)
                    </span>
                  </div>
                  <div style={{ width: '100%', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                    <div style={{ width: `${stats.percentage}%`, height: '100%', backgroundColor: color, borderRadius: '4px' }}></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* State Jurisdictions */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">State Jurisdictions & Coverage</span>
            <span className="badge badge-green">Pilot States</span>
          </div>
          <div className="card-body">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>State Name</th>
                    <th>Parcels</th>
                    <th>Hectares</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {stateBreakdown && Object.entries(stateBreakdown).map(([state, s]) => (
                    <tr key={state}>
                      <td style={{ fontWeight: 600 }}>{state}</td>
                      <td>{s.parcels?.toLocaleString()}</td>
                      <td>{s.hectares?.toLocaleString()} Ha</td>
                      <td><span className="badge badge-green">Active Synchronized</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Recent Ingested Datasets & Real-time Audit Ledger */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '20px' }}>
        
        {/* Datasets */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Federated Spatial & Tabular Datasets</span>
            <button className="btn btn-sm btn-secondary" onClick={() => onNavigate('records')}>View All</button>
          </div>
          <div className="card-body" style={{ padding: 0 }}>
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Dataset Title</th>
                    <th>Department</th>
                    <th>Format</th>
                    <th>Quality</th>
                  </tr>
                </thead>
                <tbody>
                  {recentDatasets?.map(ds => (
                    <tr key={ds.id}>
                      <td>
                        <div style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{ds.title}</div>
                        <div style={{ fontSize: '11px', color: '#64748b' }}>{ds.theme} • {ds.recordsCount} records</div>
                      </td>
                      <td><span style={{ fontSize: '12px' }}>{ds.sourceDepartment}</span></td>
                      <td><span className="badge badge-blue">{ds.format}</span></td>
                      <td>
                        <span className="badge badge-green" style={{ fontSize: '11px' }}>
                          <CheckCircle2 size={11} /> {ds.completenessScore}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Audit Activity */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">SHA-256 Tamper-Evident Audit Stream</span>
            <button className="btn btn-sm btn-secondary" onClick={() => onNavigate('audit')}>Inspect Chain</button>
          </div>
          <div className="card-body" style={{ padding: '16px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {recentActivity?.map((log, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: '10px', fontSize: '12.5px', padding: '8px 10px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                  <ShieldCheck size={16} color="#059669" style={{ flexShrink: 0, marginTop: '2px' }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontWeight: 600, color: 'var(--gov-navy-900)' }}>{log.action}</span>
                      <span style={{ fontSize: '10.5px', color: '#94a3b8' }}>Block #{log.blockIndex}</span>
                    </div>
                    <div style={{ color: '#475569', fontSize: '11.5px', margin: '2px 0' }}>{log.userEmail} ({log.userRole})</div>
                    <div style={{ fontFamily: 'monospace', fontSize: '10.5px', color: '#64748b', wordBreak: 'break-all' }}>
                      Hash: {log.blockHash?.substring(0, 24)}...
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
