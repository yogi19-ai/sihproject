import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { 
  Server, 
  Database, 
  ShieldCheck, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Terminal, 
  Cpu, 
  Layers,
  KeyRound,
  FileCheck
} from 'lucide-react';

export default function AdminHealth() {
  const { user } = useAuth();
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchHealth();
  }, []);

  async function fetchHealth() {
    try {
      setRefreshing(true);
      const res = await api.getHealth();
      setHealth(res);
    } catch (err) {
      console.error('[AdminHealth] Error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  const RBAC_TIERS = [
    {
      role: 'Viewer (Citizen / Agronomist)',
      access: 'Public Read-Only',
      capabilities: [
        'Cadastral parcel search by ULPIN & Survey No.',
        'View aggregated state & national LULC metrics',
        'Statutory legal search and evidence lookup',
        'Inspect public innovation challenges',
        'Sensitive ownership data masked for privacy'
      ]
    },
    {
      role: 'Researcher (Policy Analyst / Fellow)',
      access: 'Analytical & Sandbox Creation',
      capabilities: [
        'All Viewer capabilities',
        'Download raw spatial datasets (GeoJSON/CSV)',
        'Run Earth Observation spectral models (NDVI/NDWI)',
        'Create & save Policy What-If scenarios',
        'Draft Decision Dossiers & Cabinet briefs',
        'Submit pilot innovation challenge proposals'
      ]
    },
    {
      role: 'Administrator (Land Revenue Authority)',
      access: 'Full Supervisory & Cryptographic Audit',
      capabilities: [
        'All Researcher capabilities',
        'Field verification & statutory status overrides',
        'Cross-agency dataset ingestion & indexing',
        'View unmasked ownership records & survey notes',
        'Full access to SHA-256 tamper-evident ledger',
        'Approve/award open innovation proposals'
      ]
    }
  ];

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Platform Telemetry & Governance Health</h1>
          <p className="page-subtitle">
            Subsystem Status, Three-Tier RBAC Policy Enforcement & Microservice Integration
          </p>
        </div>

        <button 
          className="btn btn-secondary" 
          onClick={fetchHealth}
          disabled={refreshing}
        >
          <RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} />
          {refreshing ? 'Probing...' : 'Refresh Telemetry'}
        </button>
      </div>

      {/* Subsystem Health Grid */}
      <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--gov-navy-950)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '14px' }}>
        Operational Infrastructure Subsystems
      </h3>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px', marginBottom: '28px' }}>
        
        {/* Node Core API */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-body" style={{ padding: '18px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
              <Server size={22} color="#1a3e6e" />
              <span className="badge badge-green">OPERATIONAL</span>
            </div>
            <div style={{ fontWeight: 700, fontSize: '15px', color: 'var(--gov-navy-950)' }}>
              Core Express API Server
            </div>
            <div style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>
              Node.js v24 • RESTful Cadastral Engine
            </div>
            <div style={{ marginTop: '12px', fontSize: '11.5px', color: '#334155', background: '#f8fafc', padding: '8px', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
              Port: <strong>{health?.subsystems?.apiServer?.port || 5000}</strong> • CORS Origin: <strong>*</strong>
            </div>
          </div>
        </div>

        {/* Spatial Store */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-body" style={{ padding: '18px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
              <Database size={22} color="#059669" />
              <span className="badge badge-green">ACTIVE</span>
            </div>
            <div style={{ fontWeight: 700, fontSize: '15px', color: 'var(--gov-navy-950)' }}>
              PostGIS / Spatial Engine
            </div>
            <div style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>
              Indexed High-Performance Vector Store
            </div>
            <div style={{ marginTop: '12px', fontSize: '11.5px', color: '#334155', background: '#f8fafc', padding: '8px', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
              Indexed Parcels: <strong>{health?.subsystems?.databaseAdapter?.totalParcelsIndexed || '1,000+'}</strong>
            </div>
          </div>
        </div>

        {/* Audit Ledger */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-body" style={{ padding: '18px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
              <ShieldCheck size={22} color="#d97706" />
              <span className="badge badge-green">VERIFIED</span>
            </div>
            <div style={{ fontWeight: 700, fontSize: '15px', color: 'var(--gov-navy-950)' }}>
              SHA-256 Audit Ledger
            </div>
            <div style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>
              Tamper-Evident Hash Chain
            </div>
            <div style={{ marginTop: '12px', fontSize: '11.5px', color: '#334155', background: '#f8fafc', padding: '8px', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
              Total Blocks: <strong>{health?.subsystems?.auditLedger?.totalBlocks || '6'}</strong>
            </div>
          </div>
        </div>

        {/* Python AI Microservice */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-body" style={{ padding: '18px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
              <Cpu size={22} color="#7e22ce" />
              <span className="badge badge-purple">CONNECTED</span>
            </div>
            <div style={{ fontWeight: 700, fontSize: '15px', color: 'var(--gov-navy-950)' }}>
              Python Geospatial & AI Service
            </div>
            <div style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>
              CA-Markov, Spectral Indices & OCR
            </div>
            <div style={{ marginTop: '12px', fontSize: '11.5px', color: '#334155', background: '#f8fafc', padding: '8px', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
              Port: <strong>8000</strong> • Threshold: <strong>&gt;0.85</strong>
            </div>
          </div>
        </div>

      </div>

      {/* Three-Tier Role-Based Access Control (RBAC) Architecture Matrix */}
      <div className="card">
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <KeyRound size={18} color="#0a2240" />
            <span className="card-title">Three-Tier Role-Based Access Control (RBAC) Governance Framework</span>
          </div>
          <span className="badge badge-blue">Central Policy Enforced</span>
        </div>
        <div className="card-body">
          <p style={{ fontSize: '13px', color: '#475569', marginBottom: '20px' }}>
            Security policies enforce strict principle-of-least-privilege boundaries between citizen observers, academic policy fellows, and statutory land authorities:
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px' }}>
            {RBAC_TIERS.map((tier, idx) => (
              <div 
                key={idx} 
                style={{ 
                  background: '#f8fafc', 
                  borderRadius: '10px', 
                  padding: '20px', 
                  border: '1px solid #e2e8f0',
                  display: 'flex',
                  flexDirection: 'column'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                  <h4 style={{ fontSize: '14px', fontWeight: 700, color: 'var(--gov-navy-950)' }}>
                    {tier.role}
                  </h4>
                  <span className="badge badge-purple" style={{ fontSize: '10.5px' }}>{tier.access}</span>
                </div>

                <ul style={{ paddingLeft: '18px', fontSize: '12.5px', color: '#334155', lineHeight: 1.6, marginTop: '10px', flex: 1 }}>
                  {tier.capabilities.map((c, i) => (
                    <li key={i} style={{ marginBottom: '6px' }}>{c}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
}
