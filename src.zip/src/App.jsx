import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Overview from './pages/Overview';
import WebGIS from './pages/WebGIS';
import Records from './pages/Records';
import LegalSearch from './pages/LegalSearch';
import GeoAnalytics from './pages/GeoAnalytics';
import Simulator from './pages/Simulator';
import InnovationHub from './pages/InnovationHub';
import Dossiers from './pages/Dossiers';
import AuditLogs from './pages/AuditLogs';
import AdminHealth from './pages/AdminHealth';

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <Overview onNavigate={setActiveTab} />;
      case 'webgis':
        return <WebGIS />;
      case 'records':
        return <Records />;
      case 'legal':
        return <LegalSearch />;
      case 'analytics':
        return <GeoAnalytics />;
      case 'simulator':
        return <Simulator />;
      case 'innovation':
        return <InnovationHub />;
      case 'dossiers':
        return <Dossiers />;
      case 'audit':
        return <AuditLogs />;
      case 'admin':
        return <AdminHealth />;
      default:
        return <Overview onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="app-layout">
      {/* Fixed Sidebar navigation */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <div className="main-wrapper">
        <Header activeTab={activeTab} />
        <main>
          {renderContent()}
        </main>
      </div>
    </div>
  );
}
