import React from 'react';
import { 
  LayoutDashboard, 
  Map, 
  Database, 
  Search, 
  Satellite, 
  Sliders, 
  Lightbulb, 
  FileText, 
  ShieldCheck, 
  Settings,
  Lock,
  Landmark
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Sidebar({ activeTab, setActiveTab }) {
  const { user, hasRole } = useAuth();

  const navItems = [
    { id: 'overview', label: 'National Overview', icon: LayoutDashboard, section: 'Core' },
    { id: 'webgis', label: 'Land WebGIS', icon: Map, section: 'Geospatial' },
    { id: 'records', label: 'Land Records & Data', icon: Database, section: 'Geospatial' },
    { id: 'legal', label: 'Research & Legal Search', icon: Search, section: 'Evidence & Policy' },
    { id: 'analytics', label: 'Geo-Analytics (NDVI/NDWI)', icon: Satellite, section: 'Evidence & Policy' },
    { id: 'simulator', label: 'Policy What-If Simulator', icon: Sliders, section: 'Evidence & Policy' },
    { id: 'innovation', label: 'Open Innovation Hub', icon: Lightbulb, section: 'Collaboration' },
    { id: 'dossiers', label: 'Decision Dossiers', icon: FileText, section: 'Collaboration' },
    { 
      id: 'audit', 
      label: 'SHA-256 Audit Logs', 
      icon: ShieldCheck, 
      section: 'Governance & Security', 
      requiresAdmin: true 
    },
    { 
      id: 'admin', 
      label: 'Administration & Health', 
      icon: Settings, 
      section: 'Governance & Security' 
    }
  ];

  // Group by section
  const sections = ['Core', 'Geospatial', 'Evidence & Policy', 'Collaboration', 'Governance & Security'];

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="sidebar-emblem">
          <Landmark size={20} />
        </div>
        <div className="sidebar-title-group">
          <h1>Bhu-Sushasan</h1>
          <span>National Land Platform • SIH26019</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        {sections.map(sec => {
          const items = navItems.filter(item => item.section === sec);
          return (
            <React.Fragment key={sec}>
              <div className="nav-section-title">{sec}</div>
              {items.map(item => {
                const Icon = item.icon;
                const isLocked = item.requiresAdmin && !hasRole(['Administrator']);

                return (
                  <button
                    key={item.id}
                    className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
                    onClick={() => {
                      if (!isLocked) {
                        setActiveTab(item.id);
                      }
                    }}
                    title={isLocked ? 'Requires Administrator role' : item.label}
                    style={{ opacity: isLocked ? 0.6 : 1, textAlign: 'left', width: '100%', background: 'none' }}
                  >
                    <Icon size={18} />
                    <span>{item.label}</span>
                    {isLocked && <Lock size={13} style={{ marginLeft: 'auto', color: '#94a3b8' }} />}
                  </button>
                );
              })}
            </React.Fragment>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="user-compact-card">
          <div className="user-avatar">
            {user?.fullName?.charAt(0) || 'U'}
          </div>
          <div className="user-info">
            <div className="user-name" title={user?.fullName}>{user?.fullName}</div>
            <span className="user-role-badge">{user?.role}</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
