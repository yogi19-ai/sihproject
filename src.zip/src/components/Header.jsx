import React from 'react';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, UserCheck, RefreshCw, AlertCircle, Database } from 'lucide-react';

export default function Header({ activeTab }) {
  const { user, switchDemoUser, availableDemoUsers, loading } = useAuth();

  const tabLabels = {
    overview: 'National Overview & Governance Metrics',
    webgis: 'Cadastral WebGIS & Spatial Boundary Explorer',
    records: 'Digital Land Records & Cross-Departmental Ingestion',
    legal: 'Statutory Research & RAG Legal Grounding Engine',
    analytics: 'Earth Observation & Spectral Index Analytics (NDVI/NDWI)',
    simulator: 'Policy What-If & Financial Impact Simulator (LARR 2013)',
    innovation: 'Open Innovation Hub & Pilot Policy Challenges',
    dossiers: 'Cabinet & Inter-Ministerial Decision Dossiers',
    audit: 'SHA-256 Tamper-Evident Cryptographic Audit Ledger',
    admin: 'Platform Telemetry, Health & Subsystems'
  };

  return (
    <header className="top-header">
      <div className="header-left">
        <span className="portal-tag">
          <ShieldCheck size={14} color="#1a3e6e" />
          SIH26019 • DoLR Cadastral Standard
        </span>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <h2 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--gov-navy-900)' }}>
            {tabLabels[activeTab] || 'National Land Platform'}
          </h2>
        </div>
      </div>

      <div className="header-right">
        {/* Role Switcher for instant judge review */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: '#f1f5f9', padding: '4px 10px', borderRadius: '8px' }}>
          <UserCheck size={15} color="#0a2240" />
          <span style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>Active Persona:</span>
          <select 
            className="role-switcher-select"
            value={user?.email || ''}
            onChange={(e) => switchDemoUser(e.target.value)}
            disabled={loading}
          >
            {availableDemoUsers.map(u => (
              <option key={u.email} value={u.email}>
                {u.role}: {u.name}
              </option>
            ))}
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#059669', background: '#ecfdf5', padding: '6px 10px', borderRadius: '20px', border: '1px solid #a7f3d0' }}>
          <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#059669', display: 'inline-block' }}></span>
          <span style={{ fontWeight: 600 }}>API Synchronized</span>
        </div>
      </div>
    </header>
  );
}
