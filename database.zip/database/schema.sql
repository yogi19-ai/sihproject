-- ====================================================================
-- SIH26019: National Digital Platform for Land Governance
-- PostgreSQL 16 + PostGIS + pgvector Production Schema
-- ====================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS vector;

-- 1. User & Access Management (3-Tier RBAC)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('Viewer', 'Researcher', 'Administrator')),
    designation VARCHAR(150),
    department VARCHAR(200),
    state_jurisdiction VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE
);

-- 2. Land Parcels (14-digit ULPIN Standards)
CREATE TABLE IF NOT EXISTS parcels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ulpin VARCHAR(14) UNIQUE NOT NULL CHECK (length(ulpin) = 14),
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    sub_district VARCHAR(100) NOT NULL,
    village VARCHAR(100) NOT NULL,
    survey_number VARCHAR(100) NOT NULL,
    area_sqm NUMERIC(14, 2) NOT NULL,
    area_hectares NUMERIC(10, 4) GENERATED ALWAYS AS (area_sqm / 10000.0) STORED,
    area_acres NUMERIC(10, 4) GENERATED ALWAYS AS (area_sqm / 4046.8564) STORED,
    land_use_class VARCHAR(80) NOT NULL,
    ownership_category VARCHAR(80) NOT NULL,
    source_agency VARCHAR(150) NOT NULL,
    verified_status VARCHAR(50) NOT NULL DEFAULT 'Demonstration' CHECK (verified_status IN ('Demonstration', 'Imported', 'Verified')),
    centroid_lat NUMERIC(9, 6) NOT NULL,
    centroid_lng NUMERIC(9, 6) NOT NULL,
    geom GEOMETRY(Geometry, 4326),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_parcels_ulpin ON parcels(ulpin);
CREATE INDEX IF NOT EXISTS idx_parcels_state_district ON parcels(state, district);
CREATE INDEX IF NOT EXISTS idx_parcels_geom ON parcels USING GIST(geom);

-- 3. Ingested Datasets & Metadata
CREATE TABLE IF NOT EXISTS datasets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    source_agency VARCHAR(150) NOT NULL,
    coverage_state VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL,
    format VARCHAR(50) NOT NULL,
    records_count INTEGER NOT NULL DEFAULT 0,
    file_size_mb NUMERIC(8, 2) NOT NULL DEFAULT 0,
    quality_score NUMERIC(5, 2) NOT NULL DEFAULT 95.0,
    verification_status VARCHAR(50) NOT NULL DEFAULT 'Imported',
    license_info VARCHAR(200) NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Statutory Legal Evidence & Knowledge Base
CREATE TABLE IF NOT EXISTS legal_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    act_title VARCHAR(255) NOT NULL,
    short_name VARCHAR(100) NOT NULL,
    year INTEGER NOT NULL,
    issuing_authority VARCHAR(200) NOT NULL,
    document_type VARCHAR(100) NOT NULL,
    official_gazette_ref VARCHAR(200),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS document_chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID REFERENCES legal_documents(id) ON DELETE CASCADE,
    section_number VARCHAR(50) NOT NULL,
    section_title VARCHAR(255) NOT NULL,
    page_number INTEGER NOT NULL,
    content TEXT NOT NULL,
    embedding vector(384),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_chunks_embedding ON document_chunks USING ivfflat (embedding vector_cosine_ops);

-- 5. Policy Simulation Scenarios
CREATE TABLE IF NOT EXISTS policy_scenarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    baseline_year INTEGER NOT NULL,
    target_year INTEGER NOT NULL,
    eco_buffer_meters INTEGER NOT NULL DEFAULT 500,
    compensation_multiplier NUMERIC(4, 2) NOT NULL DEFAULT 2.0,
    solatium_percentage NUMERIC(5, 2) NOT NULL DEFAULT 100.0,
    parameters JSONB NOT NULL DEFAULT '{}'::jsonb,
    simulation_results JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. Open Innovation Hub Proposals & Hackathon Pilots
CREATE TABLE IF NOT EXISTS innovation_proposals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    target_state VARCHAR(100) NOT NULL,
    problem_statement TEXT NOT NULL,
    solution_summary TEXT NOT NULL,
    budget_inr NUMERIC(14, 2) NOT NULL,
    timeline_months INTEGER NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'Submitted' CHECK (status IN ('Draft', 'Submitted', 'Under Review', 'Revision Requested', 'Shortlisted for Pilot', 'Completed')),
    reviewer_score NUMERIC(5, 2),
    reviewer_notes TEXT,
    milestones JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. Decision Dossiers & Policy Briefs
CREATE TABLE IF NOT EXISTS decision_dossiers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    dossier_number VARCHAR(100) UNIQUE NOT NULL,
    geographic_scope VARCHAR(200) NOT NULL,
    problem_statement TEXT NOT NULL,
    key_findings JSONB NOT NULL DEFAULT '[]'::jsonb,
    statutory_citations JSONB NOT NULL DEFAULT '[]'::jsonb,
    policy_recommendations JSONB NOT NULL DEFAULT '[]'::jsonb,
    estimated_impact JSONB NOT NULL DEFAULT '{}'::jsonb,
    hash_sha256 VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Immutable SHA-256 Tamper-Evident Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    actor_id VARCHAR(100) NOT NULL,
    actor_role VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id VARCHAR(100) NOT NULL,
    outcome VARCHAR(50) NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    prev_hash VARCHAR(64) NOT NULL,
    current_hash VARCHAR(64) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_logs(actor_id);
