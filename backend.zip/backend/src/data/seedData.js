const UlpinValidator = require('../services/ulpinValidator');

const SEED_USERS = [
  {
    id: 'usr-admin-001',
    email: 'admin@landgov.gov.in',
    passwordHash: '$2a$10$w8u3L3uLwFm/Q3K9yF3cveJ4C01Gk1k5wH3o9Oq8F9X4rG7qN8b2W', // password: Admin@SIH2026!
    fullName: 'Dr. Rajeshwar Sharma, IAS',
    role: 'Administrator',
    designation: 'Principal Secretary & State Land Commissioner',
    department: 'Department of Revenue & Land Records',
    stateJurisdiction: 'All India / National',
    createdAt: '2026-01-15T09:00:00.000Z'
  },
  {
    id: 'usr-researcher-001',
    email: 'researcher@landgov.gov.in',
    passwordHash: '$2a$10$tZ9/f1t2uL7y0bWvX4kMleY9bM4aD9O2C7L1J9G8E6F5V4A3K2N1O', // password: Research@2026!
    fullName: 'Prof. Ananya Sen',
    role: 'Researcher',
    designation: 'Senior Geospatial Fellow & Policy Analyst',
    department: 'National Institute of Urban Affairs & Land Economics',
    stateJurisdiction: 'Maharashtra & Gujarat Corridors',
    createdAt: '2026-02-10T11:30:00.000Z'
  },
  {
    id: 'usr-viewer-001',
    email: 'citizen@landgov.gov.in',
    passwordHash: '$2a$10$u8L9o0p1q2r3s4t5u6v7w8x9y0z1a2b3c4d5e6f7g8h9i0j1k2l3m', // password: Citizen@2026!
    fullName: 'Kavita Deshmukh',
    role: 'Viewer',
    designation: 'Independent Agronomist & Citizen Researcher',
    department: 'Public Land Research Forum',
    stateJurisdiction: 'Public Portal',
    createdAt: '2026-03-01T14:15:00.000Z'
  }
];

const SEED_PARCELS = [
  // Maharashtra - Pune District
  {
    id: 'pcl-mh-001',
    ulpin: 'MH26000190012A',
    state: 'Maharashtra',
    district: 'Pune',
    subDistrict: 'Haveli',
    village: 'Wagholi',
    surveyNumber: '142/2A',
    areaSqm: 24500.0,
    landUseClass: 'Agricultural',
    ownershipCategory: 'Private Ryotwari',
    sourceAgency: 'Maharashtra Bhulekh (Mahabhumi)',
    verifiedStatus: 'Demonstration',
    centroidLat: 18.5804,
    centroidLng: 73.9805,
    polygon: [
      [73.9790, 18.5795],
      [73.9820, 18.5795],
      [73.9825, 18.5815],
      [73.9795, 18.5818],
      [73.9790, 18.5795]
    ],
    ndviCurrent: 0.62,
    ndwiCurrent: -0.15,
    lastSurveyDate: '2025-11-20'
  },
  {
    id: 'pcl-mh-002',
    ulpin: 'MH26000290023B',
    state: 'Maharashtra',
    district: 'Pune',
    subDistrict: 'Haveli',
    village: 'Wagholi',
    surveyNumber: '142/2B',
    areaSqm: 18200.0,
    landUseClass: 'Commercial / Logistics',
    ownershipCategory: 'Institutional Leasehold',
    sourceAgency: 'Maharashtra Bhulekh (Mahabhumi)',
    verifiedStatus: 'Demonstration',
    centroidLat: 18.5830,
    centroidLng: 73.9835,
    polygon: [
      [73.9822, 18.5820],
      [73.9845, 18.5822],
      [73.9848, 18.5842],
      [73.9826, 18.5840],
      [73.9822, 18.5820]
    ],
    ndviCurrent: 0.18,
    ndwiCurrent: -0.32,
    lastSurveyDate: '2025-08-14'
  },
  {
    id: 'pcl-mh-003',
    ulpin: 'MH26000390034C',
    state: 'Maharashtra',
    district: 'Pune',
    subDistrict: 'Mulshi',
    village: 'Hinjawadi',
    surveyNumber: '88/1',
    areaSqm: 42000.0,
    landUseClass: 'IT / High-Tech SEZ',
    ownershipCategory: 'MIDC Industrial Leasehold',
    sourceAgency: 'MIDC GIS & Mahabhumi',
    verifiedStatus: 'Demonstration',
    centroidLat: 18.5912,
    centroidLng: 73.7388,
    polygon: [
      [73.7370, 18.5900],
      [73.7405, 18.5902],
      [73.7410, 18.5925],
      [73.7375, 18.5928],
      [73.7370, 18.5900]
    ],
    ndviCurrent: 0.25,
    ndwiCurrent: -0.28,
    lastSurveyDate: '2026-01-10'
  },
  {
    id: 'pcl-mh-004',
    ulpin: 'MH26000490045D',
    state: 'Maharashtra',
    district: 'Nagpur',
    subDistrict: 'Hingna',
    village: 'Mandwa',
    surveyNumber: '210/4',
    areaSqm: 68000.0,
    landUseClass: 'Reserved Forest Buffer',
    ownershipCategory: 'State Forest Department',
    sourceAgency: 'ISRO Bhuvan Forest Cadastre',
    verifiedStatus: 'Demonstration',
    centroidLat: 21.0650,
    centroidLng: 78.9610,
    polygon: [
      [78.9590, 21.0630],
      [78.9635, 21.0632],
      [78.9640, 21.0672],
      [78.9592, 21.0668],
      [78.9590, 21.0630]
    ],
    ndviCurrent: 0.78,
    ndwiCurrent: 0.12,
    lastSurveyDate: '2025-10-05'
  },
  // Uttar Pradesh - Gautam Buddha Nagar (Noida / Greater Noida)
  {
    id: 'pcl-up-001',
    ulpin: 'UP26000590056E',
    state: 'Uttar Pradesh',
    district: 'Gautam Buddha Nagar',
    subDistrict: 'Jewar',
    village: 'Rohi',
    surveyNumber: '315/1',
    areaSqm: 52000.0,
    landUseClass: 'Infrastructure / Aviation Corridor',
    ownershipCategory: 'Acquired under LARR Act 2013',
    sourceAgency: 'UP Bhulekh & Yamuna Expressway Authority',
    verifiedStatus: 'Demonstration',
    centroidLat: 28.1820,
    centroidLng: 77.6320,
    polygon: [
      [77.6295, 28.1800],
      [77.6345, 28.1802],
      [77.6350, 28.1840],
      [77.6300, 28.1838],
      [77.6295, 28.1800]
    ],
    ndviCurrent: 0.22,
    ndwiCurrent: -0.25,
    lastSurveyDate: '2025-12-02'
  },
  {
    id: 'pcl-up-002',
    ulpin: 'UP26000690067F',
    state: 'Uttar Pradesh',
    district: 'Varanasi',
    subDistrict: 'Pindra',
    village: 'Karaundi',
    surveyNumber: '54/3',
    areaSqm: 15400.0,
    landUseClass: 'Agricultural (Triple Cropping)',
    ownershipCategory: 'Private Zamindari Abolition Allotment',
    sourceAgency: 'UP Bhulekh Land Records',
    verifiedStatus: 'Demonstration',
    centroidLat: 25.3450,
    centroidLng: 82.9750,
    polygon: [
      [77.6295, 25.3435],
      [82.9765, 25.3435],
      [82.9770, 25.3465],
      [82.9740, 25.3465],
      [77.6295, 25.3435]
    ],
    ndviCurrent: 0.71,
    ndwiCurrent: 0.05,
    lastSurveyDate: '2026-02-18'
  },
  // Karnataka - Bengaluru Urban
  {
    id: 'pcl-ka-001',
    ulpin: 'KA26000790078G',
    state: 'Karnataka',
    district: 'Bengaluru Urban',
    subDistrict: 'Anekal',
    village: 'Attibele',
    surveyNumber: '92/1',
    areaSqm: 31000.0,
    landUseClass: 'Mixed Residential / Commercial',
    ownershipCategory: 'Private Freehold',
    sourceAgency: 'Karnataka Bhoomi Portal',
    verifiedStatus: 'Demonstration',
    centroidLat: 12.7780,
    centroidLng: 77.7650,
    polygon: [
      [77.7630, 12.7765],
      [77.7670, 12.7768],
      [77.7672, 12.7798],
      [77.7632, 12.7795],
      [77.7630, 12.7765]
    ],
    ndviCurrent: 0.31,
    ndwiCurrent: -0.20,
    lastSurveyDate: '2026-01-22'
  },
  {
    id: 'pcl-ka-002',
    ulpin: 'KA26000890089H',
    state: 'Karnataka',
    district: 'Bengaluru Urban',
    subDistrict: 'Bengaluru East',
    village: 'Bellandur Eco-Zone',
    surveyNumber: '112/A',
    areaSqm: 28000.0,
    landUseClass: 'Wetland Buffer / Waterbody',
    ownershipCategory: 'State Minor Irrigation & Lake Authority',
    sourceAgency: 'Bhoomi & Karnataka Lake Development Authority',
    verifiedStatus: 'Demonstration',
    centroidLat: 12.9340,
    centroidLng: 77.6710,
    polygon: [
      [77.6690, 12.9325],
      [77.6730, 12.9328],
      [77.6732, 12.9355],
      [77.6692, 12.9352],
      [77.6690, 12.9325]
    ],
    ndviCurrent: 0.55,
    ndwiCurrent: 0.65,
    lastSurveyDate: '2026-02-01'
  },
  // Gujarat - Ahmedabad
  {
    id: 'pcl-gj-001',
    ulpin: 'GJ26000990090J',
    state: 'Gujarat',
    district: 'Ahmedabad',
    subDistrict: 'Sanand',
    village: 'Bol',
    surveyNumber: '401/2',
    areaSqm: 85000.0,
    landUseClass: 'Automotive & Manufacturing Zone',
    ownershipCategory: 'GIDC Industrial Estate',
    sourceAgency: 'AnyRoR Gujarat & GIDC Portal',
    verifiedStatus: 'Demonstration',
    centroidLat: 22.9850,
    centroidLng: 72.3650,
    polygon: [
      [72.3610, 22.9820],
      [72.3685, 22.9825],
      [72.3690, 22.9875],
      [72.3615, 22.9870],
      [72.3610, 22.9820]
    ],
    ndviCurrent: 0.14,
    ndwiCurrent: -0.35,
    lastSurveyDate: '2025-09-30'
  },
  // Odisha - Khordha / Bhubaneswar
  {
    id: 'pcl-od-001',
    ulpin: 'OD26001090101K',
    state: 'Odisha',
    district: 'Khordha',
    subDistrict: 'Bhubaneswar',
    village: 'Chandaka Buffer',
    surveyNumber: '67/B',
    areaSqm: 49000.0,
    landUseClass: 'Eco-Sensitive Sanctuary Fringe',
    ownershipCategory: 'Community Forest Rights (FRA 2006)',
    sourceAgency: 'Bhulekh Odisha & Forest Dept',
    verifiedStatus: 'Demonstration',
    centroidLat: 20.3550,
    centroidLng: 85.7650,
    polygon: [
      [85.7620, 20.3530],
      [85.7680, 20.3532],
      [85.7685, 20.3570],
      [85.7625, 20.3568],
      [85.7620, 20.3530]
    ],
    ndviCurrent: 0.82,
    ndwiCurrent: 0.21,
    lastSurveyDate: '2026-01-05'
  }
];

const SEED_DATASETS = [
  {
    id: 'ds-001',
    title: 'Maharashtra Bhulekh Cadastral Shapefiles & Village RoR 2025-26',
    sourceAgency: 'Settlement Commissioner & Director of Land Records, Pune',
    coverageState: 'Maharashtra',
    category: 'Cadastral & RoR',
    format: 'GeoJSON / SHP',
    recordsCount: 428500,
    fileSizeMb: 142.5,
    qualityScore: 98.4,
    verificationStatus: 'Verified',
    licenseInfo: 'Government Open Data Licence - India (GODL)',
    metadata: {
      datum: 'WGS84 / EPSG:4326',
      cadastralScale: '1:4000',
      lastSync: '2026-02-15'
    }
  },
  {
    id: 'ds-002',
    title: 'ISRO Bhuvan High-Resolution Land-Use / Land-Cover (LULC) 2025 Cycle',
    sourceAgency: 'National Remote Sensing Centre (NRSC / ISRO)',
    coverageState: 'All India',
    category: 'Geospatial Satellite Raster',
    format: 'GeoTIFF / WMS',
    recordsCount: 1250000,
    fileSizeMb: 850.0,
    qualityScore: 99.1,
    verificationStatus: 'Verified',
    licenseInfo: 'ISRO Open Geospatial Data Sharing Policy',
    metadata: {
      sensor: 'Resourcesat-2A LISS-IV',
      resolutionMeters: 5.8,
      bands: ['Green', 'Red', 'NIR', 'SWIR']
    }
  },
  {
    id: 'ds-003',
    title: 'Uttar Pradesh Bhulekh Revenue Plot Boundaries & Khatauni Ledger',
    sourceAgency: 'Board of Revenue, Uttar Pradesh',
    coverageState: 'Uttar Pradesh',
    category: 'Cadastral & Revenue',
    format: 'CSV / WFS',
    recordsCount: 785000,
    fileSizeMb: 215.3,
    qualityScore: 94.8,
    verificationStatus: 'Imported',
    licenseInfo: 'State Portal Interoperability API',
    metadata: {
      digitizationStatus: 'SVAMITVA Drone Validated 88%',
      lastSync: '2026-01-28'
    }
  },
  {
    id: 'ds-004',
    title: 'PM GatiShakti National Master Plan Infrastructure Right-of-Way (RoW)',
    sourceAgency: 'Logistics Division, DPIIT, Ministry of Commerce & Industry',
    coverageState: 'National Multi-Modal Corridors',
    category: 'Infrastructure & Corridor Planning',
    format: 'GeoJSON / OGC WFS',
    recordsCount: 89000,
    fileSizeMb: 68.2,
    qualityScore: 97.6,
    verificationStatus: 'Verified',
    licenseInfo: 'Restricted Inter-Ministerial Spatial Standard',
    metadata: {
      layers: ['Expressways', 'Dedicated Freight Corridors', 'Gas Pipelines', 'Renewable Energy Parks']
    }
  },
  {
    id: 'ds-005',
    title: 'Survey of India CORS Network Cadastral Reference Coordinates',
    sourceAgency: 'Survey of India, Dehradun',
    coverageState: 'All India',
    category: 'Geodetic Reference',
    format: 'CSV / GeoJSON',
    recordsCount: 1540,
    fileSizeMb: 12.8,
    qualityScore: 99.9,
    verificationStatus: 'Verified',
    licenseInfo: 'National Geospatial Policy 2022 Open Tier',
    metadata: {
      datum: 'ITRF2014 / WGS84',
      accuracyCm: 2.5
    }
  }
];

const SEED_STATUTORY_ACTS = [
  {
    id: 'act-001',
    actTitle: 'Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013 (LARR Act)',
    shortName: 'LARR Act 2013',
    year: 2013,
    issuingAuthority: 'Ministry of Rural Development, Government of India',
    documentType: 'Central Act (Act No. 30 of 2013)',
    chunks: [
      {
        id: 'chk-001-1',
        sectionNumber: 'Section 16',
        sectionTitle: 'Preparation of Rehabilitation and Resettlement Scheme by Administrator',
        pageNumber: 14,
        content: 'Upon the publication of preliminary notification under sub-section (1) of section 11, the Administrator for Rehabilitation and Resettlement shall conduct a survey and undertake a census of the affected families, in such manner and within such time as may be prescribed.',
        tags: ['resettlement', 'census', 'affected families', 'preliminary notification']
      },
      {
        id: 'chk-001-2',
        sectionNumber: 'Section 26',
        sectionTitle: 'Determination of Market Value of Land by Collector',
        pageNumber: 22,
        content: 'The Collector shall adopt the following criteria in assessing and determining the market value of the land: (a) the market value, if any, specified in the Indian Stamp Act, 1899 for the registration of sale deeds or agreements to sell; (b) the average sale price for similar type of land situated in the nearest village or vicinity; or (c) consented amount of compensation agreed upon in case of acquisition for private companies or public private partnerships.',
        tags: ['market value', 'collector', 'circle rate', 'average sale price']
      },
      {
        id: 'chk-001-3',
        sectionNumber: 'Section 30',
        sectionTitle: 'Award of Solatium',
        pageNumber: 26,
        content: 'The Collector having determined the total compensation to be paid, shall, to arrive at the final award, impose a "Solatium" amount equivalent to one hundred per cent. of the compensation amount. Explanation.—For the removal of doubts, it is hereby declared that solatium amount shall be in addition to the compensation payable to any person whose land has been acquired.',
        tags: ['solatium', 'compensation', '100 percent', 'mandatory award']
      },
      {
        id: 'chk-001-4',
        sectionNumber: 'Schedule I',
        sectionTitle: 'Multiplier Factor for Rural Areas',
        pageNumber: 48,
        content: 'In case of rural areas, the market value determined under section 26 shall be multiplied by a factor between 1.00 (one) to 2.00 (two) based on the distance of project from urban area as may be notified by the appropriate Government.',
        tags: ['rural multiplier', 'market value factor', 'distance from urban centre']
      }
    ]
  },
  {
    id: 'act-002',
    actTitle: 'Scheduled Tribes and Other Traditional Forest Dwellers (Recognition of Forest Rights) Act, 2006',
    shortName: 'Forest Rights Act (FRA) 2006',
    year: 2006,
    issuingAuthority: 'Ministry of Tribal Affairs, Government of India',
    documentType: 'Central Act (Act No. 2 of 2007)',
    chunks: [
      {
        id: 'chk-002-1',
        sectionNumber: 'Section 3(1)(a)',
        sectionTitle: 'Individual Forest Rights for Habitation and Self-Cultivation',
        pageNumber: 6,
        content: 'Right to hold and live in the forest land under the individual or common occupation for habitation or for self-cultivation for livelihood by a member or members of a forest dwelling Scheduled Tribe or other traditional forest dwellers up to an area not exceeding four hectares.',
        tags: ['individual forest rights', 'self-cultivation', 'four hectares limit', 'habitation']
      },
      {
        id: 'chk-002-2',
        sectionNumber: 'Section 4(5)',
        sectionTitle: 'Protection against Eviction Prior to Recognition Process',
        pageNumber: 9,
        content: 'Save as otherwise provided, no member of a forest dwelling Scheduled Tribe or other traditional forest dweller shall be evicted or removed from forest land under his occupation till the recognition and verification procedure is complete.',
        tags: ['eviction ban', 'due process', 'gram sabha verification', 'forest dweller rights']
      }
    ]
  },
  {
    id: 'act-003',
    actTitle: 'Wetlands (Conservation and Management) Rules, 2017',
    shortName: 'Wetlands Rules 2017',
    year: 2017,
    issuingAuthority: 'Ministry of Environment, Forest and Climate Change (MoEFCC)',
    documentType: 'Statutory Rules (G.S.R. 1203(E))',
    chunks: [
      {
        id: 'chk-003-1',
        sectionNumber: 'Rule 4',
        sectionTitle: 'Restrictions of Activities in Wetlands and Zone of Influence',
        pageNumber: 4,
        content: 'The wetlands shall be conserved and managed in accordance with the principle of "wise use". The following activities shall not be undertaken: (i) conversion for non-wetland uses including encroachment of any kind; (ii) setting up of any industry and expansion of existing industries; (iii) manufacture or handling or storage or disposal of construction and demolition waste; (iv) discharge of untreated wastes and effluents from industries, cities, towns, villages and other human settlements.',
        tags: ['wetlands', 'encroachment ban', 'non-wetland conversion', 'effluent discharge']
      }
    ]
  },
  {
    id: 'act-004',
    actTitle: 'Technical Specifications for Unique Land Parcel Identification Number (ULPIN / Bhu-Aadhaar) 2021',
    shortName: 'ULPIN Standards 2021',
    year: 2021,
    issuingAuthority: 'Department of Land Resources, Ministry of Rural Development',
    documentType: 'Official Technical Guideline',
    chunks: [
      {
        id: 'chk-004-1',
        sectionNumber: 'Section 3.2',
        sectionTitle: '14-Digit Alphanumeric Encoding Architecture',
        pageNumber: 8,
        content: 'The 14-character alphanumeric ULPIN is derived from the georeferenced cadastral map coordinates of the parcel vertices. The code comprises state/grid latitude-longitude coordinates encoded using an internationally standardized geographic encoding matrix, terminated with an alphanumeric check character for checksum verification.',
        tags: ['ulpin architecture', 'bhu-aadhaar', 'georeferenced vertices', 'check character']
      },
      {
        id: 'chk-004-2',
        sectionNumber: 'Section 4.1',
        sectionTitle: 'Legal Nature and Limitations of ULPIN',
        pageNumber: 12,
        content: 'The ULPIN serves as a unique geospatial reference identifier for a land parcel. It establishes standardized cross-agency data interoperability between Revenue, Survey, Registration, and Urban Planning departments. The allotment of a ULPIN does not confer, alter, or certify judicial title or clear ownership, which continues to be governed by the Record of Rights (RoR) and substantive land laws.',
        tags: ['interoperability', 'no title guarantee', 'record of rights', 'cross-agency link']
      }
    ]
  }
];

const SEED_POLICY_SCENARIOS = [
  {
    id: 'scn-001',
    userId: 'usr-researcher-001',
    title: 'Pune Metropolitan Ring Road Phase 2: Eco-Buffer & Solatium Impact',
    description: 'Assessment of agricultural land conversion along a 500-meter buffer zone with LARR 2013 2.0x rural multiplier and 100% statutory solatium.',
    state: 'Maharashtra',
    district: 'Pune',
    baselineYear: 2026,
    targetYear: 2031,
    ecoBufferMeters: 500,
    compensationMultiplier: 2.0,
    solatiumPercentage: 100.0,
    parameters: {
      affectedParcelsCount: 342,
      totalAreaHectares: 845.2,
      agriculturalConversionRate: 0.65,
      waterbodyBufferProtection: true,
      estimatedCircleRatePerHectareINR: 4500000
    },
    simulationResults: {
      projectedUrbanGrowthPct: 38.4,
      agriculturalReductionPct: 24.1,
      totalEstimatedCompensationINR: 15213600000, // 845.2 ha * 4.5M * 2.0 multiplier * 2.0 (with solatium)
      environmentalImpactScore: 68.5,
      uncertaintyRangePct: 12.0,
      caMarkovTransitionSummary: {
        agricultureToBuiltupHa: 549.4,
        fallowToBuiltupHa: 182.2,
        protectedWaterbodyPreservedHa: 113.6
      }
    },
    createdAt: '2026-02-18T10:00:00.000Z'
  },
  {
    id: 'scn-002',
    userId: 'usr-admin-001',
    title: 'Jewar Aerotropolis Green Belt Conservation & Agro-Compensation Model',
    description: 'What-if policy model evaluating statutory compliance with Wetlands Rules 2017 and compensatory afforestation requirements for Noida-Jewar peripheral zone.',
    state: 'Uttar Pradesh',
    district: 'Gautam Buddha Nagar',
    baselineYear: 2026,
    targetYear: 2036,
    ecoBufferMeters: 1000,
    compensationMultiplier: 1.5,
    solatiumPercentage: 100.0,
    parameters: {
      affectedParcelsCount: 512,
      totalAreaHectares: 1240.0,
      agriculturalConversionRate: 0.45,
      waterbodyBufferProtection: true,
      estimatedCircleRatePerHectareINR: 6200000
    },
    simulationResults: {
      projectedUrbanGrowthPct: 44.2,
      agriculturalReductionPct: 18.7,
      totalEstimatedCompensationINR: 23064000000,
      environmentalImpactScore: 74.0,
      uncertaintyRangePct: 15.0,
      caMarkovTransitionSummary: {
        agricultureToBuiltupHa: 558.0,
        fallowToBuiltupHa: 310.0,
        protectedWaterbodyPreservedHa: 372.0
      }
    },
    createdAt: '2026-03-05T15:30:00.000Z'
  }
];

const SEED_INNOVATION_PROPOSALS = [
  {
    id: 'prop-001',
    userId: 'usr-researcher-001',
    title: 'Drone-Assisted 3D Cadastral Boundary Extraction in Undulating Tribal Terrains',
    category: 'Cadastral GIS & Drone Survey',
    targetState: 'Odisha',
    problemStatement: 'Conventional total station surveys face severe line-of-sight occlusions in hilly tribal tracts, causing delays in Forest Rights Act (FRA 2006) title demarcation.',
    solutionSummary: 'Deploying RTK-enabled sub-centimeter UAV photogrammetry coupled with AI edge edge-detection to delineate customary boundaries with Gram Sabha community verification.',
    budgetInr: 4500000,
    timelineMonths: 12,
    status: 'Shortlisted for Pilot',
    reviewerScore: 92.5,
    reviewerNotes: 'Excellent alignment with SVAMITVA expansion and FRA 2006 due process requirements. Pilot sanctioned for Sundargarh district.',
    milestones: [
      { name: 'Drone Flight Plan & Gram Sabha Consent', status: 'Completed', deadline: 'Month 2' },
      { name: 'Orthomosaic Generation & 3D Point Cloud Delineation', status: 'In Progress', deadline: 'Month 6' },
      { name: 'Ground Truthing & RoR Integration Pilot', status: 'Pending', deadline: 'Month 12' }
    ],
    createdAt: '2026-01-20T16:00:00.000Z'
  },
  {
    id: 'prop-002',
    userId: 'usr-viewer-001',
    title: 'Automated Multilingual Land Mutation Anomaly Detector using Indic-BERT',
    category: 'AI & Natural Language Processing',
    targetState: 'Maharashtra',
    problemStatement: 'Manual parsing of legacy Marathi and Devanagari 7/12 extract remarks leads to backlogs in detecting non-agricultural permission violations.',
    solutionSummary: 'Fine-tuned Indic-BERT language model with legal entity recognition (NER) to extract survey numbers, easement encumbrances, and litigation notices from scanned RoR records.',
    budgetInr: 2800000,
    timelineMonths: 9,
    status: 'Under Review',
    reviewerScore: 84.0,
    reviewerNotes: 'Strong technical concept. Awaiting benchmark evaluation on noisy OCR scans from taluk land records.',
    milestones: [
      { name: 'Corpus Annotation of 10,000 Marathi RoR Extracts', status: 'In Progress', deadline: 'Month 3' },
      { name: 'Model Fine-Tuning & Evaluation', status: 'Pending', deadline: 'Month 6' }
    ],
    createdAt: '2026-02-14T10:15:00.000Z'
  }
];

const SEED_DOSSIERS = [
  {
    id: 'dos-001',
    userId: 'usr-researcher-001',
    dossierNumber: 'DOS-2026-MH-PUNE-01',
    title: 'Strategic Land Governance Brief: Pune Metro Ring Road Corridor Phase 2',
    geographicScope: 'Pune District (Haveli, Mulshi, Shirur Taluks)',
    problemStatement: 'Rapid peripheral urbanization along the proposed ring road requires evidence-based land acquisition balancing agricultural preservation, waterbody buffer protection under Wetlands Rules 2017, and fair compensation under LARR 2013.',
    keyFindings: [
      '342 parcels analyzed covering 845.2 hectares across 6 revenue villages.',
      'Average NDVI vegetation health decreased by 14% over 2021-2026 in unzoned highway fringes.',
      '68 hectares of ecologically sensitive natural drainage channels identified requiring mandatory buffer protection.'
    ],
    statutoryCitations: [
      'LARR Act 2013, Section 26: Determination of Market Value using average registered sale prices.',
      'LARR Act 2013, Section 30: Mandatory imposition of 100% Solatium.',
      'LARR Act 2013, Schedule I: Multiplier Factor of 2.0 for rural parcels.',
      'Wetlands Rules 2017, Rule 4: Ban on conversion or industrial effluent discharge into declared waterbodies.'
    ],
    policyRecommendations: [
      'Establish a 500m mandatory green buffer along watercourses to prevent flooding and retain groundwater recharge.',
      'Adopt a transparent land pooling model with 40% reconstituted developed land return as an alternative to direct cash acquisition.',
      'Deploy 14-digit ULPIN Bhu-Aadhaar tags across all affected survey subdivisions prior to section 11 preliminary notification.'
    ],
    estimatedImpact: {
      budgetRequiredINR: '15,213.6 Million',
      affectedFamiliesEstimated: 1280,
      carbonOffsetPreservedTonsPerYear: 4200
    },
    hashSha256: 'a1b2c3d4e5f60718293a4b5c6d7e8f90123456789abcdef0123456789abcdef0',
    createdAt: '2026-02-25T14:30:00.000Z'
  }
];

module.exports = {
  SEED_USERS,
  SEED_PARCELS,
  SEED_DATASETS,
  SEED_STATUTORY_ACTS,
  SEED_POLICY_SCENARIOS,
  SEED_INNOVATION_PROPOSALS,
  SEED_DOSSIERS
};
