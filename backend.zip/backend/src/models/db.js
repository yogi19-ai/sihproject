const fs = require('fs');
const path = require('path');
const { 
  SEED_USERS, 
  SEED_PARCELS, 
  SEED_DATASETS, 
  SEED_STATUTORY_ACTS, 
  SEED_POLICY_SCENARIOS, 
  SEED_INNOVATION_PROPOSALS, 
  SEED_DOSSIERS 
} = require('../data/seedData');
const UlpinValidator = require('../services/ulpinValidator');

const DB_FILE = path.join(__dirname, '..', 'data', 'db_store.json');

class DatabaseAdapter {
  constructor() {
    this.users = [];
    this.parcels = [];
    this.datasets = [];
    this.acts = [];
    this.scenarios = [];
    this.proposals = [];
    this.dossiers = [];
    this.initDatabase();
  }

  initDatabase() {
    try {
      const dataDir = path.dirname(DB_FILE);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const data = JSON.parse(raw);
        this.users = data.users || [];
        this.parcels = data.parcels || [];
        this.datasets = data.datasets || [];
        this.acts = data.acts || [];
        this.scenarios = data.scenarios || [];
        this.proposals = data.proposals || [];
        this.dossiers = data.dossiers || [];
      } else {
        this.seedInitialData();
      }
    } catch (err) {
      console.error('[DatabaseAdapter] Init error, falling back to seed:', err.message);
      this.seedInitialData();
    }
  }

  seedInitialData() {
    this.users = [...SEED_USERS];
    this.parcels = [...SEED_PARCELS];
    this.datasets = [...SEED_DATASETS];
    this.acts = [...SEED_STATUTORY_ACTS];
    this.scenarios = [...SEED_POLICY_SCENARIOS];
    this.proposals = [...SEED_INNOVATION_PROPOSALS];
    this.dossiers = [...SEED_DOSSIERS];
    this.persist();
  }

  persist() {
    try {
      const payload = {
        users: this.users,
        parcels: this.parcels,
        datasets: this.datasets,
        acts: this.acts,
        scenarios: this.scenarios,
        proposals: this.proposals,
        dossiers: this.dossiers,
        updatedAt: new Date().toISOString()
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(payload, null, 2), 'utf-8');
    } catch (err) {
      console.error('[DatabaseAdapter] Persist error:', err.message);
    }
  }

  // --- Users & Auth ---
  findUserByEmail(email) {
    if (!email) return null;
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
  }

  findUserById(id) {
    return this.users.find(u => u.id === id) || null;
  }

  createUser(userData) {
    this.users.push(userData);
    this.persist();
    return userData;
  }

  // --- Parcels & WebGIS Spatial Queries ---
  /**
   * Spatial Bounding Box (BBOX) Query
   * Queries parcels whose centroid or bounding box falls within the specified viewport
   */
  getParcelsByBbox({ minLat, maxLat, minLng, maxLng, state, district, landUseClass, verifiedStatus, limit = 500, offset = 0 }) {
    let results = this.parcels;

    if (minLat !== undefined && maxLat !== undefined && minLng !== undefined && maxLng !== undefined) {
      const nMinLat = parseFloat(minLat);
      const nMaxLat = parseFloat(maxLat);
      const nMinLng = parseFloat(minLng);
      const nMaxLng = parseFloat(maxLng);

      results = results.filter(p => {
        return (
          p.centroidLat >= nMinLat &&
          p.centroidLat <= nMaxLat &&
          p.centroidLng >= nMinLng &&
          p.centroidLng <= nMaxLng
        );
      });
    }

    if (state) {
      results = results.filter(p => p.state.toLowerCase() === state.toLowerCase());
    }
    if (district) {
      results = results.filter(p => p.district.toLowerCase() === district.toLowerCase());
    }
    if (landUseClass) {
      results = results.filter(p => p.landUseClass.toLowerCase() === landUseClass.toLowerCase());
    }
    if (verifiedStatus) {
      results = results.filter(p => p.verifiedStatus.toLowerCase() === verifiedStatus.toLowerCase());
    }

    const total = results.length;
    const paginated = results.slice(offset, offset + limit);

    return {
      total,
      limit,
      offset,
      parcels: paginated
    };
  }

  findParcelByUlpin(ulpin) {
    if (!ulpin) return null;
    const clean = ulpin.trim().toUpperCase();
    return this.parcels.find(p => p.ulpin === clean) || null;
  }

  findParcelById(id) {
    return this.parcels.find(p => p.id === id) || null;
  }

  addParcel(parcel) {
    this.parcels.push(parcel);
    this.persist();
    return parcel;
  }

  addParcelsBatch(parcelArray) {
    this.parcels.push(...parcelArray);
    this.persist();
    return parcelArray.length;
  }

  updateParcelVerification(ulpin, status, actorId) {
    const parcel = this.findParcelByUlpin(ulpin);
    if (!parcel) return null;
    parcel.verifiedStatus = status;
    parcel.lastVerifiedBy = actorId;
    parcel.lastVerifiedAt = new Date().toISOString();
    this.persist();
    return parcel;
  }

  // --- Datasets Catalogue ---
  getDatasets({ category, state, search } = {}) {
    let list = [...this.datasets];
    if (category) {
      list = list.filter(d => d.category.toLowerCase().includes(category.toLowerCase()));
    }
    if (state) {
      list = list.filter(d => d.coverageState.toLowerCase().includes(state.toLowerCase()));
    }
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(d => 
        d.title.toLowerCase().includes(q) || 
        d.sourceAgency.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q)
      );
    }
    return list;
  }

  findDatasetById(id) {
    return this.datasets.find(d => d.id === id) || null;
  }

  addDataset(dataset) {
    this.datasets.unshift(dataset);
    this.persist();
    return dataset;
  }

  // --- Statutory Acts & Knowledge Chunks ---
  getAllActs() {
    return this.acts;
  }

  findActById(id) {
    return this.acts.find(a => a.id === id) || null;
  }

  getAllDocumentChunks() {
    const chunks = [];
    this.acts.forEach(act => {
      act.chunks.forEach(chunk => {
        chunks.push({
          ...chunk,
          actId: act.id,
          actTitle: act.actTitle,
          shortName: act.shortName,
          year: act.year,
          issuingAuthority: act.issuingAuthority
        });
      });
    });
    return chunks;
  }

  // --- Policy Scenarios ---
  getScenarios({ state, district } = {}) {
    let list = [...this.scenarios];
    if (state) list = list.filter(s => s.state.toLowerCase() === state.toLowerCase());
    if (district) list = list.filter(s => s.district.toLowerCase() === district.toLowerCase());
    return list.reverse();
  }

  findScenarioById(id) {
    return this.scenarios.find(s => s.id === id) || null;
  }

  addScenario(scenario) {
    this.scenarios.unshift(scenario);
    this.persist();
    return scenario;
  }

  // --- Innovation Hub Proposals ---
  getProposals({ status, category } = {}) {
    let list = [...this.proposals];
    if (status) list = list.filter(p => p.status.toLowerCase() === status.toLowerCase());
    if (category) list = list.filter(p => p.category.toLowerCase() === category.toLowerCase());
    return list.reverse();
  }

  findProposalById(id) {
    return this.proposals.find(p => p.id === id) || null;
  }

  addProposal(proposal) {
    this.proposals.unshift(proposal);
    this.persist();
    return proposal;
  }

  updateProposalReview(id, { status, reviewerScore, reviewerNotes }) {
    const prop = this.findProposalById(id);
    if (!prop) return null;
    if (status) prop.status = status;
    if (reviewerScore !== undefined) prop.reviewerScore = reviewerScore;
    if (reviewerNotes !== undefined) prop.reviewerNotes = reviewerNotes;
    prop.updatedAt = new Date().toISOString();
    this.persist();
    return prop;
  }

  // --- Decision Dossiers ---
  getDossiers() {
    return [...this.dossiers].reverse();
  }

  findDossierById(id) {
    return this.dossiers.find(d => d.id === id || d.dossierNumber === id) || null;
  }

  addDossier(dossier) {
    this.dossiers.unshift(dossier);
    this.persist();
    return dossier;
  }

  // --- Dashboard Summary Metrics ---
  getSummaryMetrics() {
    const totalParcels = this.parcels.length;
    const totalDatasets = this.datasets.length;
    const totalActs = this.acts.length;
    const totalProposals = this.proposals.length;
    const totalScenarios = this.scenarios.length;
    const totalDossiers = this.dossiers.length;

    let totalAreaHectares = 0;
    const landUseBreakdown = {};
    const stateBreakdown = {};

    this.parcels.forEach(p => {
      const ha = (p.areaSqm || 0) / 10000.0;
      totalAreaHectares += ha;
      landUseBreakdown[p.landUseClass] = (landUseBreakdown[p.landUseClass] || 0) + 1;
      stateBreakdown[p.state] = (stateBreakdown[p.state] || 0) + 1;
    });

    return {
      totalParcels,
      totalDatasets,
      totalActs,
      totalProposals,
      totalScenarios,
      totalDossiers,
      totalAreaHectares: parseFloat(totalAreaHectares.toFixed(2)),
      totalAreaAcres: parseFloat((totalAreaHectares * 2.47105).toFixed(2)),
      landUseBreakdown,
      stateBreakdown,
      demonstrationDataNotice: 'All parcel records and metrics in this deployment are calibrated demonstration datasets and should not be construed as official revenue records.'
    };
  }
}

module.exports = new DatabaseAdapter();
