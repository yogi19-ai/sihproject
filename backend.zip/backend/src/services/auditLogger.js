const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const AUDIT_STORE_PATH = path.join(__dirname, '..', 'data', 'audit_chain.json');
const GENESIS_PREV_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

class AuditLoggerService {
  constructor() {
    this.logs = [];
    this.initStore();
  }

  initStore() {
    try {
      const dataDir = path.dirname(AUDIT_STORE_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      if (fs.existsSync(AUDIT_STORE_PATH)) {
        const raw = fs.readFileSync(AUDIT_STORE_PATH, 'utf-8');
        this.logs = JSON.parse(raw);
      } else {
        // Create Genesis Block
        const genesisEntry = this.createGenesisBlock();
        this.logs = [genesisEntry];
        this.persist();
      }
    } catch (err) {
      console.error('[AuditLogger] Store init error:', err.message);
      this.logs = [this.createGenesisBlock()];
    }
  }

  createGenesisBlock() {
    const timestamp = '2026-01-01T00:00:00.000Z';
    const actorId = 'SYSTEM_GENESIS';
    const actorRole = 'System';
    const action = 'CHAIN_INITIALIZATION';
    const entityType = 'AuditChain';
    const entityId = 'GENESIS-001';
    const outcome = 'SUCCESS';
    const details = { message: 'SIH26019 National Land Governance Audit Ledger Initialized' };
    
    const payload = `${GENESIS_PREV_HASH}|${timestamp}|${actorId}|${action}|${entityType}|${entityId}|${outcome}|${JSON.stringify(details)}`;
    const currentHash = crypto.createHash('sha256').update(payload).digest('hex');

    return {
      index: 0,
      timestamp,
      actorId,
      actorRole,
      action,
      entityType,
      entityId,
      outcome,
      details,
      prevHash: GENESIS_PREV_HASH,
      currentHash
    };
  }

  persist() {
    try {
      fs.writeFileSync(AUDIT_STORE_PATH, JSON.stringify(this.logs, null, 2), 'utf-8');
    } catch (err) {
      console.error('[AuditLogger] Persist error:', err.message);
    }
  }

  logEvent({ actorId, actorRole, action, entityType, entityId, outcome = 'SUCCESS', details = {} }) {
    const prevEntry = this.logs[this.logs.length - 1];
    const prevHash = prevEntry ? prevEntry.currentHash : GENESIS_PREV_HASH;
    const timestamp = new Date().toISOString();
    const index = this.logs.length;

    // Filter out any sensitive information from details
    const sanitizedDetails = { ...details };
    delete sanitizedDetails.password;
    delete sanitizedDetails.token;
    delete sanitizedDetails.secret;

    const payload = `${prevHash}|${timestamp}|${actorId}|${action}|${entityType}|${entityId}|${outcome}|${JSON.stringify(sanitizedDetails)}`;
    const currentHash = crypto.createHash('sha256').update(payload).digest('hex');

    const entry = {
      index,
      timestamp,
      actorId: String(actorId || 'anonymous'),
      actorRole: String(actorRole || 'Viewer'),
      action: String(action),
      entityType: String(entityType || 'General'),
      entityId: String(entityId || 'N/A'),
      outcome: String(outcome),
      details: sanitizedDetails,
      prevHash,
      currentHash
    };

    this.logs.push(entry);
    this.persist();
    return entry;
  }

  getLogs({ limit = 100, page = 1, action, entityType, actorId } = {}) {
    let filtered = [...this.logs];
    if (action) filtered = filtered.filter(l => l.action.toLowerCase().includes(action.toLowerCase()));
    if (entityType) filtered = filtered.filter(l => l.entityType.toLowerCase() === entityType.toLowerCase());
    if (actorId) filtered = filtered.filter(l => l.actorId.toLowerCase().includes(actorId.toLowerCase()));

    // Return in reverse chronological order
    filtered.reverse();
    const total = filtered.length;
    const startIndex = (page - 1) * limit;
    const paginated = filtered.slice(startIndex, startIndex + limit);

    return {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      logs: paginated
    };
  }

  verifyChainIntegrity() {
    let isValid = true;
    const brokenAt = [];

    for (let i = 0; i < this.logs.length; i++) {
      const entry = this.logs[i];
      if (i === 0) {
        if (entry.prevHash !== GENESIS_PREV_HASH) {
          isValid = false;
          brokenAt.push({ index: 0, reason: 'Genesis block previous hash is invalid' });
        }
        continue;
      }

      const prevEntry = this.logs[i - 1];
      if (entry.prevHash !== prevEntry.currentHash) {
        isValid = false;
        brokenAt.push({
          index: i,
          reason: `Previous hash mismatch: expected ${prevEntry.currentHash}, found ${entry.prevHash}`
        });
      }

      const payload = `${entry.prevHash}|${entry.timestamp}|${entry.actorId}|${entry.action}|${entry.entityType}|${entry.entityId}|${entry.outcome}|${JSON.stringify(entry.details)}`;
      const recalculatedHash = crypto.createHash('sha256').update(payload).digest('hex');
      if (recalculatedHash !== entry.currentHash) {
        isValid = false;
        brokenAt.push({
          index: i,
          reason: `Hash corruption: recomputed ${recalculatedHash} !== stored ${entry.currentHash}`
        });
      }
    }

    return {
      isValid,
      totalEntries: this.logs.length,
      genesisHash: this.logs[0]?.currentHash,
      latestHash: this.logs[this.logs.length - 1]?.currentHash,
      brokenAt,
      verifiedAt: new Date().toISOString(),
      disclaimer: 'Cryptographic SHA-256 hash chaining detects post-hoc data tampering. In enterprise deployment, external ledger anchoring or WORM (Write Once Read Many) storage prevents unauthorized full-chain rewrite by root administrators.'
    };
  }
}

module.exports = new AuditLoggerService();
