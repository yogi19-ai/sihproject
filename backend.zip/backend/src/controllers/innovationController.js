const db = require('../models/db');
const auditLogger = require('../services/auditLogger');
const config = require('../config');

exports.getProposals = (req, res) => {
  try {
    const { status, category } = req.query;
    const proposals = db.getProposals({ status, category });
    res.json({
      count: proposals.length,
      proposals
    });
  } catch (err) {
    console.error('[innovationController.getProposals] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve innovation proposals.' });
  }
};

exports.getProposalById = (req, res) => {
  try {
    const { id } = req.params;
    const proposal = db.findProposalById(id);
    if (!proposal) {
      return res.status(404).json({ error: 'Proposal not found.' });
    }
    res.json({ proposal });
  } catch (err) {
    console.error('[innovationController.getProposalById] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve proposal.' });
  }
};

exports.submitProposal = (req, res) => {
  try {
    const {
      title,
      category,
      targetState,
      problemStatement,
      solutionSummary,
      budgetInr,
      timelineMonths,
      milestones
    } = req.body;

    if (!title || !category || !targetState || !problemStatement || !solutionSummary) {
      return res.status(400).json({ error: 'Title, category, state, problem statement, and solution are required.' });
    }

    const newProposal = {
      id: `prop-${Date.now().toString(36)}`,
      userId: req.user?.id || 'usr-anonymous',
      authorName: req.user?.fullName || 'Research Applicant',
      title,
      category,
      targetState,
      problemStatement,
      solutionSummary,
      budgetInr: parseFloat(budgetInr) || 1000000,
      timelineMonths: parseInt(timelineMonths) || 6,
      status: 'Submitted',
      reviewerScore: null,
      reviewerNotes: null,
      milestones: milestones || [
        { name: 'Phase 1: Field Reconnaissance & Methodology Finalization', status: 'Pending', deadline: 'Month 2' },
        { name: 'Phase 2: Pilot Deployment & Data Verification', status: 'Pending', deadline: 'Month 4' },
        { name: 'Phase 3: Final Policy Evaluation & RoR Interface', status: 'Pending', deadline: 'Month 6' }
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    db.addProposal(newProposal);

    auditLogger.logEvent({
      actorId: req.user?.id || 'anonymous',
      actorRole: req.user?.role || 'Researcher',
      action: 'INNOVATION_PROPOSAL_SUBMITTED',
      entityType: 'InnovationProposal',
      entityId: newProposal.id,
      outcome: 'SUCCESS',
      details: {
        title: newProposal.title,
        category: newProposal.category,
        budgetInr: newProposal.budgetInr
      }
    });

    res.status(201).json({
      message: 'Proposal successfully submitted to the National Land Innovation Review Committee.',
      proposal: newProposal
    });
  } catch (err) {
    console.error('[innovationController.submitProposal] Error:', err);
    res.status(500).json({ error: 'Failed to submit proposal.' });
  }
};

exports.reviewProposal = (req, res) => {
  try {
    const { id } = req.params;
    const { status, reviewerScore, reviewerNotes } = req.body;

    const validStatuses = ['Submitted', 'Under Review', 'Revision Requested', 'Shortlisted for Pilot', 'Completed'];
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Must be one of: [${validStatuses.join(', ')}]` });
    }

    const updated = db.updateProposalReview(id, {
      status,
      reviewerScore: reviewerScore !== undefined ? parseFloat(reviewerScore) : undefined,
      reviewerNotes
    });

    if (!updated) {
      return res.status(404).json({ error: 'Proposal not found.' });
    }

    auditLogger.logEvent({
      actorId: req.user?.id || 'admin',
      actorRole: req.user?.role || 'Administrator',
      action: 'INNOVATION_PROPOSAL_REVIEWED',
      entityType: 'InnovationProposal',
      entityId: id,
      outcome: 'SUCCESS',
      details: { status, reviewerScore, reviewerNotes }
    });

    res.json({
      message: 'Proposal review status recorded successfully.',
      proposal: updated
    });
  } catch (err) {
    console.error('[innovationController.reviewProposal] Error:', err);
    res.status(500).json({ error: 'Failed to record proposal review.' });
  }
};
