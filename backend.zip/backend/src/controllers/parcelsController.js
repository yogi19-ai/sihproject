const db = require('../models/db');
const UlpinValidator = require('../services/ulpinValidator');
const auditLogger = require('../services/auditLogger');
const config = require('../config');

// Helper to mask sensitive information for Viewers
function sanitizeParcelForRole(parcel, role) {
  if (role === config.roles.ADMINISTRATOR) {
    return parcel;
  }
  const sanitized = { ...parcel };
  // Non-admins do not see raw internal survey notes or private identity
  if (sanitized.ownershipCategory && sanitized.ownershipCategory.includes('Private')) {
    sanitized.ownershipCategory = 'Private Ryotwari (Protected under Privacy Guidelines)';
  }
  return sanitized;
}

exports.getParcelsByBbox = (req, res) => {
  try {
    const { minLat, maxLat, minLng, maxLng, state, district, landUseClass, verifiedStatus, limit, offset, scaleDemo } = req.query;

    const result = db.getParcelsByBbox({
      minLat,
      maxLat,
      minLng,
      maxLng,
      state,
      district,
      landUseClass,
      verifiedStatus,
      limit: parseInt(limit) || 100,
      offset: parseInt(offset) || 0
    });

    // If client requested large-scale demo benchmark (e.g. scaleDemo=1000)
    let parcels = result.parcels.map(p => sanitizeParcelForRole(p, req.user?.role));

    if (scaleDemo && parseInt(scaleDemo) > 0) {
      const scaleCount = Math.min(parseInt(scaleDemo), 5000); // cap per viewport request
      const demoGrid = generateSyntheticDenseParcels(
        parseFloat(minLat) || 18.5,
        parseFloat(maxLat) || 18.65,
        parseFloat(minLng) || 73.8,
        parseFloat(maxLng) || 74.0,
        scaleCount
      );
      parcels = parcels.concat(demoGrid);
    }

    res.json({
      total: result.total + (scaleDemo ? parseInt(scaleDemo) : 0),
      limit: parseInt(limit) || 100,
      offset: parseInt(offset) || 0,
      count: parcels.length,
      parcels,
      userRole: req.user?.role || 'Viewer'
    });
  } catch (err) {
    console.error('[parcelsController.getParcelsByBbox] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve parcels by bounding box.' });
  }
};

exports.getParcelByUlpin = (req, res) => {
  try {
    const { ulpin } = req.params;
    const validation = UlpinValidator.validate(ulpin);

    const parcel = db.findParcelByUlpin(ulpin);
    if (!parcel) {
      return res.status(404).json({
        found: false,
        ulpin,
        validation,
        message: 'No parcel record exists with this ULPIN in the current database index.'
      });
    }

    const sanitized = sanitizeParcelForRole(parcel, req.user?.role);
    res.json({
      found: true,
      parcel: sanitized,
      validation,
      units: {
        sqm: parcel.areaSqm,
        hectares: parseFloat((parcel.areaSqm / 10000.0).toFixed(4)),
        acres: parseFloat((parcel.areaSqm / 4046.8564).toFixed(4))
      }
    });
  } catch (err) {
    console.error('[parcelsController.getParcelByUlpin] Error:', err);
    res.status(500).json({ error: 'Failed to look up parcel by ULPIN.' });
  }
};

exports.validateUlpinSyntax = (req, res) => {
  const { ulpin } = req.body;
  const result = UlpinValidator.validate(ulpin);
  res.json(result);
};

exports.updateVerificationStatus = (req, res) => {
  try {
    const { ulpin } = req.params;
    const { status, remarks } = req.body;

    if (!['Verified', 'Demonstration', 'Imported'].includes(status)) {
      return res.status(400).json({ error: 'Status must be Verified, Demonstration, or Imported.' });
    }

    const updated = db.updateParcelVerification(ulpin, status, req.user.id);
    if (!updated) {
      return res.status(404).json({ error: 'Parcel not found.' });
    }

    auditLogger.logEvent({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: 'PARCEL_VERIFICATION_STATUS_CHANGED',
      entityType: 'Parcel',
      entityId: ulpin,
      outcome: 'SUCCESS',
      details: { newStatus: status, remarks }
    });

    res.json({
      message: `Parcel ${ulpin} verification status updated to '${status}'.`,
      parcel: updated
    });
  } catch (err) {
    console.error('[parcelsController.updateVerificationStatus] Error:', err);
    res.status(500).json({ error: 'Failed to update parcel status.' });
  }
};

// Generates synthetic demonstration parcels on-the-fly for WebGIS 50,000+ benchmark testing
function generateSyntheticDenseParcels(minLat, maxLat, minLng, maxLng, count) {
  const generated = [];
  const classes = ['Agricultural', 'Commercial / Logistics', 'IT / High-Tech SEZ', 'Reserved Forest Buffer', 'Mixed Residential / Commercial'];
  const latStep = (maxLat - minLat) / Math.sqrt(count);
  const lngStep = (maxLng - minLng) / Math.sqrt(count);
  let idx = 0;

  for (let lat = minLat; lat < maxLat && idx < count; lat += latStep) {
    for (let lng = minLng; lng < maxLng && idx < count; lng += lngStep) {
      idx++;
      const pLat = lat + Math.random() * (latStep * 0.7);
      const pLng = lng + Math.random() * (lngStep * 0.7);
      const halfSize = Math.min(latStep, lngStep) * 0.35;
      const poly = [
        [pLng - halfSize, pLat - halfSize],
        [pLng + halfSize, pLat - halfSize],
        [pLng + halfSize, pLat + halfSize],
        [pLng - halfSize, pLat + halfSize],
        [pLng - halfSize, pLat - halfSize]
      ];

      generated.push({
        id: `bench-${idx}`,
        ulpin: UlpinValidator.generateDemoUlpin('MH', idx + 100),
        state: 'Maharashtra',
        district: 'Pune',
        subDistrict: 'Benchmark Sub-District',
        village: `Sector-${Math.floor(idx / 100) + 1}`,
        surveyNumber: `${Math.floor(Math.random() * 500) + 1}/${Math.floor(Math.random() * 10) + 1}`,
        areaSqm: Math.floor(Math.random() * 25000 + 4000),
        landUseClass: classes[idx % classes.length],
        ownershipCategory: 'Demonstration Benchmark Layer',
        sourceAgency: 'SIH26019 Synthetic WebGIS Scalability Engine',
        verifiedStatus: 'Demonstration',
        centroidLat: pLat,
        centroidLng: pLng,
        polygon: poly,
        ndviCurrent: parseFloat((Math.random() * 0.7 + 0.1).toFixed(2)),
        ndwiCurrent: parseFloat((Math.random() * 0.6 - 0.4).toFixed(2)),
        lastSurveyDate: '2026-01-01'
      });
    }
  }

  return generated;
}
