const auditLogger = require('../services/auditLogger');

exports.getAuditLogs = (req, res) => {
  try {
    const { page, limit, action, entityType, actorId } = req.query;
    const result = auditLogger.getLogs({
      page: parseInt(page) || 1,
      limit: parseInt(limit) || 50,
      action,
      entityType,
      actorId
    });

    res.json(result);
  } catch (err) {
    console.error('[auditController.getAuditLogs] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve audit logs.' });
  }
};

exports.verifyChain = (req, res) => {
  try {
    const verification = auditLogger.verifyChainIntegrity();
    res.json({
      ...verification,
      performedBy: req.user?.email || 'Authorized Auditor',
      serverTime: new Date().toISOString()
    });
  } catch (err) {
    console.error('[auditController.verifyChain] Error:', err);
    res.status(500).json({ error: 'Failed to perform cryptographic audit chain verification.' });
  }
};
