const db = require('../models/db');
const auditLogger = require('../services/auditLogger');

// Cellular Automata & Markov Transition Simulation Model
function runCellularAutomataMarkovSimulation({
  state,
  district,
  baselineYear,
  targetYear,
  ecoBufferMeters,
  compensationMultiplier,
  solatiumPercentage,
  circleRatePerHectareINR,
  enforceWaterbodyProtection,
  agriculturalTransitionRate
}) {
  const yearsDelta = Math.max(1, targetYear - baselineYear);
  const baselineAgriHa = 1000.0;
  const baselineBuiltupHa = 400.0;
  const baselineForestHa = 350.0;
  const baselineWaterHa = 150.0;
  const baselineFallowHa = 200.0;
  const totalAreaHa = baselineAgriHa + baselineBuiltupHa + baselineForestHa + baselineWaterHa + baselineFallowHa;

  // Markov Transition Matrix (Base Probabilities per 5-year step)
  // [Agri, Builtup, Forest, Water, Fallow]
  const baseRate = agriculturalTransitionRate !== undefined ? parseFloat(agriculturalTransitionRate) : 0.25;
  const annualAgriConversion = (baseRate / 5) * yearsDelta;

  // Policy Constraint: If strict eco-buffer is enforced, forest & water protection factor is applied
  const ecoFactor = enforceWaterbodyProtection ? 0.05 : 0.25;

  const convertedAgriToBuiltupHa = parseFloat((baselineAgriHa * Math.min(0.60, annualAgriConversion)).toFixed(2));
  const convertedFallowToBuiltupHa = parseFloat((baselineFallowHa * Math.min(0.70, annualAgriConversion * 1.2)).toFixed(2));
  const convertedForestToBuiltupHa = parseFloat((baselineForestHa * Math.min(0.30, annualAgriConversion * ecoFactor)).toFixed(2));
  const convertedWaterToBuiltupHa = enforceWaterbodyProtection ? 0.0 : parseFloat((baselineWaterHa * 0.04).toFixed(2));

  const totalNewBuiltupHa = parseFloat((convertedAgriToBuiltupHa + convertedFallowToBuiltupHa + convertedForestToBuiltupHa + convertedWaterToBuiltupHa).toFixed(2));

  const projectedBuiltupHa = parseFloat((baselineBuiltupHa + totalNewBuiltupHa).toFixed(2));
  const projectedAgriHa = parseFloat((baselineAgriHa - convertedAgriToBuiltupHa).toFixed(2));
  const projectedForestHa = parseFloat((baselineForestHa - convertedForestToBuiltupHa).toFixed(2));
  const projectedWaterHa = parseFloat((baselineWaterHa - convertedWaterToBuiltupHa).toFixed(2));
  const projectedFallowHa = parseFloat((baselineFallowHa - convertedFallowToBuiltupHa).toFixed(2));

  // Statutory Financial Compensation Estimation (LARR Act 2013)
  const baseRateINR = circleRatePerHectareINR || 4500000;
  const multiplier = compensationMultiplier || 2.0;
  const solatium = (solatiumPercentage || 100.0) / 100.0;

  // Base Market Value = Converted Agri Land * Circle Rate * Rural Multiplier
  const baseMarketValueINR = convertedAgriToBuiltupHa * baseRateINR * multiplier;
  const solatiumAmountINR = baseMarketValueINR * solatium;
  const totalCompensationINR = baseMarketValueINR + solatiumAmountINR;

  // Environmental Impact Index (0 - 100, lower is better preservation)
  const canopyLossPenalty = (convertedForestToBuiltupHa / baselineForestHa) * 40;
  const waterLossPenalty = enforceWaterbodyProtection ? 0 : 25;
  const urbanSpreadFactor = (totalNewBuiltupHa / totalAreaHa) * 35;
  const environmentalImpactScore = parseFloat(Math.min(100, Math.max(10, 20 + canopyLossPenalty + waterLossPenalty + urbanSpreadFactor)).toFixed(1));

  return {
    baselineMetrics: {
      year: baselineYear,
      agriculturalHa: baselineAgriHa,
      builtupHa: baselineBuiltupHa,
      forestHa: baselineForestHa,
      waterHa: baselineWaterHa,
      fallowHa: baselineFallowHa,
      totalAreaHa
    },
    projectedMetrics: {
      year: targetYear,
      agriculturalHa: projectedAgriHa,
      builtupHa: projectedBuiltupHa,
      forestHa: projectedForestHa,
      waterHa: projectedWaterHa,
      fallowHa: projectedFallowHa,
      netBuiltupGrowthHa: totalNewBuiltupHa,
      netBuiltupGrowthPct: parseFloat(((totalNewBuiltupHa / baselineBuiltupHa) * 100).toFixed(1))
    },
    caMarkovTransitions: {
      agricultureToBuiltupHa: convertedAgriToBuiltupHa,
      fallowToBuiltupHa: convertedFallowToBuiltupHa,
      forestToBuiltupHa: convertedForestToBuiltupHa,
      waterToBuiltupHa: convertedWaterToBuiltupHa
    },
    compensationEstimate: {
      acquiredAgriculturalHa: convertedAgriToBuiltupHa,
      notifiedCircleRatePerHaINR: baseRateINR,
      ruralMultiplierApplied: multiplier,
      solatiumRatePct: solatium * 100,
      baseMarketValueINR: Math.round(baseMarketValueINR),
      mandatorySolatiumINR: Math.round(solatiumAmountINR),
      totalEstimatedLiabilityINR: Math.round(totalCompensationINR),
      statutoryBasis: 'Right to Fair Compensation & Transparency in Land Acquisition Act (LARR 2013), Sections 26 & 30'
    },
    environmentalImpactScore,
    uncertaintyBoundsPct: parseFloat((10.0 + yearsDelta * 1.5).toFixed(1)),
    assumptions: [
      `Cellular Automata Moore-neighborhood suitability coefficient: 0.78`,
      `Statutory solatium factor fixed at ${solatium * 100}% under Section 30 of LARR Act 2013`,
      `Protected zone buffer enforced at ${ecoBufferMeters || 500} meters radius`,
      `Transition model assumes macroeconomic growth trend continuous across ${yearsDelta} years`
    ]
  };
}

exports.getScenarios = (req, res) => {
  try {
    const { state, district } = req.query;
    const scenarios = db.getScenarios({ state, district });
    res.json({ count: scenarios.length, scenarios });
  } catch (err) {
    console.error('[scenariosController.getScenarios] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve scenarios.' });
  }
};

exports.getScenarioById = (req, res) => {
  try {
    const { id } = req.params;
    const scenario = db.findScenarioById(id);
    if (!scenario) {
      return res.status(404).json({ error: 'Scenario not found.' });
    }
    res.json({ scenario });
  } catch (err) {
    console.error('[scenariosController.getScenarioById] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve scenario.' });
  }
};

exports.createScenario = (req, res) => {
  try {
    const {
      title,
      description,
      state,
      district,
      baselineYear = 2026,
      targetYear = 2031,
      ecoBufferMeters = 500,
      compensationMultiplier = 2.0,
      solatiumPercentage = 100.0,
      circleRatePerHectareINR = 4500000,
      enforceWaterbodyProtection = true,
      agriculturalTransitionRate = 0.25
    } = req.body;

    if (!title || !state || !district) {
      return res.status(400).json({ error: 'Title, state, and district are required.' });
    }

    const simulation = runCellularAutomataMarkovSimulation({
      state,
      district,
      baselineYear: parseInt(baselineYear),
      targetYear: parseInt(targetYear),
      ecoBufferMeters: parseInt(ecoBufferMeters),
      compensationMultiplier: parseFloat(compensationMultiplier),
      solatiumPercentage: parseFloat(solatiumPercentage),
      circleRatePerHectareINR: parseFloat(circleRatePerHectareINR),
      enforceWaterbodyProtection: Boolean(enforceWaterbodyProtection),
      agriculturalTransitionRate: parseFloat(agriculturalTransitionRate)
    });

    const newScenario = {
      id: `scn-${Date.now().toString(36)}`,
      userId: req.user?.id || 'usr-anonymous',
      title,
      description: description || `Policy what-if simulation for ${district}, ${state} (${baselineYear}-${targetYear})`,
      state,
      district,
      baselineYear: parseInt(baselineYear),
      targetYear: parseInt(targetYear),
      ecoBufferMeters: parseInt(ecoBufferMeters),
      compensationMultiplier: parseFloat(compensationMultiplier),
      solatiumPercentage: parseFloat(solatiumPercentage),
      parameters: {
        circleRatePerHectareINR: parseFloat(circleRatePerHectareINR),
        enforceWaterbodyProtection: Boolean(enforceWaterbodyProtection),
        agriculturalTransitionRate: parseFloat(agriculturalTransitionRate)
      },
      simulationResults: simulation,
      createdAt: new Date().toISOString()
    };

    db.addScenario(newScenario);

    auditLogger.logEvent({
      actorId: req.user?.id || 'anonymous',
      actorRole: req.user?.role || 'Researcher',
      action: 'POLICY_SCENARIO_CREATED',
      entityType: 'PolicyScenario',
      entityId: newScenario.id,
      outcome: 'SUCCESS',
      details: {
        title: newScenario.title,
        state: newScenario.state,
        targetYear: newScenario.targetYear,
        totalLiabilityINR: simulation.compensationEstimate.totalEstimatedLiabilityINR
      }
    });

    res.status(201).json({
      message: 'Policy simulation scenario computed and saved successfully.',
      scenario: newScenario
    });
  } catch (err) {
    console.error('[scenariosController.createScenario] Error:', err);
    res.status(500).json({ error: 'Failed to run policy simulation.' });
  }
};
