const db = require('../models/db');
const auditLogger = require('../services/auditLogger');
const UlpinValidator = require('../services/ulpinValidator');

exports.getDatasets = (req, res) => {
  try {
    const { category, state, search } = req.query;
    const datasets = db.getDatasets({ category, state, search });
    res.json({
      count: datasets.length,
      datasets
    });
  } catch (err) {
    console.error('[datasetsController.getDatasets] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve dataset catalogue.' });
  }
};

exports.getDatasetById = (req, res) => {
  try {
    const { id } = req.params;
    const dataset = db.findDatasetById(id);
    if (!dataset) {
      return res.status(404).json({ error: 'Dataset not found.' });
    }
    res.json({ dataset });
  } catch (err) {
    console.error('[datasetsController.getDatasetById] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve dataset.' });
  }
};

exports.uploadAndIngestDataset = (req, res) => {
  try {
    const { title, sourceAgency, coverageState, category, rawContent, format } = req.body;

    if (!title || !sourceAgency || !coverageState) {
      return res.status(400).json({ error: 'Title, source agency, and coverage state are required.' });
    }

    // Ingestion & Schema Normalization Simulator
    let recordCount = 0;
    let validUlpinCount = 0;
    let invalidUlpinCount = 0;
    const validationErrors = [];
    const sampleRows = [];

    if (rawContent && typeof rawContent === 'string') {
      const lines = rawContent.split('\n').filter(l => l.trim().length > 0);
      const headers = lines[0]?.split(',').map(h => h.trim().toLowerCase()) || [];
      
      const ulpinIdx = headers.findIndex(h => h.includes('ulpin') || h.includes('bhu_aadhaar'));
      const stateIdx = headers.findIndex(h => h.includes('state'));
      const districtIdx = headers.findIndex(h => h.includes('district'));
      const surveyIdx = headers.findIndex(h => h.includes('survey'));

      for (let i = 1; i < Math.min(lines.length, 100); i++) {
        const parts = lines[i].split(',').map(p => p.trim());
        recordCount++;
        const ulpin = ulpinIdx !== -1 ? parts[ulpinIdx] : UlpinValidator.generateDemoUlpin(coverageState.substring(0, 2), i);
        const valRes = UlpinValidator.validate(ulpin);
        
        if (valRes.isValid) {
          validUlpinCount++;
        } else {
          invalidUlpinCount++;
          validationErrors.push(`Row ${i}: Invalid ULPIN '${ulpin}' - ${valRes.reason}`);
        }

        sampleRows.push({
          row: i,
          ulpin,
          surveyNumber: surveyIdx !== -1 ? parts[surveyIdx] : `${i}/1`,
          district: districtIdx !== -1 ? parts[districtIdx] : coverageState,
          status: valRes.isValid ? 'Valid Syntax' : 'Syntax Warning'
        });
      }
    } else {
      recordCount = 250;
      validUlpinCount = 245;
      invalidUlpinCount = 5;
    }

    const newDataset = {
      id: `ds-${Date.now().toString(36)}`,
      title,
      sourceAgency,
      coverageState,
      category: category || 'Cadastral & RoR',
      format: format || 'GeoJSON / CSV',
      recordsCount: recordCount,
      fileSizeMb: parseFloat((recordCount * 0.002).toFixed(2)) + 0.1,
      qualityScore: parseFloat(((validUlpinCount / Math.max(recordCount, 1)) * 100).toFixed(1)),
      verificationStatus: 'Imported',
      licenseInfo: 'State Portal Interoperability Standard / GODL',
      metadata: {
        ingestedBy: req.user?.fullName || 'Authorized Officer',
        ingestedAt: new Date().toISOString(),
        validUlpinCount,
        invalidUlpinCount,
        validationErrors: validationErrors.slice(0, 5),
        samplePreview: sampleRows.slice(0, 5)
      }
    };

    db.addDataset(newDataset);

    // Record SHA-256 Tamper-Evident Audit Event
    auditLogger.logEvent({
      actorId: req.user?.id || 'anonymous',
      actorRole: req.user?.role || 'Administrator',
      action: 'DATASET_INGESTED',
      entityType: 'Dataset',
      entityId: newDataset.id,
      outcome: 'SUCCESS',
      details: {
        title: newDataset.title,
        recordsCount: newDataset.recordsCount,
        qualityScore: newDataset.qualityScore
      }
    });

    res.status(201).json({
      message: 'Dataset uploaded, validated, and normalized successfully.',
      dataset: newDataset,
      ingestionReport: {
        totalRecordsProcessed: recordCount,
        validUlpins: validUlpinCount,
        invalidUlpins: invalidUlpinCount,
        qualityScore: newDataset.qualityScore,
        schemaNormalized: true,
        coordinateReferenceSystem: 'EPSG:4326 (WGS84)',
        disclaimer: 'Data ingested as Demonstration/Imported tier. Official gazette notification required for judicial enforcement.'
      }
    });
  } catch (err) {
    console.error('[datasetsController.uploadAndIngestDataset] Error:', err);
    res.status(500).json({ error: 'Failed to ingest dataset.' });
  }
};
