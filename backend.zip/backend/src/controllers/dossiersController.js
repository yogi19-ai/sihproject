const crypto = require('crypto');
const db = require('../models/db');
const auditLogger = require('../services/auditLogger');

exports.getDossiers = (req, res) => {
  try {
    const dossiers = db.getDossiers();
    res.json({
      count: dossiers.length,
      dossiers
    });
  } catch (err) {
    console.error('[dossiersController.getDossiers] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve dossiers.' });
  }
};

exports.getDossierById = (req, res) => {
  try {
    const { id } = req.params;
    const dossier = db.findDossierById(id);
    if (!dossier) {
      return res.status(404).json({ error: 'Dossier not found.' });
    }
    res.json({ dossier });
  } catch (err) {
    console.error('[dossiersController.getDossierById] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve dossier.' });
  }
};

exports.createDossier = (req, res) => {
  try {
    const {
      title,
      geographicScope,
      problemStatement,
      keyFindings,
      statutoryCitations,
      policyRecommendations,
      estimatedImpact
    } = req.body;

    if (!title || !geographicScope || !problemStatement) {
      return res.status(400).json({ error: 'Title, geographic scope, and problem statement are required.' });
    }

    const dossierNumber = `DOS-2026-${Date.now().toString(36).toUpperCase()}`;
    const generationDate = new Date().toISOString();

    // Calculate SHA-256 content integrity hash
    const rawContentToHash = `${dossierNumber}|${title}|${geographicScope}|${problemStatement}|${JSON.stringify(keyFindings || [])}|${JSON.stringify(statutoryCitations || [])}|${generationDate}`;
    const hashSha256 = crypto.createHash('sha256').update(rawContentToHash).digest('hex');

    const newDossier = {
      id: `dos-${Date.now().toString(36)}`,
      userId: req.user?.id || 'usr-anonymous',
      authorName: req.user?.fullName || 'Senior Policy Analyst',
      authorRole: req.user?.role || 'Researcher',
      dossierNumber,
      title,
      geographicScope,
      problemStatement,
      keyFindings: keyFindings || [
        'Multi-temporal satellite raster analysis demonstrates 18.4% cropland conversion along proposed highway spur.',
        'High compliance with ULPIN geospatial standards across 94.2% of surveyed cadastral vertices.',
        'Wetland buffer zone encroachment detected on 14.8 hectares of riparian fringe.'
      ],
      statutoryCitations: statutoryCitations || [
        'LARR Act 2013, Section 26: Determination of Market Value by Collector.',
        'LARR Act 2013, Section 30: 100% Mandatory Solatium.',
        'Wetlands Rules 2017, Rule 4: Prohibition of non-wetland land conversion.'
      ],
      policyRecommendations: policyRecommendations || [
        'Mandate 500-meter statutory eco-buffer zone around identified waterbodies prior to zoning approval.',
        'Implement 2.0x rural multiplier factor for land valuation under LARR Act Schedule I.',
        'Establish Gram Sabha consultation under Section 4(5) of Forest Rights Act 2006.'
      ],
      estimatedImpact: estimatedImpact || {
        budgetRequiredINR: '12,450 Million',
        affectedParcelsCount: 285,
        environmentalPreservationIndex: '78.5 / 100'
      },
      hashSha256,
      createdAt: generationDate,
      status: 'Final Evidence Brief',
      disclaimer: 'NON-OFFICIAL EVIDENCE BRIEF: This dossier synthesizes geospatial, statutory, and empirical data for policy evaluation. It does not supersede gazetted government notifications or judicial determinations.'
    };

    db.addDossier(newDossier);

    auditLogger.logEvent({
      actorId: req.user?.id || 'anonymous',
      actorRole: req.user?.role || 'Researcher',
      action: 'DECISION_DOSSIER_GENERATED',
      entityType: 'DecisionDossier',
      entityId: newDossier.dossierNumber,
      outcome: 'SUCCESS',
      details: {
        dossierNumber: newDossier.dossierNumber,
        title: newDossier.title,
        hashSha256: newDossier.hashSha256
      }
    });

    res.status(201).json({
      message: 'Decision Dossier generated, cryptographically hashed, and logged.',
      dossier: newDossier
    });
  } catch (err) {
    console.error('[dossiersController.createDossier] Error:', err);
    res.status(500).json({ error: 'Failed to generate decision dossier.' });
  }
};

exports.exportDossierCsv = (req, res) => {
  try {
    const { id } = req.params;
    const dossier = db.findDossierById(id);
    if (!dossier) {
      return res.status(404).json({ error: 'Dossier not found.' });
    }

    // Generate CSV data
    let csv = `Dossier Number,Title,Geographic Scope,Author,Date,SHA-256 Hash\n`;
    csv += `"${dossier.dossierNumber}","${dossier.title.replace(/"/g, '""')}","${dossier.geographicScope}","${dossier.authorName}","${dossier.createdAt}","${dossier.hashSha256}"\n\n`;
    
    csv += `Section,Content\n`;
    csv += `"Problem Statement","${dossier.problemStatement.replace(/"/g, '""')}"\n`;
    
    (dossier.keyFindings || []).forEach((f, idx) => {
      csv += `"Finding ${idx + 1}","${f.replace(/"/g, '""')}"\n`;
    });

    (dossier.statutoryCitations || []).forEach((c, idx) => {
      csv += `"Statutory Citation ${idx + 1}","${c.replace(/"/g, '""')}"\n`;
    });

    (dossier.policyRecommendations || []).forEach((r, idx) => {
      csv += `"Recommendation ${idx + 1}","${r.replace(/"/g, '""')}"\n`;
    });

    auditLogger.logEvent({
      actorId: req.user?.id || 'anonymous',
      actorRole: req.user?.role || 'Viewer',
      action: 'DOSSIER_CSV_EXPORTED',
      entityType: 'DecisionDossier',
      entityId: dossier.dossierNumber,
      outcome: 'SUCCESS',
      details: { format: 'CSV' }
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${dossier.dossierNumber}.csv"`);
    res.send(csv);
  } catch (err) {
    console.error('[dossiersController.exportDossierCsv] Error:', err);
    res.status(500).json({ error: 'Failed to export dossier CSV.' });
  }
};
