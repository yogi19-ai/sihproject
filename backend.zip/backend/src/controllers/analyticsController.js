const db = require('../models/db');

exports.getAnalyticsWorkspace = (req, res) => {
  try {
    const { region = 'Maharashtra - Pune Corridor', sensor = 'Sentinel-2 / Resourcesat-2A', year = '2026' } = req.query;

    const parcels = db.parcels;
    let totalSampleParcels = parcels.length;
    let avgNdvi = 0;
    let avgNdwi = 0;

    parcels.forEach(p => {
      avgNdvi += (p.ndviCurrent || 0.45);
      avgNdwi += (p.ndwiCurrent || -0.1);
    });

    avgNdvi = parseFloat((avgNdvi / Math.max(totalSampleParcels, 1)).toFixed(3));
    avgNdwi = parseFloat((avgNdwi / Math.max(totalSampleParcels, 1)).toFixed(3));

    // Multi-temporal LULC Change Matrix (2021 Baseline vs 2026 Current)
    const lulcChangeMatrix = [
      {
        class: 'Agricultural Land',
        baseline2021Ha: 1420.5,
        current2026Ha: 1145.2,
        netChangeHa: -275.3,
        netChangePct: -19.38,
        primaryDriver: 'Urban Expansion / Highway Corridor Development'
      },
      {
        class: 'Built-up / Urban Infrastructure',
        baseline2021Ha: 480.0,
        current2026Ha: 785.4,
        netChangeHa: 305.4,
        netChangePct: 63.63,
        primaryDriver: 'Industrial Logistics Parks & High-Tech Zones'
      },
      {
        class: 'Forest & Eco-Sensitive Buffer',
        baseline2021Ha: 610.8,
        current2026Ha: 588.1,
        netChangeHa: -22.7,
        netChangePct: -3.72,
        primaryDriver: 'Perimeter Infrastructure Encroachment'
      },
      {
        class: 'Waterbodies & Drainage Corridors',
        baseline2021Ha: 185.0,
        current2026Ha: 178.6,
        netChangeHa: -6.4,
        netChangePct: -3.46,
        primaryDriver: 'Siltation and Buffer Compaction'
      },
      {
        class: 'Barren / Fallow Land',
        baseline2021Ha: 320.0,
        current2026Ha: 319.0,
        netChangeHa: -1.0,
        netChangePct: -0.31,
        primaryDriver: 'Reclamation & Grading'
      }
    ];

    // NDVI Spectral Distribution Histogram
    const ndviHistogram = [
      { range: '< 0.0 (Water / Deep Shadows)', count: 4, label: 'Waterbodies' },
      { range: '0.0 - 0.2 (Built-up / Concrete)', count: 28, label: 'Impervious Surfaces' },
      { range: '0.2 - 0.4 (Sparse Vegetation / Fallow)', count: 35, label: 'Fallow / Open Scrub' },
      { range: '0.4 - 0.6 (Moderate Crops)', count: 48, label: 'Agricultural Cropland' },
      { range: '0.6 - 0.8+ (Dense Canopy)', count: 22, label: 'Forest / Orchards' }
    ];

    res.json({
      workspaceRegion: region,
      satelliteSensor: sensor,
      analysisCycle: `${year} Pre-Monsoon / Post-Monsoon Composite`,
      metrics: {
        totalAreaAnalyzedHa: 3016.3,
        averageNdvi: avgNdvi,
        averageNdwi: avgNdwi,
        vegetationStressScore: 'Moderate (Dry Season Seasonal Drop)',
        surfaceWaterRetentionIndex: 0.72
      },
      lulcChangeMatrix,
      ndviHistogram,
      methodology: {
        ndviFormula: 'NDVI = (NIR - Red) / (NIR + Red) using Band 8 (842nm) and Band 4 (665nm)',
        ndwiFormula: 'NDWI = (Green - NIR) / (Green + NIR) using Band 3 (560nm) and Band 8 (842nm)',
        temporalBaseline: '2021 Copernicus Sentinel-2 Level-2A Orthorectified Surface Reflectance',
        radiometricCorrection: 'Bottom-Of-Atmosphere (BOA) atmospheric correction'
      },
      disclaimer: 'INDICATOR NOTICE: Normalized Difference Spectral Indices (NDVI and NDWI) are biophysical indicators of green biomass and moisture content. They do NOT constitute standalone proof of cadastral ownership, boundary delineation, or unauthorized encroachment without field ground truthing by Revenue Surveyors.'
    });
  } catch (err) {
    console.error('[analyticsController.getAnalyticsWorkspace] Error:', err);
    res.status(500).json({ error: 'Failed to compute geo-analytics workspace.' });
  }
};
