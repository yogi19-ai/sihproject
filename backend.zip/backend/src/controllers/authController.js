const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../models/db');
const auditLogger = require('../services/auditLogger');

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = db.findUserByEmail(email);
    if (!user) {
      auditLogger.logEvent({
        actorId: email,
        actorRole: 'Unknown',
        action: 'USER_LOGIN_FAILED',
        entityType: 'User',
        entityId: email,
        outcome: 'FAILURE',
        details: { reason: 'User not found' }
      });
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Compare bcrypt password
    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      auditLogger.logEvent({
        actorId: user.id,
        actorRole: user.role,
        action: 'USER_LOGIN_FAILED',
        entityType: 'User',
        entityId: user.id,
        outcome: 'FAILURE',
        details: { reason: 'Password mismatch' }
      });
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Sign JWT
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    // Record SHA-256 Audit Log
    auditLogger.logEvent({
      actorId: user.id,
      actorRole: user.role,
      action: 'USER_LOGIN_SUCCESS',
      entityType: 'User',
      entityId: user.id,
      outcome: 'SUCCESS',
      details: { email: user.email, role: user.role, ip: req.ip }
    });

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        designation: user.designation,
        department: user.department,
        stateJurisdiction: user.stateJurisdiction,
        permissions: config.permissions[user.role] || []
      }
    });
  } catch (err) {
    console.error('[authController.login] Error:', err);
    res.status(500).json({ error: 'Internal server error during authentication.' });
  }
};

exports.getProfile = (req, res) => {
  if (!req.user || req.user.id === 'usr-anonymous') {
    return res.json({
      authenticated: false,
      user: {
        role: config.roles.VIEWER,
        fullName: 'Public Guest',
        permissions: config.permissions.Viewer
      }
    });
  }

  const user = db.findUserById(req.user.id);
  res.json({
    authenticated: true,
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      designation: user.designation,
      department: user.department,
      stateJurisdiction: user.stateJurisdiction,
      permissions: config.permissions[user.role] || []
    }
  });
};
