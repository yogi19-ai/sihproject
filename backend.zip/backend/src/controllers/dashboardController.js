const db = require('../models/db');
const auditLogger = require('../services/auditLogger');
const config = require('../config');

exports.getNationalOverview = (req, res) => {
  try {
    const metrics = db.getSummaryMetrics();
    const recentActivity = auditLogger.getLogs({ limit: 6 }).logs;
    const recentDatasets = db.getDatasets().slice(0, 4);

    res.json({
      summaryCards: {
        totalParcels: metrics.totalParcels,
        totalDatasets: metrics.totalDatasets,
        totalStatutoryActs: metrics.totalActs,
        activeInnovationProposals: metrics.totalProposals,
        policyScenariosCreated: metrics.totalScenarios,
        decisionDossiersPublished: metrics.totalDossiers,
        totalMappedHectares: metrics.totalAreaHectares,
        totalMappedAcres: metrics.totalAreaAcres
      },
      landUseBreakdown: metrics.landUseBreakdown,
      stateBreakdown: metrics.stateBreakdown,
      recentDatasets,
      recentActivity,
      demonstrationNotice: metrics.demonstrationDataNotice
    });
  } catch (err) {
    console.error('[dashboardController.getNationalOverview] Error:', err);
    res.status(500).json({ error: 'Failed to retrieve national overview metrics.' });
  }
};

exports.getHealthStatus = (req, res) => {
  const auditVerification = auditLogger.verifyChainIntegrity();

  res.json({
    status: 'HEALTHY',
    service: 'SIH26019 National Land Governance Platform Core API',
    version: '1.0.0',
    environment: config.nodeEnv,
    timestamp: new Date().toISOString(),
    subsystems: {
      apiServer: { status: 'OPERATIONAL', port: config.port },
      databaseAdapter: {
        status: 'OPERATIONAL',
        engine: config.databaseUrl ? 'PostgreSQL 16 + PostGIS' : 'Integrated High-Performance Spatial Store',
        totalParcelsIndexed: db.parcels.length
      },
      auditLedger: {
        status: auditVerification.isValid ? 'VERIFIED_TAMPER_FREE' : 'WARNING_CHAIN_MISMATCH',
        totalBlocks: auditVerification.totalEntries,
        latestHash: auditVerification.latestHash
      },
      ulpinValidationEngine: {
        status: 'OPERATIONAL',
        standard: 'DoLR Bhu-Aadhaar 14-digit ISO-7064'
      },
      pyGeoAiService: {
        status: 'CONNECTED',
        url: config.aiServiceUrl
      }
    }
  });
};
