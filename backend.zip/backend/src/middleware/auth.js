const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../models/db');

/**
 * Authentication Middleware: Extracts and verifies JWT bearer token
 */
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    // If no token, set req.user to anonymous Viewer so public endpoints can still function
    req.user = {
      id: 'usr-anonymous',
      email: 'public@guest.landgov.in',
      role: config.roles.VIEWER,
      fullName: 'Public Guest'
    };
    return next();
  }

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    const user = db.findUserById(decoded.id);
    if (!user) {
      return res.status(401).json({ error: 'User account not found or expired session.' });
    }
    req.user = {
      id: user.id,
      email: user.email,
      role: user.role,
      fullName: user.fullName,
      department: user.department,
      stateJurisdiction: user.stateJurisdiction
    };
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired authorization token.', details: err.message });
  }
}

/**
 * Strict Authentication Middleware: Requires a valid logged-in user
 */
function requireAuth(req, res, next) {
  if (!req.user || req.user.id === 'usr-anonymous') {
    return res.status(401).json({
      error: 'Authentication required. Please log in with authorized credentials.',
      code: 'AUTH_REQUIRED'
    });
  }
  next();
}

/**
 * RBAC Role Check Middleware: Restricts access to specific role tiers
 * @param {Array<string>} allowedRoles 
 */
function requireRole(allowedRoles = []) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required.', code: 'UNAUTHENTICATED' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Access Denied: Your role '${req.user.role}' lacks permission for this operation. Required: [${allowedRoles.join(', ')}].`,
        code: 'FORBIDDEN_ROLE',
        userRole: req.user.role,
        requiredRoles: allowedRoles
      });
    }
    next();
  };
}

/**
 * RBAC Permission Check Middleware: Checks granular permission strings
 * @param {string} permission 
 */
function requirePermission(permission) {
  return (req, res, next) => {
    const userRole = req.user ? req.user.role : config.roles.VIEWER;
    const allowed = config.permissions[userRole] || [];
    if (!allowed.includes(permission)) {
      return res.status(403).json({
        error: `Permission Denied: Your role '${userRole}' lacks permission '${permission}'.`,
        code: 'FORBIDDEN_PERMISSION',
        permission
      });
    }
    next();
  };
}

module.exports = {
  authenticateToken,
  requireAuth,
  requireRole,
  requirePermission
};
