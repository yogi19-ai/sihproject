const express = require('express');
const router = express.Router();

const { authenticateToken, requireAuth, requireRole } = require('../middleware/auth');
const authController = require('../controllers/authController');
const parcelsController = require('../controllers/parcelsController');
const datasetsController = require('../controllers/datasetsController');
const legalController = require('../controllers/legalController');
const analyticsController = require('../controllers/analyticsController');
const scenariosController = require('../controllers/scenariosController');
const innovationController = require('../controllers/innovationController');
const dossiersController = require('../controllers/dossiersController');
const auditController = require('../controllers/auditController');
const dashboardController = require('../controllers/dashboardController');

// Global token authentication middleware (attaches req.user or guest)
router.use(authenticateToken);

// 1. Health & Dashboard Overview
router.get('/health', dashboardController.getHealthStatus);
router.get('/dashboard/overview', dashboardController.getNationalOverview);

// 2. Authentication & Profile
router.post('/auth/login', authController.login);
router.get('/auth/me', authController.getProfile);

// 3. Land Parcels & WebGIS Spatial Queries
router.get('/parcels/bbox', parcelsController.getParcelsByBbox);
router.get('/parcels/ulpin/:ulpin', parcelsController.getParcelByUlpin);
router.post('/parcels/validate-ulpin', parcelsController.validateUlpinSyntax);
router.patch('/parcels/:ulpin/verify', requireAuth, requireRole(['Administrator']), parcelsController.updateVerificationStatus);

// 4. Ingested Datasets Catalogue
router.get('/datasets', datasetsController.getDatasets);
router.get('/datasets/:id', datasetsController.getDatasetById);
router.post('/datasets/upload', requireAuth, requireRole(['Administrator', 'Researcher']), datasetsController.uploadAndIngestDataset);

// 5. Research & Legal Evidence Assistant
router.post('/legal/search', legalController.searchLegalEvidence);
router.get('/legal/acts', legalController.getStatutoryActsList);

// 6. Geo-Analytics & Satellite NDVI/NDWI Workspace
router.get('/analytics/workspace', analyticsController.getAnalyticsWorkspace);

// 7. Policy What-If Simulator (Cellular Automata & Markov)
router.get('/scenarios', scenariosController.getScenarios);
router.get('/scenarios/:id', scenariosController.getScenarioById);
router.post('/scenarios/create', requireAuth, requireRole(['Researcher', 'Administrator']), scenariosController.createScenario);

// 8. Open Innovation Hub (Grants, Hackathons & Pilots)
router.get('/innovation/proposals', innovationController.getProposals);
router.get('/innovation/proposals/:id', innovationController.getProposalById);
router.post('/innovation/submit', requireAuth, innovationController.submitProposal);
router.patch('/innovation/review/:id', requireAuth, requireRole(['Administrator']), innovationController.reviewProposal);

// 9. Decision Dossiers & Policy Briefs
router.get('/dossiers', dossiersController.getDossiers);
router.get('/dossiers/:id', dossiersController.getDossierById);
router.post('/dossiers/create', requireAuth, requireRole(['Researcher', 'Administrator']), dossiersController.createDossier);
router.get('/dossiers/:id/export-csv', dossiersController.exportDossierCsv);

// 10. Tamper-Evident SHA-256 Audit Logs (Restricted to Administrator)
router.get('/audit/logs', requireAuth, requireRole(['Administrator']), auditController.getAuditLogs);
router.get('/audit/verify', requireAuth, requireRole(['Administrator']), auditController.verifyChain);

module.exports = router;
