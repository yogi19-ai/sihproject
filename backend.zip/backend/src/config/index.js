const path = require('path');
require('dotenv').config();

module.exports = {
  port: process.env.PORT || 5000,
  aiServiceUrl: process.env.AI_SERVICE_URL || 'http://127.0.0.1:8000',
  jwtSecret: process.env.JWT_SECRET || 'sih26019-national-land-governance-secret-key-2026',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
  nodeEnv: process.env.NODE_ENV || 'development',
  databaseUrl: process.env.DATABASE_URL || '',
  citationVerificationThreshold: parseFloat(process.env.CITATION_VERIFY_THRESHOLD || '0.85'),
  roles: {
    VIEWER: 'Viewer',
    RESEARCHER: 'Researcher',
    ADMINISTRATOR: 'Administrator'
  },
  permissions: {
    Viewer: [
      'parcels:read_public',
      'datasets:read',
      'legal:search',
      'analytics:read',
      'scenarios:read',
      'innovation:read_challenges'
    ],
    Researcher: [
      'parcels:read_public',
      'datasets:read',
      'datasets:download',
      'legal:search',
      'analytics:run',
      'scenarios:create',
      'scenarios:export',
      'innovation:submit',
      'innovation:read_challenges',
      'dossiers:create',
      'dossiers:export'
    ],
    Administrator: [
      'parcels:read_public',
      'parcels:read_sensitive',
      'parcels:verify',
      'datasets:read',
      'datasets:upload',
      'datasets:verify',
      'legal:search',
      'legal:manage',
      'analytics:run',
      'scenarios:create',
      'scenarios:export',
      'scenarios:admin_override',
      'innovation:submit',
      'innovation:review',
      'dossiers:create',
      'dossiers:export',
      'audit:read',
      'audit:verify',
      'admin:manage_users'
    ]
  }
};
