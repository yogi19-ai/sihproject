const assert = require('assert');
const UlpinValidator = require('../src/services/ulpinValidator');
const auditLogger = require('../src/services/auditLogger');
const db = require('../src/models/db');
const config = require('../src/config');

console.log('====================================================================');
console.log('🧪 Starting SIH26019 National Land Governance Platform Test Suite');
console.log('====================================================================\n');

let testsPassed = 0;
let testsFailed = 0;

function runTest(name, fn) {
  try {
    fn();
    console.log(`  ✅ PASS: ${name}`);
    testsPassed++;
  } catch (err) {
    console.error(`  ❌ FAIL: ${name}`);
    console.error(`     Reason: ${err.message}`);
    testsFailed++;
  }
}

// 1. ULPIN 14-Digit Format & Validator Tests
console.log('▶ Module 1: ULPIN / Bhu-Aadhaar Standard Validation');
runTest('Valid 14-character ULPIN passes syntax validation', () => {
  const result = UlpinValidator.validate('MH26000190012A');
  assert.strictEqual(result.isValid, true);
  assert.strictEqual(result.ulpin.length, 14);
  assert.ok(result.legalDisclaimer.includes('STATUTORY NOTICE'));
});

runTest('Short ULPIN (< 14 chars) is rejected', () => {
  const result = UlpinValidator.validate('MH12345');
  assert.strictEqual(result.isValid, false);
  assert.ok(result.reason.includes('must be exactly 14 characters'));
});

runTest('ULPIN with special characters is rejected', () => {
  const result = UlpinValidator.validate('MH2600019@012#');
  assert.strictEqual(result.isValid, false);
  assert.ok(result.reason.includes('alphanumeric characters'));
});

runTest('Validation confirms syntactic validity is NOT legal title proof', () => {
  const result = UlpinValidator.validate('UP26000590056E');
  assert.strictEqual(result.isLegalProof, false);
});

// 2. Cryptographic SHA-256 Audit Chain Tests
console.log('\n▶ Module 2: SHA-256 Tamper-Evident Audit Ledger');
runTest('Audit chain starts with Genesis Block at index 0', () => {
  const chain = auditLogger.logs;
  assert.ok(chain.length > 0);
  assert.strictEqual(chain[0].index, 0);
  assert.strictEqual(chain[0].prevHash, '0000000000000000000000000000000000000000000000000000000000000000');
});

runTest('New event is chained with previous hash and correct SHA-256 digest', () => {
  const entry = auditLogger.logEvent({
    actorId: 'usr-admin-001',
    actorRole: 'Administrator',
    action: 'TEST_AUDIT_ACTION',
    entityType: 'TestEntity',
    entityId: 'test-123',
    outcome: 'SUCCESS',
    details: { test: true }
  });

  assert.ok(entry.currentHash);
  assert.strictEqual(entry.currentHash.length, 64);
  assert.ok(entry.prevHash);

  const verify = auditLogger.verifyChainIntegrity();
  assert.strictEqual(verify.isValid, true);
});

// 3. Three-Tier RBAC Policy Tests
console.log('\n▶ Module 3: Three-Tier RBAC & Permissions Policy');
runTest('Central policy defines Viewer, Researcher, and Administrator tiers', () => {
  assert.ok(config.roles.VIEWER);
  assert.ok(config.roles.RESEARCHER);
  assert.ok(config.roles.ADMINISTRATOR);
});

runTest('Viewer has restricted permissions (cannot upload datasets or view sensitive data)', () => {
  const viewerPerms = config.permissions.Viewer;
  assert.ok(!viewerPerms.includes('datasets:upload'));
  assert.ok(!viewerPerms.includes('audit:read'));
  assert.ok(!viewerPerms.includes('parcels:read_sensitive'));
});

runTest('Administrator has supervisory privileges (audit, verify, manage)', () => {
  const adminPerms = config.permissions.Administrator;
  assert.ok(adminPerms.includes('audit:read'));
  assert.ok(adminPerms.includes('parcels:verify'));
  assert.ok(adminPerms.includes('datasets:upload'));
});

// 4. WebGIS Spatial Queries & Bounding Box Tests
console.log('\n▶ Module 4: WebGIS Spatial Bounding Box & Parcel Store');
runTest('Bounding box query filters parcels within latitude and longitude bounds', () => {
  const result = db.getParcelsByBbox({
    minLat: 18.0,
    maxLat: 19.0,
    minLng: 73.0,
    maxLng: 74.5,
    limit: 10
  });

  assert.ok(result.parcels.length > 0);
  result.parcels.forEach(p => {
    assert.ok(p.centroidLat >= 18.0 && p.centroidLat <= 19.0);
    assert.ok(p.centroidLng >= 73.0 && p.centroidLng <= 74.5);
  });
});

runTest('ULPIN query accurately locates specific parcel', () => {
  const parcel = db.findParcelByUlpin('MH26000190012A');
  assert.ok(parcel);
  assert.strictEqual(parcel.village, 'Wagholi');
  assert.strictEqual(parcel.state, 'Maharashtra');
});

// 5. Research & Statutory RAG Citation Grounding Tests
console.log('\n▶ Module 5: Statutory Knowledge & RAG Grounding Verification');
runTest('All statutory acts (LARR 2013, FRA 2006, Wetlands 2017, ULPIN) are indexed', () => {
  const acts = db.getAllActs();
  assert.strictEqual(acts.length, 4);
  const titles = acts.map(a => a.shortName);
  assert.ok(titles.includes('LARR Act 2013'));
  assert.ok(titles.includes('Forest Rights Act (FRA) 2006'));
  assert.ok(titles.includes('Wetlands Rules 2017'));
  assert.ok(titles.includes('ULPIN Standards 2021'));
});

runTest('Document chunks contain required section numbers and legal text', () => {
  const chunks = db.getAllDocumentChunks();
  assert.ok(chunks.length >= 8);
  const larrSolatium = chunks.find(c => c.sectionNumber === 'Section 30');
  assert.ok(larrSolatium);
  assert.ok(larrSolatium.content.includes('Solatium'));
  assert.ok(larrSolatium.content.includes('one hundred per cent'));
});

// 6. Policy Simulation & Compensation Formula Tests
console.log('\n▶ Module 6: Policy What-If & LARR 2013 Financial Formula');
runTest('Compensation calculation applies Rural Multiplier and 100% Solatium correctly', () => {
  const agriHa = 100;
  const circleRatePerHa = 4000000; // 40 Lakhs INR
  const multiplier = 2.0; // Rural 2x
  const solatiumPct = 100.0; // 100%

  const baseMarketVal = agriHa * circleRatePerHa * multiplier; // 800,000,000
  const solatium = baseMarketVal * (solatiumPct / 100.0); // 800,000,000
  const total = baseMarketVal + solatium; // 1,600,000,000

  assert.strictEqual(baseMarketVal, 800000000);
  assert.strictEqual(total, 1600000000);
});

console.log('\n====================================================================');
console.log(`🏁 Test Summary: ${testsPassed} Passed, ${testsFailed} Failed`);
console.log('====================================================================\n');

if (testsFailed > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
