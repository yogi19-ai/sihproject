const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./src/config');
const apiRoutes = require('./src/routes/api');

const app = express();

// Security & Cross-Origin Configuration
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Request Body Parsing with size boundaries
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Request Logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (process.env.NODE_ENV !== 'test') {
      console.log(`[HTTP] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
});

// Root Welcome Route
app.get('/', (req, res) => {
  res.json({
    platform: 'National Digital Platform for Land Governance (SIH26019)',
    version: '1.0.0',
    status: 'ONLINE',
    documentation: '/api/health',
    message: 'Welcome to the Government of India Land Governance Core API Service.'
  });
});

// API Routes
app.use('/api', apiRoutes);

// 404 Route Handler
app.use((req, res) => {
  res.status(404).json({
    error: `Endpoint not found: ${req.method} ${req.originalUrl}`,
    status: 404
  });
});

// Structured Global Error Handler
app.use((err, req, res, next) => {
  console.error('[Unhandled Error]:', err.stack || err.message);
  res.status(err.status || 500).json({
    error: err.message || 'An unexpected internal error occurred.',
    code: err.code || 'INTERNAL_ERROR'
  });
});

// Start Server
if (process.env.NODE_ENV !== 'test') {
  app.listen(config.port, () => {
    console.log(`====================================================================`);
    console.log(`🏛️  SIH26019: National Land Governance Core API Service Running`);
    console.log(`📡 URL: http://localhost:${config.port}`);
    console.log(`🛡️  RBAC: Three-Tier [Viewer, Researcher, Administrator]`);
    console.log(`🔐 SHA-256 Audit Ledger: Initialized & Verified`);
    console.log(`====================================================================`);
  });
}

module.exports = app;
